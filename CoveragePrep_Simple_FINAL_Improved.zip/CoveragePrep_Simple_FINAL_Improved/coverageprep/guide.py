"""Local, deterministic analysis of Guide/Instruction sheets.

The challenge workbooks may include sheets such as ``Guide`` or ``Instructions``
that describe client-specific field or period conventions.  CoveragePrep keeps
this analysis deliberately local and rule-based: it reads explanatory text and
extracts only explicit hints/examples.  It never sends client data to an
external service and never treats a guide hint as permission to overwrite source
values.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import re

from openpyxl import load_workbook

from .reader import validate_source_path

_GUIDE_SHEET_RE = re.compile(
    r"(?:^|\b)(guide|instructions?|read\s*me|readme|documentation|definitions?|spec(?:ification)?s?)(?:\b|$)",
    re.IGNORECASE,
)

# Explicit guide examples such as:
#   c2025 Feb = February 2025
#   c2025 Feb means February 2025
#   c2025 Feb represents February 2025
_EXPLICIT_MAPPING_RE = re.compile(
    r"(?P<source>c(?:19|20)\d{2}\s+[A-Za-z]{3,9})\s*"
    r"(?:=|means|represents|is|->|→|:)\s*"
    r"(?P<target>[A-Za-z]{3,9}[\s\-/]+(?:19|20)\d{2})",
    re.IGNORECASE,
)

_C_YEAR_MONTH_RE = re.compile(r"\bc(?:19|20)\d{2}\s+[A-Za-z]{3,9}\b", re.IGNORECASE)


@dataclass(frozen=True)
class GuidePeriodExample:
    sheet_name: str
    source_text: str
    target_text: str
    row_number: int
    confidence: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class GuidePatternHint:
    sheet_name: str
    pattern_name: str
    example: str
    row_number: int
    confidence: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class GuideAnalysis:
    guide_sheets: list[str]
    explicit_period_examples: list[GuidePeriodExample]
    pattern_hints: list[GuidePatternHint]
    notes: list[str]

    @property
    def explicit_mapping(self) -> dict[str, GuidePeriodExample]:
        """Case-insensitive lookup for explicit source->target examples."""
        return {item.source_text.casefold(): item for item in self.explicit_period_examples}

    @property
    def pattern_names(self) -> set[str]:
        return {item.pattern_name for item in self.pattern_hints}

    def to_dict(self) -> dict[str, Any]:
        return {
            "guide_sheets": list(self.guide_sheets),
            "explicit_period_examples": [x.to_dict() for x in self.explicit_period_examples],
            "pattern_hints": [x.to_dict() for x in self.pattern_hints],
            "notes": list(self.notes),
        }


def _cell_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _read_guide_rows(path: Path, sheet_name: str, *, max_rows: int, max_columns: int) -> list[tuple[int, str]]:
    keep_vba = path.suffix.lower() == ".xlsm"
    wb = load_workbook(path, read_only=True, data_only=False, keep_vba=keep_vba, keep_links=True)
    try:
        ws = wb[sheet_name]
        output: list[tuple[int, str]] = []
        for row_number, row in enumerate(
            ws.iter_rows(
                min_row=1,
                max_row=min(int(ws.max_row or 0), max_rows),
                min_col=1,
                max_col=min(int(ws.max_column or 0), max_columns),
                values_only=True,
            ),
            start=1,
        ):
            pieces = [_cell_text(v) for v in row if _cell_text(v)]
            if pieces:
                output.append((row_number, " | ".join(pieces)))
        return output
    finally:
        wb.close()


def analyze_guide_sheets(
    file_path: str | Path,
    *,
    max_rows: int = 250,
    max_columns: int = 80,
) -> GuideAnalysis:
    """Extract explicit local hints from Guide/Instruction-like sheets.

    The function is intentionally conservative.  It only records text that is
    actually present in the workbook.  A pattern hint improves scan diagnostics;
    source values are still transformed only by the normal period parser and
    validation workflow.
    """
    path = validate_source_path(file_path)
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        return GuideAnalysis([], [], [], ["No workbook guide-sheet analysis is available for CSV input."])

    keep_vba = path.suffix.lower() == ".xlsm"
    wb = load_workbook(path, read_only=True, data_only=False, keep_vba=keep_vba, keep_links=True)
    try:
        guide_sheets = [name for name in wb.sheetnames if _GUIDE_SHEET_RE.search(name)]
    finally:
        wb.close()

    examples: list[GuidePeriodExample] = []
    hints: list[GuidePatternHint] = []
    notes: list[str] = []
    seen_examples: set[tuple[str, str]] = set()
    seen_hints: set[tuple[str, str]] = set()

    for sheet_name in guide_sheets:
        for row_number, text in _read_guide_rows(path, sheet_name, max_rows=max_rows, max_columns=max_columns):
            for match in _EXPLICIT_MAPPING_RE.finditer(text):
                source = re.sub(r"\s+", " ", match.group("source").strip())
                target = re.sub(r"\s+", " ", match.group("target").strip())
                key = (source.casefold(), target.casefold())
                if key not in seen_examples:
                    seen_examples.add(key)
                    examples.append(
                        GuidePeriodExample(
                            sheet_name=sheet_name,
                            source_text=source,
                            target_text=target,
                            row_number=row_number,
                            confidence="High",
                            reason="explicit source-to-period example found in guide/instruction text",
                        )
                    )

            c_examples = _C_YEAR_MONTH_RE.findall(text)
            for example in c_examples:
                key = (sheet_name.casefold(), "cYYYY MMM")
                if key not in seen_hints:
                    seen_hints.add(key)
                    hints.append(
                        GuidePatternHint(
                            sheet_name=sheet_name,
                            pattern_name="cYYYY MMM",
                            example=example,
                            row_number=row_number,
                            confidence="High",
                            reason="client-style cYYYY MMM period token appears in guide/instruction text",
                        )
                    )

    if guide_sheets:
        notes.append(
            f"Analyzed {len(guide_sheets)} guide/instruction sheet(s) locally: {', '.join(guide_sheets)}."
        )
        if not examples and not hints:
            notes.append("Guide sheets were found, but no explicit supported period examples were extracted.")
    else:
        notes.append("No Guide/Instructions/ReadMe/Documentation/Definition sheet was detected.")

    return GuideAnalysis(guide_sheets, examples, hints, notes)
