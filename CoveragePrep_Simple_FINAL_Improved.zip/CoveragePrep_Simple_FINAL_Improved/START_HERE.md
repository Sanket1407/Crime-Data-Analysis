# Start Here — VS Code

## 1. Open this folder in VS Code

Open the extracted `CoveragePrep_Simple_FINAL_Improved` folder.

## 2. Open Terminal → New Terminal

Use Command Prompt on Windows.

## 3. Create and activate the Python environment

```bat
python -m venv .venv
.venv\Scripts\activate
```

## 4. Install the application

```bat
python -m pip install -r requirements.txt
```

## 5. Test with synthetic files first

Run:

```bat
python main.py
```

Choose either:

```text
1. Scan a shipment file
```

or:

```text
2. Prepare a shipment file
```

When asked for another local path, try:

```text
sample_data\sample_multisheet_shipment.xlsx
```

For this synthetic workbook, select:

```text
Shipment KG
Shipment Units
```

To test the improved period scanner specifically, use:

```text
sample_data\sample_c_period_headers.xlsx
```

Its `Data` sheet contains 37 deliberately out-of-order headers such as `c2025 Feb`, `c2024 Jul`, and `c2023 Mar`. Scan-only mode should recognize them as monthly periods, normalize them to `Feb 2025`, `Jul 2024`, `Mar 2023`, report the range `Jan 2023` to `Jan 2026`, and flag the source order as non-chronological rather than failing period detection.

The app should detect monthly periods and suggest:

```text
Shipment KG    -> FACT = KG
Shipment Units -> FACT = UNITS
```

A successful run should end with:

```text
FINAL STATUS: PASS
```

and can create:

```text
output\sample_multisheet_shipment_Prepared.xlsx
```

## 6. Real local shipment

You can either place the file under `input\` or choose `0` and paste its local path.

The original file is never overwritten.

## 7. Reuse next month

After a successful preparation, choose to save the config under `config\`.

Next time run:

```bat
python main.py
```

and choose:

```text
3. Reuse a saved configuration
```

The program checks the new file structure before applying the saved rules.

## 8. Tests

```bat
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

Expected for this build:

```text
58 passed
```
