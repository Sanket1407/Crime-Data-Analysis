# CoveragePrep Simple — Improved Final Local Build

CoveragePrep Simple is a **local-first Python terminal application** for preparing client shipment files before Coverage Analysis.

It is intentionally simpler than the earlier Streamlit build. The main application is plain Python and runs from VS Code with:

```bat
python main.py
```

No Streamlit, web server, database, Docker, or external AI service is required.

## Core design rules

- The original shipment file is never overwritten.
- `.xlsx`, `.xlsm`, and `.csv` inputs are supported.
- Every Excel sheet is inventoried before processing.
- Single-row and multi-row headers are supported.
- Client source header names remain unchanged in `Prepared_Data`.
- Logical roles such as COUNTRY / REGION / CHANNEL / CATEGORY / BRAND / SKU are internal metadata only.
- Multiple source fields may share one logical role and remain separate in the output.
- Each processed table has **one shipment FACT/value series**.
- Periods can be in columns, rows, Year + Month/Week/Quarter fields, multi-row headers, or sheet names.
- Monthly output labels are standardized as `Jan 2026`, `Dec 2024`, etc.
- Weekly / quarterly / bimonthly frequency is preserved.
- Ambiguous periods are flagged; they are never guessed.
- Period collisions block preparation instead of merging values.
- Automatic aggregation is disabled.
- Duplicate pivot keys block the transformation unless another distinguishing field exists.
- Numerical validation uses source lineage and exact dimension + FACT + period associations, not only grand totals.

## Final terminal menu

```text
1. Scan a shipment file
2. Prepare a shipment file
3. Reuse a saved configuration
4. Exit
```

### 1. Scan a shipment file

Read-only inspection of:

- all sheets/tables;
- sheet dimensions;
- likely header rows;
- multi-row headers;
- period structure;
- period collisions / review items.

You can optionally create:

```text
output/<source>_Scan_Report.xlsx
```

The scan report contains:

```text
Workbook_Summary
Sheet_Summary
Guide_Analysis
Header_Detection
Period_Detection
Period_Map
Period_Coverage
Readiness
Issues
Recommendations
```

The improved scan report now shows the detected period pattern, frequency, first/last period, missing periods, source chronology, a normalization preview, actionable recommendations, and a transparent transformation-readiness assessment.

No shipment data is transformed in scan-only mode.

### 2. Prepare a shipment file

The terminal guides you through:

1. local file selection;
2. selecting one or more sheets;
3. header confirmation or manual header-row range;
4. period detection;
5. logical field-role review;
6. FACT label confirmation;
7. period ordering;
8. negative-value rule;
9. exact-duplicate rule;
10. transformation;
11. per-sheet validation;
12. combining selected sheets into one `Prepared_Data`;
13. local export;
14. optional reusable config save.

### 3. Reuse a saved configuration

A successful run can save:

```text
config/<source>_Config.json
```

Before applying it to a later shipment, CoveragePrep rescans and compares the new structure.

Period columns may naturally change between deliveries. The reusable structure check focuses on durable structure such as:

- selected sheet names;
- layout type;
- header rows;
- non-period source fields;
- logical field-role set;
- ability to run the saved transformation safely.

If the structure changed, the configuration is **not applied automatically**.

## FACT behaviour

The normal model is **one value series per processed table**.

Wide example:

```text
Brand | Jan-26 | Feb-26 | Mar-26
ABC   | 100    | 120    | 130
```

becomes:

```text
Brand | FACT        | Jan 2026 | Feb 2026 | Mar 2026
ABC   | Sales Value | 100      | 120      | 130
```

The period columns are not treated as separate facts.

Row example:

```text
Brand | Period   | Sales Value
ABC   | Jan-26   | 100
ABC   | Feb 2026 | 120
```

becomes:

```text
Brand | FACT        | Jan 2026 | Feb 2026
ABC   | Sales Value | 100      | 120
```

Numeric identifiers such as SKU / UPC / Material Code are protected from being automatically treated as fact values.

## Multi-sheet processing

Each selected sheet is transformed and validated separately first.

Only then are the resulting rows combined into one `Prepared_Data`.

For example:

```text
Shipment KG    -> FACT = KG
Shipment Units -> FACT = UNITS
```

may produce:

```text
Region Description | Brand Desc | Material Code | FACT  | Jan 2026 | Feb 2026
West                | Brand A    | SKU001        | KG    | 100      | 120
West                | Brand A    | SKU001        | UNITS | 20       | 25
```

Different original source headers remain separate. The application does not silently rename or merge them.

## Period detection

Examples standardized to monthly display:

```text
c2025 Feb       -> Feb 2025
JAN-26          -> Jan 2026
February 2026   -> Feb 2026
FEB2026         -> Feb 2026
January/2020    -> Jan 2020
202603          -> Mar 2026
04/2026         -> Apr 2026
Dec-24          -> Dec 2024
```

Common simple patterns are kept in a centralized `PERIOD_PATTERNS` registry in `coverageprep/periods.py`, making future client conventions easier to add and test. Bare month values such as `01` or `1` are recognized only as ambiguous month components until a year/context is confirmed.

Examples that retain frequency:

```text
2026-W05        -> W05 2026
2026-Q1         -> Q1 2026
Jan-Feb 2026    -> Jan-Feb 2026
```

If two source period fields both resolve to the same standardized period unexpectedly, transformation is blocked until the user resolves the meaning.

### Guide / instruction sheet analysis

When the workbook contains sheets named like `Guide`, `Instructions`, `ReadMe`, `Documentation`, or `Definition`, CoveragePrep analyzes their text locally for explicit period examples and pattern hints. For example, a guide statement such as:

```text
c2025 Feb = February 2025
```

is captured in `Guide_Analysis` and can corroborate period recognition. This is deterministic local parsing; no external AI service is required.

### Period coverage and chronology

For a detected series the scanner reports, where applicable:

```text
Pattern: cYYYY MMM
Frequency: Monthly
Detected periods: 37
First: Jan 2023
Last: Jan 2026
Source order: Non-chronological
Missing months: None
Recommended action: sort Prepared_Data ascending
```

Only the prepared output is reordered. The source workbook and source evidence remain unchanged.

### Transformation readiness

The read-only scan provides a transparent weighted readiness assessment across Header Detection, Period Detection, Chronology, Field Structure, Fact Detection, and blocking safety checks. It is a diagnostic aid, not an automatic approval: the terminal still requires user confirmation before transformation.

## Negative values

The terminal offers:

```text
1. Keep original [recommended]
2. Convert negatives to positive
3. Convert negatives to zero
```

If the user chooses option 2 or 3, the original value remains in source evidence and lineage, while validation checks the explicitly approved expected value.

## Duplicates

The terminal offers:

```text
1. Keep all [recommended]
2. Exclude exact duplicate source rows from Prepared_Data
```

This only applies to **exact duplicate source rows** and is an explicit user choice.

A duplicate transformation key is different. If multiple source records would occupy the same dimension + FACT + period output position, CoveragePrep blocks the pivot rather than summing them automatically.

## Validation

Every selected sheet is validated independently using:

- source/expected fact-cell counts;
- exact source lineage;
- dimension + FACT + period association;
- overall fact-value multiset;
- per-period counts;
- per-period numerical reconciliation.

This catches cases where two values are accidentally swapped between products even when the grand total remains unchanged.

## Final local output

A fully validated run creates:

```text
output/<source>_Prepared.xlsx
```

If validation fails:

```text
output/<source>_REVIEW_REQUIRED.xlsx
```

The review workbook is deliberately not labelled as validated prepared output.

Sheets:

```text
Prepared_Data
# or Prepared_Data_DRAFT

Source_Copy
# or Source_Reference for large inputs

Field_Mapping
Period_Map
Validation
Issues
Recommendations
Audit_Log
```

### Source_Copy / Source_Reference

For manageable selected sheets, `Source_Copy` is one audit ledger containing cells from all selected source sheets with:

```text
SOURCE_SHEET
SOURCE_ROW
SOURCE_COLUMN
SOURCE_HEADER
ORIGINAL_VALUE
FORMULA
CACHED_VALUE
```

For large files, the application uses `Source_Reference` instead of duplicating the entire source into Excel. The original local source file remains untouched.

### Excel-size fallback

If `Prepared_Data` exceeds Excel worksheet limits, the application writes:

```text
<source>_Prepared_Data.csv
```

and keeps the evidence/control sheets in the Excel workbook.

## Folder structure

```text
CoveragePrep_Simple_7G/
│
├── main.py
├── requirements.txt
├── requirements-dev.txt
├── README.md
├── START_HERE.md
│
├── coverageprep/
│   ├── reader.py
│   ├── scanner.py
│   ├── periods.py
│   ├── mapping.py
│   ├── transform.py
│   ├── validation.py
│   ├── workflow.py
│   ├── config.py
│   ├── export.py
│   ├── export_multi.py
│   └── scanreport.py
│
├── input/
├── output/
├── config/
├── sample_data/
└── tests/
```

## Install and run

Windows / VS Code Command Prompt:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

Testing:

```bat
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

Current verified test result:

```text
58 passed
```

## Confidentiality

Keep real client files only inside your approved company environment.

Do not place real shipment files in GitHub. The repository `.gitignore` excludes `input/`, `output/`, and `config/` contents by default.

## Additional safety rules in 7G

- `P01`, `P02`, etc. are never assumed to mean months. If a Year column is present, the terminal can explicitly ask you to confirm `P01=Jan`, `P02=Feb`, etc. before using that mapping.
- Formula-derived fact cells are preserved in source evidence but are blocked from automatic transformation in this simple build. This avoids silently relying on hidden spreadsheet logic.
- If multiple numeric columns could be the shipment value, the terminal can ask you to select the single fact/value source column explicitly.
