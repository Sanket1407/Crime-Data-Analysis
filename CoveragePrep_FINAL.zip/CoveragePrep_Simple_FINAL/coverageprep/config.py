"""Reusable local configuration for CoveragePrep Simple Step 7G."""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
import json
from pathlib import Path
from typing import Any

from .reader import validate_source_path
from .workflow import MultiSheetRun, SheetRunSpec, WorkflowBlocked, process_sheet


CONFIG_VERSION = 1


def _sheet_signature(result) -> dict[str, Any]:
    preview = result.preview
    periods = {str(x.get("standard")) for x in preview.period_map if x.get("standard")}
    dims = [
        str(c) for c in preview.prepared_data.columns
        if c != "FACT" and c not in periods
    ]
    return {
        "layout": preview.layout,
        "header_start_row": preview.header_start_row,
        "header_end_row": preview.header_end_row,
        "dimension_headers": dims,
        "field_roles": dict(preview.field_roles),
        "fact_source_header": preview.fact_source_header,
        "period_source_columns": list(preview.period_source_columns or []),
    }


def build_config(run: MultiSheetRun) -> dict[str, Any]:
    return {
        "config_version": CONFIG_VERSION,
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "source_filename_at_creation": Path(run.source_file).name,
        "period_order": run.results[0].spec.period_order if run.results else "ascending",
        "sheets": [
            {
                "spec": result.spec.to_dict(),
                "signature": _sheet_signature(result),
            }
            for result in run.results
        ],
    }


def save_config(run: MultiSheetRun, path: str | Path) -> Path:
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(build_config(run), indent=2, ensure_ascii=False), encoding="utf-8")
    return target


def load_config(path: str | Path) -> dict[str, Any]:
    target = Path(path).expanduser().resolve()
    if not target.exists():
        raise FileNotFoundError(f"Configuration not found: {target}")
    data = json.loads(target.read_text(encoding="utf-8"))
    if data.get("config_version") != CONFIG_VERSION:
        raise WorkflowBlocked(
            f"Unsupported config version {data.get('config_version')}; expected {CONFIG_VERSION}."
        )
    if not isinstance(data.get("sheets"), list) or not data["sheets"]:
        raise WorkflowBlocked("Configuration contains no sheet definitions.")
    return data


def specs_from_config(config: dict[str, Any]) -> list[SheetRunSpec]:
    specs: list[SheetRunSpec] = []
    for item in config["sheets"]:
        spec = item["spec"]
        specs.append(SheetRunSpec(**spec))
    return specs


def compare_structure(source_file: str | Path, config: dict[str, Any]) -> tuple[bool, list[str]]:
    """Safely test a saved config against a new file.

    Period labels are allowed to change between deliveries. We compare the durable
    structural parts: selected sheets, layout, header range, dimension headers and
    logical role keys. The new file must also transform successfully using the saved
    configuration before it is considered safe to reuse.
    """
    path = validate_source_path(source_file)
    messages: list[str] = []
    safe = True
    for item in config["sheets"]:
        spec = SheetRunSpec(**item["spec"])
        expected = item["signature"]
        sheet_safe = True
        try:
            current = process_sheet(path, spec)
        except Exception as exc:
            safe = False
            messages.append(f"{spec.sheet_name}: could not reuse safely — {exc}")
            continue

        preview = current.preview
        periods = {str(x.get("standard")) for x in preview.period_map if x.get("standard")}
        current_dims = [
            str(c) for c in preview.prepared_data.columns
            if c != "FACT" and c not in periods
        ]
        if preview.layout != expected.get("layout"):
            safe = False
            sheet_safe = False
            messages.append(
                f"{spec.sheet_name}: layout changed {expected.get('layout')} -> {preview.layout}"
            )
        expected_dims = expected.get("dimension_headers", [])
        if current_dims != expected_dims:
            safe = False
            sheet_safe = False
            added = [x for x in current_dims if x not in expected_dims]
            removed = [x for x in expected_dims if x not in current_dims]
            messages.append(
                f"{spec.sheet_name}: dimension/header structure changed; added={added or 'none'}, removed={removed or 'none'}"
            )
        if set(preview.field_roles) != set(expected.get("field_roles", {})):
            safe = False
            sheet_safe = False
            messages.append(f"{spec.sheet_name}: mapped source-field set changed")
        if sheet_safe:
            messages.append(f"{spec.sheet_name}: structure compatible")
    return safe, messages
