"""Read-only file inventory for CoveragePrep Simple.

Step 7A scope only:
- Support .xlsx, .xlsm and .csv inputs.
- Inventory every Excel sheet or the single CSV table.
- Read a small preview without transforming data.
- Never write back to the source file.

This module remains the read-only input layer. Structural header scanning is
implemented separately in ``coverageprep.scanner``. Period detection, mapping,
transformation, validation and export are intentionally not implemented yet.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable
import csv
import hashlib
import os

from openpyxl import load_workbook


SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm", ".csv"}


class UnsupportedFileTypeError(ValueError):
    """Raised when the supplied shipment file type is not supported."""


class ShipmentReadError(RuntimeError):
    """Raised when the source file cannot be inventoried safely."""


@dataclass(frozen=True)
class SheetInventory:
    """Read-only structural summary of one sheet/table."""

    name: str
    rows: int
    columns: int
    state: str
    preview: list[list[Any]]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class FileInventory:
    """Read-only structural summary of a shipment file."""

    path: str
    filename: str
    extension: str
    size_bytes: int
    sheets: list[SheetInventory]

    @property
    def sheet_count(self) -> int:
        return len(self.sheets)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["sheet_count"] = self.sheet_count
        return data


def validate_source_path(file_path: str | os.PathLike[str]) -> Path:
    """Validate the input path without modifying the source."""
    path = Path(file_path).expanduser().resolve()

    if not path.exists():
        raise FileNotFoundError(f"Shipment file not found: {path}")
    if not path.is_file():
        raise ShipmentReadError(f"Input path is not a file: {path}")

    extension = path.suffix.lower()
    if extension not in SUPPORTED_EXTENSIONS:
        supported = ", ".join(sorted(SUPPORTED_EXTENSIONS))
        raise UnsupportedFileTypeError(
            f"Unsupported file type '{extension or '(none)'}'. Supported: {supported}"
        )

    return path


def fingerprint_sha256(
    file_path: str | os.PathLike[str], chunk_size: int = 1024 * 1024
) -> str:
    """Return a SHA-256 fingerprint without altering the file.

    This is optional because hashing very large shipment files can take time.
    """
    path = validate_source_path(file_path)
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _normalize_preview_value(value: Any) -> Any:
    """Return a terminal-friendly preview value without changing source data."""
    if value is None:
        return None
    # Leave real numeric/date/formula values intact. Only cap very long text in preview.
    if isinstance(value, str) and len(value) > 200:
        return value[:197] + "..."
    return value


def _preview_rows(rows: Iterable[Iterable[Any]], limit: int) -> list[list[Any]]:
    preview: list[list[Any]] = []
    for row_number, row in enumerate(rows, start=1):
        if row_number > limit:
            break
        preview.append([_normalize_preview_value(value) for value in row])
    return preview


def _inventory_excel(path: Path, preview_rows: int) -> FileInventory:
    """Inventory an Excel workbook in read-only mode."""
    keep_vba = path.suffix.lower() == ".xlsm"

    try:
        workbook = load_workbook(
            filename=path,
            read_only=True,
            data_only=False,  # keep formulas visible for later review stages
            keep_vba=keep_vba,
            keep_links=True,
        )
    except Exception as exc:  # openpyxl emits several file-format exceptions
        raise ShipmentReadError(f"Could not read workbook '{path.name}': {exc}") from exc

    inventories: list[SheetInventory] = []
    try:
        for worksheet in workbook.worksheets:
            rows = int(worksheet.max_row or 0)
            columns = int(worksheet.max_column or 0)

            if rows > 0 and columns > 0:
                raw_preview = worksheet.iter_rows(
                    min_row=1,
                    max_row=min(rows, preview_rows),
                    min_col=1,
                    max_col=columns,
                    values_only=False,
                )
                preview = _preview_rows(
                    ([cell.value for cell in row] for row in raw_preview), preview_rows
                )
            else:
                preview = []

            inventories.append(
                SheetInventory(
                    name=worksheet.title,
                    rows=rows,
                    columns=columns,
                    state=worksheet.sheet_state,
                    preview=preview,
                )
            )
    finally:
        workbook.close()

    return FileInventory(
        path=str(path),
        filename=path.name,
        extension=path.suffix.lower(),
        size_bytes=path.stat().st_size,
        sheets=inventories,
    )


def _open_csv_text(path: Path):
    """Open a CSV with a conservative local encoding fallback."""
    try:
        return path.open("r", encoding="utf-8-sig", newline="")
    except UnicodeDecodeError:
        # This exception normally occurs on read, not open. Kept for clarity.
        return path.open("r", encoding="cp1252", newline="")


def _read_csv_with_encoding(path: Path, encoding: str, preview_rows: int):
    preview: list[list[Any]] = []
    row_count = 0
    max_columns = 0

    with path.open("r", encoding=encoding, newline="") as handle:
        sample = handle.read(8192)
        handle.seek(0)

        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|") if sample else csv.excel
        except csv.Error:
            dialect = csv.excel

        reader = csv.reader(handle, dialect)
        for row in reader:
            row_count += 1
            max_columns = max(max_columns, len(row))
            if len(preview) < preview_rows:
                preview.append([_normalize_preview_value(value) for value in row])

    return row_count, max_columns, preview


def _inventory_csv(path: Path, preview_rows: int) -> FileInventory:
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            rows, columns, preview = _read_csv_with_encoding(path, encoding, preview_rows)
            return FileInventory(
                path=str(path),
                filename=path.name,
                extension=path.suffix.lower(),
                size_bytes=path.stat().st_size,
                sheets=[
                    SheetInventory(
                        name="(CSV)",
                        rows=rows,
                        columns=columns,
                        state="visible",
                        preview=preview,
                    )
                ],
            )
        except UnicodeDecodeError as exc:
            last_error = exc
            continue
        except Exception as exc:
            raise ShipmentReadError(f"Could not read CSV '{path.name}': {exc}") from exc

    raise ShipmentReadError(
        f"Could not decode CSV '{path.name}' using UTF-8 or CP1252: {last_error}"
    )


def inventory_file(
    file_path: str | os.PathLike[str], preview_rows: int = 8
) -> FileInventory:
    """Inventory a shipment file without transforming or writing to it.

    Parameters
    ----------
    file_path:
        Local .xlsx, .xlsm or .csv shipment file.
    preview_rows:
        Number of top rows kept in memory per sheet for display only.
    """
    if preview_rows < 0:
        raise ValueError("preview_rows must be 0 or greater")

    path = validate_source_path(file_path)

    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        return _inventory_excel(path, preview_rows)
    return _inventory_csv(path, preview_rows)
