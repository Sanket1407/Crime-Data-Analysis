"""Read-only period detection and standardization recommendations.

Step 7C scope
-------------
- detect period labels in column headers, row values, separate Year + Month/Week/Quarter
  columns, and sheet names;
- recommend readable standardized labels without modifying source data;
- monthly labels are always ``Jan 2026`` / ``Dec 2024`` style;
- preserve source frequency (monthly stays monthly, weekly stays weekly, etc.);
- flag ambiguous labels instead of guessing;
- detect collisions where two source fields resolve to the same standardized period.

This module does NOT pivot, aggregate, rename source fields, or write output files.
Those belong to later rebuild steps.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable
import csv
import math
import re

from openpyxl import load_workbook

from .reader import ShipmentReadError, inventory_file, validate_source_path
from .scanner import HeaderCandidate, SheetHeaderScan, scan_sheet_headers


MONTH_ABBR = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]

_MONTH_LOOKUP: dict[str, int] = {}
for number, (abbr, full) in enumerate(
    zip(
        MONTH_ABBR,
        [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December",
        ],
    ),
    start=1,
):
    _MONTH_LOOKUP[abbr.casefold()] = number
    _MONTH_LOOKUP[full.casefold()] = number
    # Common September variant.
    if number == 9:
        _MONTH_LOOKUP["sept"] = 9

_MONTH_PATTERN = "(?:" + "|".join(
    sorted((re.escape(k) for k in _MONTH_LOOKUP), key=len, reverse=True)
) + ")"

_TWO_OR_FOUR_YEAR = r"(?:\d{2}|(?:19|20)\d{2})"
_FOUR_YEAR = r"(?:19|20)\d{2}"

_IDENTIFIER_HEADER_RE = re.compile(
    r"\b(?:sku|upc|ean|gtin|item|material|product\s*code|code|identifier|\bid\b)\b",
    re.IGNORECASE,
)
_PERIOD_HEADER_HINT_RE = re.compile(
    r"\b(?:period|month|week|wk|quarter|qtr|year|date|time)\b",
    re.IGNORECASE,
)
_YEAR_HEADER_RE = re.compile(r"\b(?:year|yr|yyyy)\b", re.IGNORECASE)
_MONTH_HEADER_RE = re.compile(r"\b(?:month|mnth|mm|analysis\s*month)\b", re.IGNORECASE)
_WEEK_HEADER_RE = re.compile(r"\b(?:week|wk|week\s*no|week\s*number)\b", re.IGNORECASE)
_QUARTER_HEADER_RE = re.compile(r"\b(?:quarter|qtr)\b", re.IGNORECASE)


@dataclass(frozen=True)
class PeriodParse:
    original: str
    frequency: str
    standard: str | None
    status: str  # OK / REVIEW / AMBIGUOUS / NOT_PERIOD
    confidence: str
    reason: str
    year: int | None = None
    sequence: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PeriodFinding:
    location: str  # COLUMN_HEADER / ROW_COLUMN / COMBINED_COLUMNS / SHEET_NAME
    source: str
    frequency: str
    status: str
    confidence: str
    mappings: list[PeriodParse]
    detail: str
    source_columns: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PeriodCollision:
    standard_period: str
    sources: list[str]
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SheetPeriodScan:
    sheet_name: str
    header_start_row: int | None
    header_end_row: int | None
    findings: list[PeriodFinding]
    collisions: list[PeriodCollision]
    warnings: list[str]

    @property
    def blocking_issue_count(self) -> int:
        return len(self.collisions) + sum(
            1
            for finding in self.findings
            for mapping in finding.mappings
            if mapping.status == "AMBIGUOUS"
        )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["blocking_issue_count"] = self.blocking_issue_count
        return data


@dataclass(frozen=True)
class WorkbookPeriodScan:
    filename: str
    sheets: list[SheetPeriodScan]

    def to_dict(self) -> dict[str, Any]:
        return {"filename": self.filename, "sheets": [sheet.to_dict() for sheet in self.sheets]}


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _year_from_token(token: str) -> int | None:
    token = token.strip()
    if re.fullmatch(_FOUR_YEAR, token):
        return int(token)
    if re.fullmatch(r"\d{2}", token):
        value = int(token)
        # Shipment examples overwhelmingly use recent two-digit years. Values 80-99
        # are kept conservative and treated as the 1900s; 00-79 as the 2000s.
        return 2000 + value if value <= 79 else 1900 + value
    return None


def _month_number(token: str) -> int | None:
    return _MONTH_LOOKUP.get(token.strip().casefold())


def _monthly(original: str, year: int, month: int, *, reason: str, confidence: str = "High") -> PeriodParse:
    if not 1 <= month <= 12:
        return PeriodParse(original, "Monthly", None, "AMBIGUOUS", "Low", "month is outside 1-12")
    return PeriodParse(
        original=original,
        frequency="Monthly",
        standard=f"{MONTH_ABBR[month - 1]} {year:04d}",
        status="OK",
        confidence=confidence,
        reason=reason,
        year=year,
        sequence=month,
    )


def _weekly(original: str, year: int, week: int, *, reason: str) -> PeriodParse:
    if not 1 <= week <= 53:
        return PeriodParse(original, "Weekly", None, "AMBIGUOUS", "Low", "week is outside 1-53")
    return PeriodParse(
        original, "Weekly", f"W{week:02d} {year:04d}", "OK", "High", reason, year, week
    )


def _quarterly(original: str, year: int, quarter: int, *, reason: str) -> PeriodParse:
    if not 1 <= quarter <= 4:
        return PeriodParse(original, "Quarterly", None, "AMBIGUOUS", "Low", "quarter is outside 1-4")
    return PeriodParse(
        original, "Quarterly", f"Q{quarter} {year:04d}", "OK", "High", reason, year, quarter
    )


def _yearly(original: str, year: int, *, confidence: str = "High", reason: str = "four-digit year") -> PeriodParse:
    return PeriodParse(original, "Yearly", f"{year:04d}", "OK", confidence, reason, year, year)


def parse_period(value: Any) -> PeriodParse:
    """Parse one potential period token conservatively.

    A successful parse only standardizes the *label*. It never changes source data.
    Ambiguous labels (for example ``Jan`` or ``P01`` without a year) are returned as
    AMBIGUOUS rather than guessed.
    """
    if value is None or (isinstance(value, str) and not value.strip()):
        return PeriodParse("", "Unknown", None, "NOT_PERIOD", "Low", "blank value")

    if isinstance(value, (datetime, date)):
        return _monthly(
            _text(value), value.year, value.month,
            reason="native Excel/date value; standardized at monthly display level",
        )

    original = _text(value)
    text = re.sub(r"\s+", " ", original.strip())
    compact = text.replace("’", "'")

    # Fiscal labels are intentionally not converted to calendar periods.
    if re.search(r"\bFY\s*\d{2,4}\b", compact, flags=re.IGNORECASE):
        return PeriodParse(
            original, "Fiscal", original, "REVIEW", "Medium",
            "fiscal period detected; calendar mapping requires user confirmation",
        )

    # Bimonthly pairs such as Jan-Feb 2026 / Jan & Feb 2026.
    bim = re.search(
        rf"\b({_MONTH_PATTERN})\s*(?:-|/|&|to)\s*({_MONTH_PATTERN})\s*[-/' ]*({_TWO_OR_FOUR_YEAR})\b",
        compact,
        flags=re.IGNORECASE,
    )
    if bim:
        m1, m2 = _month_number(bim.group(1)), _month_number(bim.group(2))
        year = _year_from_token(bim.group(3))
        if m1 and m2 and year:
            return PeriodParse(
                original,
                "Bimonthly",
                f"{MONTH_ABBR[m1 - 1]}-{MONTH_ABBR[m2 - 1]} {year:04d}",
                "OK",
                "High",
                "two named months plus year",
                year,
                m1,
            )

    # Weekly patterns.
    weekly_patterns = [
        rf"\b(?:W|WK|WEEK)\s*0?(\d{{1,2}})\s*[-/' ]*({_TWO_OR_FOUR_YEAR})\b",
        rf"\b({_FOUR_YEAR})\s*[-/ ]*W(?:K)?\s*0?(\d{{1,2}})\b",
        rf"\b({_FOUR_YEAR})W0?(\d{{1,2}})\b",
    ]
    match = re.search(weekly_patterns[0], compact, flags=re.IGNORECASE)
    if match:
        year = _year_from_token(match.group(2))
        if year:
            return _weekly(original, year, int(match.group(1)), reason="week number plus year")
    for pattern in weekly_patterns[1:]:
        match = re.search(pattern, compact, flags=re.IGNORECASE)
        if match:
            return _weekly(original, int(match.group(1)), int(match.group(2)), reason="year plus week number")

    # Quarterly patterns.
    q = re.search(
        rf"\b(?:Q|QTR|QUARTER)\s*([1-4])\s*[-/' ]*({_TWO_OR_FOUR_YEAR})\b",
        compact,
        flags=re.IGNORECASE,
    )
    if q:
        year = _year_from_token(q.group(2))
        if year:
            return _quarterly(original, year, int(q.group(1)), reason="quarter plus year")
    q = re.search(rf"\b({_FOUR_YEAR})\s*[-/ ]*Q(?:TR)?\s*([1-4])\b", compact, flags=re.IGNORECASE)
    if q:
        return _quarterly(original, int(q.group(1)), int(q.group(2)), reason="year plus quarter")

    # Named month + year, year + named month, including flattened multi-row headers
    # such as "Sales | 2026 | Jan".
    month_year = re.search(
        rf"\b({_MONTH_PATTERN})\b\s*[-/'., ]*({_TWO_OR_FOUR_YEAR})\b",
        compact,
        flags=re.IGNORECASE,
    )
    if month_year:
        month = _month_number(month_year.group(1))
        year = _year_from_token(month_year.group(2))
        if month and year:
            return _monthly(original, year, month, reason="named month plus year")

    # Compact named month + year, e.g. FEB2026 / Apr26. Letters and digits are
    # both word characters, so the boundary-based pattern above does not match.
    compact_month_year = re.fullmatch(
        rf"({_MONTH_PATTERN})({_TWO_OR_FOUR_YEAR})",
        re.sub(r"\s+", "", compact),
        flags=re.IGNORECASE,
    )
    if compact_month_year:
        month = _month_number(compact_month_year.group(1))
        year = _year_from_token(compact_month_year.group(2))
        if month and year:
            return _monthly(original, year, month, reason="compact named month plus year")

    year_month_name = re.search(
        rf"\b({_FOUR_YEAR})\b\s*[-/'., |]*\b({_MONTH_PATTERN})\b",
        compact,
        flags=re.IGNORECASE,
    )
    if year_month_name:
        month = _month_number(year_month_name.group(2))
        if month:
            return _monthly(original, int(year_month_name.group(1)), month, reason="year plus named month")

    # Flattened header may contain extra group labels around year/month. Extract one
    # unambiguous year and one unambiguous month token if present.
    years = [int(y) for y in re.findall(rf"\b({_FOUR_YEAR})\b", compact)]
    month_tokens = re.findall(rf"\b({_MONTH_PATTERN})\b", compact, flags=re.IGNORECASE)
    month_values = [m for token in month_tokens if (m := _month_number(token))]
    if len(set(years)) == 1 and len(set(month_values)) == 1:
        return _monthly(
            original,
            years[0],
            month_values[0],
            reason="one year and one month found within a multi-level header",
            confidence="High",
        )

    # Pure numeric YYYYMM.
    numeric_compact = re.sub(r"\s+", "", compact)
    m = re.fullmatch(r"((?:19|20)\d{2})(0[1-9]|1[0-2])", numeric_compact)
    if m:
        return _monthly(original, int(m.group(1)), int(m.group(2)), reason="YYYYMM period code", confidence="Medium")

    # Numeric month/year or year/month with separators.
    m = re.fullmatch(r"(0?[1-9]|1[0-2])\s*[-/.]\s*([^\s]+)", compact)
    if m:
        year = _year_from_token(m.group(2))
        if year:
            return _monthly(original, year, int(m.group(1)), reason="numeric month/year")
    m = re.fullmatch(rf"({_FOUR_YEAR})\s*[-/.]\s*(0?[1-9]|1[0-2])", compact)
    if m:
        return _monthly(original, int(m.group(1)), int(m.group(2)), reason="numeric year/month")

    # Period codes such as P01 2026: useful recommendation, but user must confirm
    # that P01 really means month 01 for that client.
    p = re.search(rf"\bP(0?[1-9]|1[0-2])\s*[-/' ]*({_TWO_OR_FOUR_YEAR})\b", compact, flags=re.IGNORECASE)
    if p:
        year = _year_from_token(p.group(2))
        month = int(p.group(1))
        if year:
            return PeriodParse(
                original,
                "Period code",
                f"{MONTH_ABBR[month - 1]} {year:04d}",
                "REVIEW",
                "Medium",
                "P01-P12 looks month-like, but interpretation requires user confirmation",
                year,
                month,
            )

    # A bare year is a valid yearly period label, but context will decide whether it
    # is actually a period or simply a Year component.
    if re.fullmatch(_FOUR_YEAR, compact):
        return _yearly(original, int(compact))

    # Ambiguous month/week/quarter/period-code tokens without a year.
    if re.fullmatch(_MONTH_PATTERN, compact, flags=re.IGNORECASE):
        return PeriodParse(
            original, "Monthly", original, "AMBIGUOUS", "Medium",
            "month name detected but no year is available",
            sequence=_month_number(compact),
        )
    w = re.fullmatch(r"(?:W|WK|WEEK)\s*0?(\d{1,2})", compact, flags=re.IGNORECASE)
    if w:
        return PeriodParse(original, "Weekly", original, "AMBIGUOUS", "Medium", "week detected but no year is available", sequence=int(w.group(1)))
    q = re.fullmatch(r"(?:Q|QTR|QUARTER)\s*([1-4])", compact, flags=re.IGNORECASE)
    if q:
        return PeriodParse(original, "Quarterly", original, "AMBIGUOUS", "Medium", "quarter detected but no year is available", sequence=int(q.group(1)))
    p = re.fullmatch(r"P(0?[1-9]|1[0-2])", compact, flags=re.IGNORECASE)
    if p:
        return PeriodParse(original, "Period code", original, "AMBIGUOUS", "Medium", "P01-P12 detected but no year is available; mapping is client-specific", sequence=int(p.group(1)))

    return PeriodParse(original, "Unknown", None, "NOT_PERIOD", "Low", "no safe period pattern detected")


def _header_collision_findings(mappings: list[tuple[str, PeriodParse]]) -> list[PeriodCollision]:
    grouped: dict[str, list[str]] = {}
    for source, parsed in mappings:
        if parsed.standard and parsed.status in {"OK", "REVIEW"}:
            grouped.setdefault(parsed.standard, []).append(source)
    collisions: list[PeriodCollision] = []
    for standard, sources in grouped.items():
        if len(sources) > 1:
            collisions.append(
                PeriodCollision(
                    standard,
                    sources,
                    "multiple source period fields resolve to the same standard label; no merge is allowed automatically",
                )
            )
    return collisions


def _read_sheet_values(
    path: Path,
    sheet_name: str,
    *,
    max_rows: int = 500,
    max_columns: int = 512,
) -> list[list[Any]]:
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        keep_vba = path.suffix.lower() == ".xlsm"
        try:
            wb = load_workbook(
                path,
                read_only=True,
                data_only=False,
                keep_vba=keep_vba,
                keep_links=True,
            )
        except Exception as exc:
            raise ShipmentReadError(f"Could not read workbook '{path.name}': {exc}") from exc
        try:
            if sheet_name not in wb.sheetnames:
                raise ShipmentReadError(f"Sheet not found: {sheet_name}")
            ws = wb[sheet_name]
            rows = ws.iter_rows(
                min_row=1,
                max_row=min(int(ws.max_row or 0), max_rows),
                min_col=1,
                max_col=min(int(ws.max_column or 0), max_columns),
                values_only=True,
            )
            return [list(row) for row in rows]
        finally:
            wb.close()

    # CSV: inventory handles encoding/delimiter. Use a larger preview for scan rows.
    inv = inventory_file(path, preview_rows=max_rows)
    return [list(row[:max_columns]) for row in inv.sheets[0].preview]


def _flatten_for_header_rows(rows: list[list[Any]], candidate: HeaderCandidate) -> list[str]:
    # Reuse the scanner's already-computed flattened headers. It is authoritative for
    # Step 7C and avoids duplicating multi-row fill logic here.
    return list(candidate.flattened_headers)


def _values_below_header(rows: list[list[Any]], header_end_row: int, width: int) -> list[list[Any]]:
    return [list(row[:width]) + [None] * max(0, width - len(row)) for row in rows[header_end_row:]]


def _unique_period_mappings(values: Iterable[Any], limit: int = 40) -> list[PeriodParse]:
    result: list[PeriodParse] = []
    seen: set[tuple[str, str | None, str]] = set()
    for value in values:
        parsed = parse_period(value)
        key = (parsed.original, parsed.standard, parsed.status)
        if key not in seen and parsed.status != "NOT_PERIOD":
            seen.add(key)
            result.append(parsed)
            if len(result) >= limit:
                break
    return result


def _is_year_component(values: list[Any]) -> bool:
    nonblank = [v for v in values if _text(v)]
    if len(nonblank) < 2:
        return False
    valid = 0
    for value in nonblank:
        t = _text(value)
        if re.fullmatch(_FOUR_YEAR, t):
            valid += 1
    return valid / len(nonblank) >= 0.8


def _month_component(value: Any) -> int | None:
    t = _text(value).strip()
    m = _month_number(t)
    if m:
        return m
    if re.fullmatch(r"0?[1-9]|1[0-2]", t):
        return int(t)
    p = re.fullmatch(r"P(0?[1-9]|1[0-2])", t, flags=re.IGNORECASE)
    if p:
        # P01 is only a recommendation, not an automatic monthly interpretation.
        return int(p.group(1))
    return None


def _week_component(value: Any) -> int | None:
    t = _text(value).strip()
    m = re.fullmatch(r"(?:W|WK|WEEK)?\s*0?(\d{1,2})", t, flags=re.IGNORECASE)
    if not m:
        return None
    week = int(m.group(1))
    return week if 1 <= week <= 53 else None


def _quarter_component(value: Any) -> int | None:
    t = _text(value).strip()
    m = re.fullmatch(r"(?:Q|QTR|QUARTER)?\s*([1-4])", t, flags=re.IGNORECASE)
    return int(m.group(1)) if m else None


def _component_ratio(values: list[Any], parser) -> float:
    nonblank = [v for v in values if _text(v)]
    if len(nonblank) < 2:
        return 0.0
    return sum(parser(v) is not None for v in nonblank) / len(nonblank)


def _combine_component_columns(
    headers: list[str],
    data_rows: list[list[Any]],
) -> list[PeriodFinding]:
    if not headers or not data_rows:
        return []
    width = len(headers)
    columns = [[row[i] if i < len(row) else None for row in data_rows] for i in range(width)]

    year_candidates: list[int] = []
    month_candidates: list[int] = []
    week_candidates: list[int] = []
    quarter_candidates: list[int] = []

    for idx, (header, values) in enumerate(zip(headers, columns)):
        if _IDENTIFIER_HEADER_RE.search(header):
            continue
        if _YEAR_HEADER_RE.search(header) or _is_year_component(values):
            if _is_year_component(values):
                year_candidates.append(idx)
        month_ratio = _component_ratio(values, _month_component)
        week_ratio = _component_ratio(values, _week_component)
        quarter_ratio = _component_ratio(values, _quarter_component)
        if (_MONTH_HEADER_RE.search(header) or re.search(r"\bperiod\b", header, re.I)) and month_ratio >= 0.8:
            month_candidates.append(idx)
        if _WEEK_HEADER_RE.search(header) and week_ratio >= 0.8:
            week_candidates.append(idx)
        if _QUARTER_HEADER_RE.search(header) and quarter_ratio >= 0.8:
            quarter_candidates.append(idx)

    findings: list[PeriodFinding] = []
    for year_idx in year_candidates:
        year_header = headers[year_idx]
        for component_idx, frequency in [
            *[(i, "Monthly") for i in month_candidates],
            *[(i, "Weekly") for i in week_candidates],
            *[(i, "Quarterly") for i in quarter_candidates],
        ]:
            if component_idx == year_idx:
                continue
            component_header = headers[component_idx]
            mappings: list[PeriodParse] = []
            seen: set[str] = set()
            uses_p_codes = False
            for row in data_rows:
                year_text = _text(row[year_idx] if year_idx < len(row) else None)
                if not re.fullmatch(_FOUR_YEAR, year_text):
                    continue
                year = int(year_text)
                comp_value = row[component_idx] if component_idx < len(row) else None
                comp_text = _text(comp_value)
                if not comp_text:
                    continue
                if frequency == "Monthly":
                    seq = _month_component(comp_value)
                    if seq is None:
                        continue
                    if re.fullmatch(r"P(?:0?[1-9]|1[0-2])", comp_text, flags=re.IGNORECASE):
                        uses_p_codes = True
                        parsed = PeriodParse(
                            f"{year_text} + {comp_text}",
                            "Period code",
                            f"{MONTH_ABBR[seq - 1]} {year:04d}",
                            "REVIEW",
                            "Medium",
                            "P01-P12 plus year looks month-like; user confirmation is required",
                            year,
                            seq,
                        )
                    else:
                        parsed = _monthly(f"{year_text} + {comp_text}", year, seq, reason="separate Year + Month columns")
                elif frequency == "Weekly":
                    seq = _week_component(comp_value)
                    if seq is None:
                        continue
                    parsed = _weekly(f"{year_text} + {comp_text}", year, seq, reason="separate Year + Week columns")
                else:
                    seq = _quarter_component(comp_value)
                    if seq is None:
                        continue
                    parsed = _quarterly(f"{year_text} + {comp_text}", year, seq, reason="separate Year + Quarter columns")
                key = parsed.standard or parsed.original
                if key not in seen:
                    seen.add(key)
                    mappings.append(parsed)
                    if len(mappings) >= 40:
                        break
            if mappings:
                status = "REVIEW" if uses_p_codes else "OK"
                findings.append(
                    PeriodFinding(
                        location="COMBINED_COLUMNS",
                        source=f"{year_header} + {component_header}",
                        frequency=frequency if not uses_p_codes else "Period code",
                        status=status,
                        confidence="High" if not uses_p_codes else "Medium",
                        mappings=mappings,
                        detail=(
                            "separate year and period-component columns can form one standardized period"
                            if not uses_p_codes
                            else "P01-P12 pattern detected with year; user must confirm that P01 means January"
                        ),
                        source_columns=[year_header, component_header],
                    )
                )
    return findings


def _scan_row_period_columns(headers: list[str], data_rows: list[list[Any]]) -> list[PeriodFinding]:
    if not headers or not data_rows:
        return []
    findings: list[PeriodFinding] = []
    width = len(headers)
    for idx in range(width):
        header = headers[idx]
        if _IDENTIFIER_HEADER_RE.search(header):
            continue
        values = [row[idx] if idx < len(row) else None for row in data_rows]
        nonblank = [v for v in values if _text(v)]
        if len(nonblank) < 2:
            continue
        parsed = [parse_period(v) for v in nonblank]
        recognized = [p for p in parsed if p.status in {"OK", "REVIEW", "AMBIGUOUS"}]
        ratio = len(recognized) / len(nonblank)

        # Year-only columns are usually components, not a complete period field. They
        # are handled by Year + Month/Week/Quarter detection above.
        frequencies = {p.frequency for p in recognized if p.status != "NOT_PERIOD"}
        if frequencies == {"Yearly"} and (_YEAR_HEADER_RE.search(header) or ratio >= 0.8):
            continue

        header_hint = bool(_PERIOD_HEADER_HINT_RE.search(header))
        if ratio < 0.8 or (not header_hint and ratio < 0.95):
            continue

        unique = _unique_period_mappings(nonblank)
        if not unique:
            continue
        good_freqs = [p.frequency for p in unique if p.frequency != "Unknown"]
        frequency = max(set(good_freqs), key=good_freqs.count) if good_freqs else "Unknown"
        status = "AMBIGUOUS" if any(p.status == "AMBIGUOUS" for p in unique) else (
            "REVIEW" if any(p.status == "REVIEW" for p in unique) else "OK"
        )
        findings.append(
            PeriodFinding(
                location="ROW_COLUMN",
                source=header,
                frequency=frequency,
                status=status,
                confidence="High" if header_hint and ratio >= 0.95 else "Medium",
                mappings=unique,
                detail=f"{len(recognized)}/{len(nonblank)} sampled values are period-like",
                source_columns=[header],
            )
        )
    return findings


def scan_sheet_periods(
    file_path: str | Path,
    sheet_name: str,
    *,
    header_scan: SheetHeaderScan | None = None,
    max_scan_rows: int = 500,
    max_scan_columns: int = 512,
) -> SheetPeriodScan:
    """Scan one sheet for period structures without altering the source."""
    path = validate_source_path(file_path)
    if header_scan is None:
        header_scan = scan_sheet_headers(
            path,
            sheet_name,
            max_scan_rows=min(40, max_scan_rows),
            max_scan_columns=max_scan_columns,
        )
    candidate = header_scan.recommended
    warnings: list[str] = []
    findings: list[PeriodFinding] = []
    collisions: list[PeriodCollision] = []

    rows = _read_sheet_values(path, sheet_name, max_rows=max_scan_rows, max_columns=max_scan_columns)

    if candidate is None:
        warnings.append("no reliable header recommendation is available; row/column period scanning is limited")
        sheet_parse = parse_period(sheet_name)
        if sheet_parse.status != "NOT_PERIOD":
            findings.append(
                PeriodFinding(
                    "SHEET_NAME", sheet_name, sheet_parse.frequency, sheet_parse.status,
                    sheet_parse.confidence, [sheet_parse], "sheet name looks period-like", []
                )
            )
        return SheetPeriodScan(sheet_name, None, None, findings, collisions, warnings)

    headers = _flatten_for_header_rows(rows, candidate)
    width = len(headers)

    # 1) Periods embedded in header columns.
    header_periods: list[tuple[str, PeriodParse]] = []
    for index, header in enumerate(headers, start=1):
        parsed = parse_period(header)
        if parsed.status != "NOT_PERIOD":
            source = f"Column {index}: {header}"
            header_periods.append((source, parsed))
    if header_periods:
        mappings = [parsed for _, parsed in header_periods]
        frequencies = [p.frequency for p in mappings if p.frequency != "Unknown"]
        freq = max(set(frequencies), key=frequencies.count) if frequencies else "Unknown"
        status = "AMBIGUOUS" if any(p.status == "AMBIGUOUS" for p in mappings) else (
            "REVIEW" if any(p.status == "REVIEW" for p in mappings) else "OK"
        )
        confidence = "High" if len(header_periods) >= 2 and status == "OK" else "Medium"
        findings.append(
            PeriodFinding(
                location="COLUMN_HEADER",
                source="period-like header columns",
                frequency=freq,
                status=status,
                confidence=confidence,
                mappings=mappings,
                detail=f"{len(header_periods)} period-like header field(s) detected",
                source_columns=[source for source, _ in header_periods],
            )
        )
        collisions.extend(_header_collision_findings(header_periods))
        if len(header_periods) == 1:
            warnings.append("only one period-like header was detected; user confirmation is recommended")

    # 2) Periods in rows, including separate Year + Month/Week/Quarter fields.
    data_rows = _values_below_header(rows, candidate.end_row, width)
    combined = _combine_component_columns(headers, data_rows)
    findings.extend(combined)

    combined_columns = {col for finding in combined for col in finding.source_columns}
    row_findings = _scan_row_period_columns(headers, data_rows)
    # Suppress a component column if it is already part of a stronger combined finding.
    row_findings = [f for f in row_findings if not all(col in combined_columns for col in f.source_columns)]
    findings.extend(row_findings)

    # 3) Sheet name may itself represent the period for sheet-per-period layouts.
    sheet_parse = parse_period(sheet_name)
    if sheet_parse.status != "NOT_PERIOD":
        # A bare year as a sheet name is useful but less certain than a full month/week/quarter.
        confidence = "Medium" if sheet_parse.frequency == "Yearly" else sheet_parse.confidence
        findings.append(
            PeriodFinding(
                location="SHEET_NAME",
                source=sheet_name,
                frequency=sheet_parse.frequency,
                status=sheet_parse.status,
                confidence=confidence,
                mappings=[sheet_parse],
                detail="sheet name is period-like and could be used for a sheet-per-period layout after user confirmation",
                source_columns=[],
            )
        )

    if not findings:
        warnings.append("no safe period structure was detected automatically")

    return SheetPeriodScan(
        sheet_name=sheet_name,
        header_start_row=candidate.start_row,
        header_end_row=candidate.end_row,
        findings=findings,
        collisions=collisions,
        warnings=warnings,
    )


def scan_workbook_periods(
    file_path: str | Path,
    *,
    max_scan_rows: int = 500,
    max_scan_columns: int = 512,
) -> WorkbookPeriodScan:
    """Scan every sheet/table for period structures."""
    path = validate_source_path(file_path)
    inv = inventory_file(path, preview_rows=0)
    scans: list[SheetPeriodScan] = []
    for sheet in inv.sheets:
        header = scan_sheet_headers(
            path,
            sheet.name,
            max_scan_rows=min(40, max_scan_rows),
            max_scan_columns=max_scan_columns,
        )
        scans.append(
            scan_sheet_periods(
                path,
                sheet.name,
                header_scan=header,
                max_scan_rows=max_scan_rows,
                max_scan_columns=max_scan_columns,
            )
        )
    return WorkbookPeriodScan(path.name, scans)
