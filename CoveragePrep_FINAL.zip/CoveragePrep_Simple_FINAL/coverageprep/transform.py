"""In-memory transformation engine for CoveragePrep Simple Step 7D.

7D deliberately does NOT export files or claim final validation. It proves the core
mapping + one-fact transformation behavior in memory so validation/export can be
added independently in later steps.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import csv
import re
import numbers

import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from .reader import ShipmentReadError, inventory_file, validate_source_path
from .scanner import HeaderCandidate, SheetHeaderScan, scan_sheet_headers
from .periods import PeriodFinding, SheetPeriodScan, parse_period, scan_sheet_periods
from .mapping import detect_single_fact, order_headers_by_role, suggest_field_roles


class TransformationBlocked(RuntimeError):
    """Raised when transforming would require an unsafe assumption/aggregation."""


@dataclass(frozen=True)
class SourceColumn:
    position: int
    internal_name: str
    source_header: str
    flattened_header: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class LoadedTable:
    sheet_name: str
    header_start_row: int
    header_end_row: int
    frame: pd.DataFrame
    columns: list[SourceColumn]


@dataclass(frozen=True)
class FactLineage:
    source_sheet: str
    source_row: int
    source_column: str
    source_header: str
    source_period: str
    standard_period: str
    fact_label: str
    source_value: Any
    dimensions: dict[str, Any]
    expected_value: Any = None
    included_in_output: bool = True
    action: str = "keep"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class TransformationPreview:
    sheet_name: str
    layout: str
    fact_label: str
    prepared_data: pd.DataFrame
    field_roles: dict[str, str]
    period_map: list[dict[str, Any]]
    warnings: list[str]
    lineage: list[FactLineage]
    fact_source_header: str | None = None
    header_start_row: int | None = None
    header_end_row: int | None = None
    period_source_columns: list[str] | None = None
    negative_policy: str = "keep"
    duplicate_policy: str = "keep"


def _read_rows(path: Path, sheet_name: str) -> list[list[Any]]:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        keep_vba = suffix == ".xlsm"
        try:
            wb = load_workbook(path, read_only=True, data_only=False, keep_vba=keep_vba, keep_links=True)
        except Exception as exc:
            raise ShipmentReadError(f"Could not read workbook '{path.name}': {exc}") from exc
        try:
            ws = wb[sheet_name]
            return [list(row) for row in ws.iter_rows(values_only=True)]
        finally:
            wb.close()

    inv = inventory_file(path, preview_rows=0)
    # CSV text handling follows reader's encoding strategy indirectly via pandas.
    # sep=None lets Python's parser infer common delimiters.
    try:
        df = pd.read_csv(path, header=None, sep=None, engine="python", dtype=object)
    except UnicodeDecodeError:
        df = pd.read_csv(path, header=None, sep=None, engine="python", dtype=object, encoding="latin-1")
    return df.where(pd.notna(df), None).values.tolist()


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _leaf_headers(rows: list[list[Any]], candidate: HeaderCandidate, width: int) -> list[str]:
    """Use the lowest visible header cell when unique; preserve full path if needed."""
    bottom = rows[candidate.end_row - 1] if candidate.end_row - 1 < len(rows) else []
    raw_leaf = [_text(bottom[i]) if i < len(bottom) else "" for i in range(width)]
    flattened = list(candidate.flattened_headers)

    # Empty leaf cells inherit a readable source path. Duplicate leaf names also use
    # the flattened path so we never silently merge two distinct source columns.
    counts: dict[str, int] = {}
    for leaf in raw_leaf:
        if leaf:
            counts[leaf.casefold()] = counts.get(leaf.casefold(), 0) + 1

    output: list[str] = []
    for i in range(width):
        leaf = raw_leaf[i]
        if leaf and counts.get(leaf.casefold(), 0) == 1:
            output.append(leaf)
        else:
            output.append(flattened[i] if i < len(flattened) and flattened[i] else f"Column {i + 1}")
    return output


def _make_unique(names: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    result: list[str] = []
    for name in names:
        base = name or "Column"
        key = base.casefold()
        seen[key] = seen.get(key, 0) + 1
        result.append(base if seen[key] == 1 else f"{base}__{seen[key]}")
    return result


def load_table(
    file_path: str | Path,
    sheet_name: str,
    *,
    header_scan: SheetHeaderScan | None = None,
) -> LoadedTable:
    """Load one selected sheet using the confirmed/recommended header range."""
    path = validate_source_path(file_path)
    header_scan = header_scan or scan_sheet_headers(path, sheet_name)
    candidate = header_scan.recommended
    if candidate is None:
        raise TransformationBlocked(f"No confirmed header is available for sheet '{sheet_name}'.")

    rows = _read_rows(path, sheet_name)
    width = len(candidate.flattened_headers)
    flattened = list(candidate.flattened_headers)
    source_headers = _leaf_headers(rows, candidate, width)
    internal = _make_unique(flattened)

    body = []
    for row in rows[candidate.end_row:]:
        vals = list(row[:width]) + [None] * max(0, width - len(row))
        # Ignore completely blank trailing rows only.
        if any(v is not None and str(v).strip() != "" for v in vals):
            body.append(vals[:width])

    frame = pd.DataFrame(body, columns=internal)
    columns = [
        SourceColumn(i + 1, internal[i], source_headers[i], flattened[i])
        for i in range(width)
    ]
    return LoadedTable(sheet_name, candidate.start_row, candidate.end_row, frame, columns)


def _period_sort_key(label: str) -> tuple[int, int, str]:
    parsed = parse_period(label)
    year = parsed.year if parsed.year is not None else 9999
    seq = parsed.sequence if parsed.sequence is not None else 99
    frequency_order = {"Monthly": 1, "Bimonthly": 2, "Weekly": 3, "Quarterly": 4, "Yearly": 5}.get(parsed.frequency, 9)
    return (year, frequency_order * 100 + seq, label)


def _best_period_finding(scan: SheetPeriodScan, *, accept_period_codes: bool = False) -> PeriodFinding:
    if scan.collisions:
        raise TransformationBlocked("Period collisions exist; they must be resolved before transformation.")

    priority = {"COLUMN_HEADER": 1, "COMBINED_COLUMNS": 2, "ROW_COLUMN": 3, "SHEET_NAME": 4}
    safe = [f for f in scan.findings if f.status == "OK"]
    if not safe and accept_period_codes:
        safe = [
            f for f in scan.findings
            if f.status == "REVIEW"
            and f.frequency == "Period code"
            and f.mappings
            and all(m.standard for m in f.mappings)
        ]
    if not safe:
        review = [f for f in scan.findings if f.status == "REVIEW"]
        if review:
            raise TransformationBlocked("Period interpretation requires user confirmation before transformation.")
        raise TransformationBlocked("No safe period structure is available for transformation.")
    safe.sort(key=lambda f: priority.get(f.location, 99))
    return safe[0]


def _column_lookup(table: LoadedTable) -> dict[str, SourceColumn]:
    lookup: dict[str, SourceColumn] = {}
    for col in table.columns:
        lookup[col.flattened_header] = col
        lookup[col.source_header] = col
        lookup[col.internal_name] = col
    return lookup


def _role_assignments_for_columns(columns: list[SourceColumn], exclude_internal: set[str]) -> dict[str, str]:
    headers = [c.source_header for c in columns if c.internal_name not in exclude_internal]
    suggestions = suggest_field_roles(headers)
    return {s.source_header: s.role for s in suggestions}


def _rename_dimensions_to_source(frame: pd.DataFrame, columns: list[SourceColumn]) -> pd.DataFrame:
    rename = {c.internal_name: c.source_header for c in columns if c.internal_name in frame.columns}
    return frame.rename(columns=rename)


def _ensure_no_duplicate_keys(frame: pd.DataFrame, key_columns: list[str], period_col: str) -> None:
    if not key_columns:
        # A table containing only period + value still must have one value per period.
        dup = frame.duplicated(subset=[period_col], keep=False)
    else:
        dup = frame.duplicated(subset=key_columns + [period_col], keep=False)
    if dup.any():
        count = int(dup.sum())
        raise TransformationBlocked(
            f"{count} row(s) share the same dimension + period key. Pivoting would require aggregation; add a distinguishing field or review the source."
        )


def _is_nonblank(value: Any) -> bool:
    if value is None:
        return False
    try:
        if pd.isna(value):
            return False
    except Exception:
        pass
    return not (isinstance(value, str) and value.strip() == "")


def _apply_negative_policy(value: Any, policy: str) -> tuple[Any, str]:
    if policy not in {"keep", "absolute", "zero"}:
        raise ValueError("negative_policy must be 'keep', 'absolute', or 'zero'")
    if value is None or isinstance(value, bool):
        return value, "keep"
    numeric = None
    if isinstance(value, numbers.Number):
        numeric = value
    elif isinstance(value, str):
        try:
            numeric = float(value.strip().replace(",", ""))
        except Exception:
            numeric = None
    if numeric is None or numeric >= 0:
        return value, "keep"
    if policy == "keep":
        return value, "keep_negative"
    if policy == "absolute":
        transformed = abs(numeric)
        if isinstance(value, numbers.Integral):
            transformed = int(transformed)
        return transformed, "negative_to_absolute"
    return 0, "negative_to_zero"


def _row_dimensions(table: LoadedTable, row_index: int, dims: list[SourceColumn]) -> dict[str, Any]:
    return {col.source_header: table.frame.iloc[row_index][col.internal_name] for col in dims}


def transform_selected_sheet(
    file_path: str | Path,
    sheet_name: str,
    *,
    fact_label: str | None = None,
    fact_source_header: str | None = None,
    field_role_overrides: dict[str, str] | None = None,
    period_order: str = "ascending",
    negative_policy: str = "keep",
    duplicate_policy: str = "keep",
    accept_period_codes: bool = False,
    header_scan: SheetHeaderScan | None = None,
    period_scan: SheetPeriodScan | None = None,
) -> TransformationPreview:
    """Create an in-memory prepared-data preview for one selected sheet.

    No files are written. No aggregation is performed.
    """
    path = validate_source_path(file_path)
    header_scan = header_scan or scan_sheet_headers(path, sheet_name)
    period_scan = period_scan or scan_sheet_periods(path, sheet_name, header_scan=header_scan)
    finding = _best_period_finding(period_scan, accept_period_codes=accept_period_codes)
    table = load_table(path, sheet_name, header_scan=header_scan)
    if duplicate_policy not in {"keep", "drop_exact"}:
        raise ValueError("duplicate_policy must be 'keep' or 'drop_exact'")
    original_frame = table.frame.copy()
    duplicate_mask = original_frame.duplicated(keep="first") if not original_frame.empty else pd.Series([], dtype=bool)
    if duplicate_policy == "drop_exact" and len(duplicate_mask):
        table.frame = original_frame.loc[~duplicate_mask].copy()
    lookup = _column_lookup(table)
    warnings: list[str] = []
    period_map: list[dict[str, Any]] = []
    lineage: list[FactLineage] = []

    if finding.location == "COLUMN_HEADER":
        period_internal: list[str] = []
        rename_periods: dict[str, str] = {}
        standards: list[str] = []
        for col in table.columns:
            parsed = parse_period(col.flattened_header)
            if parsed.standard and (parsed.status == "OK" or (accept_period_codes and parsed.status == "REVIEW" and parsed.frequency == "Period code")):
                period_internal.append(col.internal_name)
                rename_periods[col.internal_name] = parsed.standard
                standards.append(parsed.standard)
                period_map.append({
                    "original": col.flattened_header,
                    "standard": parsed.standard,
                    "frequency": parsed.frequency,
                    "status": parsed.status,
                })
        if not period_internal:
            raise TransformationBlocked("No safe period columns were found in the loaded table.")
        if len(set(standards)) != len(standards):
            raise TransformationBlocked("Two source period columns resolve to the same standard label; automatic merge is blocked.")
        formula_cells = 0
        for internal_name in period_internal:
            formula_cells += sum(
                1 for v in table.frame[internal_name].tolist()
                if isinstance(v, str) and v.startswith("=")
            )
        if formula_cells:
            raise TransformationBlocked(
                f"{formula_cells} formula-derived fact cell(s) detected in period values. "
                "They are preserved in source evidence but are not transformed automatically in this simple build."
            )

        dims = [c for c in table.columns if c.internal_name not in set(period_internal)]
        role_assignments = _role_assignments_for_columns(table.columns, set(period_internal))
        if field_role_overrides:
            role_assignments.update(field_role_overrides)
        ordered_dim_headers = order_headers_by_role([c.source_header for c in dims], role_assignments)
        internal_by_source = {c.source_header: c.internal_name for c in dims}
        ordered_internal = [internal_by_source[h] for h in ordered_dim_headers]

        prepared = table.frame[ordered_internal + period_internal].copy()
        prepared = _rename_dimensions_to_source(prepared, dims)
        prepared = prepared.rename(columns=rename_periods)
        if negative_policy != "keep":
            for period_name in standards:
                prepared[period_name] = prepared[period_name].map(lambda v: _apply_negative_policy(v, negative_policy)[0])

        actual_fact_label = (fact_label or "").strip()
        if not actual_fact_label:
            raise TransformationBlocked("Wide-period structure detected, but FACT label is not known. User must provide/confirm one fact label.")
        prepared.insert(len(ordered_dim_headers), "FACT", actual_fact_label)

        sorted_periods = list(standards)
        if period_order == "ascending":
            sorted_periods = sorted(sorted_periods, key=_period_sort_key)
        elif period_order == "descending":
            sorted_periods = sorted(sorted_periods, key=_period_sort_key, reverse=True)
        elif period_order != "source":
            raise ValueError("period_order must be 'ascending', 'descending', or 'source'")
        prepared = prepared[ordered_dim_headers + ["FACT"] + sorted_periods]

        # Build one lineage record for every nonblank source fact cell. Source row
        # numbers are 1-based workbook row numbers and source columns use Excel letters.
        period_cols_by_internal = {c.internal_name: c for c in table.columns if c.internal_name in set(period_internal)}
        for pos in range(len(table.frame)):
            original_index = int(table.frame.index[pos])
            dims_map = _row_dimensions(table, pos, dims)
            source_row = table.header_end_row + 1 + original_index
            for internal_name in period_internal:
                value = table.frame.iloc[pos][internal_name]
                if not _is_nonblank(value):
                    continue
                col = period_cols_by_internal[internal_name]
                standard = rename_periods[internal_name]
                expected, action = _apply_negative_policy(value, negative_policy)
                lineage.append(FactLineage(
                    source_sheet=sheet_name,
                    source_row=source_row,
                    source_column=get_column_letter(col.position),
                    source_header=col.flattened_header,
                    source_period=col.flattened_header,
                    standard_period=standard,
                    fact_label=actual_fact_label,
                    source_value=value,
                    dimensions=dims_map,
                    expected_value=expected,
                    included_in_output=True,
                    action=action,
                ))

        if duplicate_policy == "drop_exact" and duplicate_mask.any():
            warnings.append(f"{int(duplicate_mask.sum())} exact duplicate source row(s) excluded from Prepared_Data by explicit user choice")
        return TransformationPreview(
            sheet_name, "WIDE_PERIODS", actual_fact_label, prepared, role_assignments, period_map, warnings, lineage,
            fact_source_header=None, header_start_row=table.header_start_row, header_end_row=table.header_end_row,
            period_source_columns=[period_cols_by_internal[i].source_header for i in period_internal],
            negative_policy=negative_policy, duplicate_policy=duplicate_policy,
        )

    # Row/combined/sheet-name period layouts share a single source value column.
    period_source_names = list(finding.source_columns)
    period_internal: list[str] = []
    for source_name in period_source_names:
        if source_name not in lookup:
            raise TransformationBlocked(f"Period source column '{source_name}' could not be matched to the loaded table.")
        period_internal.append(lookup[source_name].internal_name)

    exclude_internal = set(period_internal)
    roles = _role_assignments_for_columns(table.columns, exclude_internal)
    if field_role_overrides:
        roles.update(field_role_overrides)

    # Fact detection uses source-display headers, so make a temporary source-named frame.
    source_frame = _rename_dimensions_to_source(table.frame.copy(), table.columns)
    fact_detection = detect_single_fact(
        source_frame,
        layout="SHEET_PERIOD" if finding.location == "SHEET_NAME" else "ROW_PERIODS",
        period_source_columns=[lookup[p].source_header if p in lookup else p for p in period_source_names],
        assigned_roles=roles,
        sheet_name=sheet_name,
    )
    selected_fact_source = fact_source_header or fact_detection.source_column
    if not selected_fact_source:
        raise TransformationBlocked(fact_detection.reason)
    if fact_source_header and fact_source_header not in source_frame.columns:
        raise TransformationBlocked(f"User-selected fact column '{fact_source_header}' does not exist in the loaded table.")
    if not fact_source_header and fact_detection.status == "BLOCKER":
        raise TransformationBlocked(fact_detection.reason)

    fact_col = next((c for c in table.columns if c.source_header == selected_fact_source), None)
    if fact_col is None:
        raise TransformationBlocked(f"Fact column '{selected_fact_source}' could not be resolved uniquely.")
    fact_internal = fact_col.internal_name
    formula_cells = sum(
        1 for v in table.frame[fact_internal].tolist()
        if isinstance(v, str) and v.startswith("=")
    )
    if formula_cells:
        raise TransformationBlocked(
            f"{formula_cells} formula-derived fact cell(s) detected in '{fact_col.source_header}'. "
            "They are preserved in source evidence but are not transformed automatically in this simple build."
        )
    actual_fact_label = (fact_label or (selected_fact_source if fact_source_header else fact_detection.suggested_fact_label) or "").strip()
    if not actual_fact_label:
        raise TransformationBlocked("FACT label is not known. User must provide/confirm it.")

    excluded = exclude_internal | {fact_internal}
    dims = [c for c in table.columns if c.internal_name not in excluded]
    ordered_dim_headers = order_headers_by_role([c.source_header for c in dims], roles)
    internal_by_source = {c.source_header: c.internal_name for c in dims}
    ordered_dim_internal = [internal_by_source[h] for h in ordered_dim_headers]

    work = table.frame[ordered_dim_internal + period_internal + [fact_internal]].copy()
    work = _rename_dimensions_to_source(work, dims)

    if finding.location == "ROW_COLUMN":
        period_col_internal = period_internal[0]
        values = table.frame[period_col_internal]
        standards = []
        for value in values.tolist():
            parsed = parse_period(value)
            if not parsed.standard or (parsed.status != "OK" and not (accept_period_codes and parsed.status == "REVIEW" and parsed.frequency == "Period code")):
                raise TransformationBlocked(f"Ambiguous/unrecognized period value '{value}' requires review before pivoting.")
            standards.append(parsed.standard)
            period_map.append({"original": str(value), "standard": parsed.standard, "frequency": parsed.frequency, "status": parsed.status})
        work["__PERIOD__"] = standards

    elif finding.location == "COMBINED_COLUMNS":
        year_col = period_internal[0]
        comp_col = period_internal[1]
        standards = []
        for year, comp in zip(table.frame[year_col].tolist(), table.frame[comp_col].tolist()):
            comp_text = str(comp).strip()
            combined = f"{comp_text} {year}" if re.fullmatch(r"P(?:0?[1-9]|1[0-2])", comp_text, flags=re.IGNORECASE) else f"{year} {comp}"
            parsed = parse_period(combined)
            if not parsed.standard or (parsed.status != "OK" and not (accept_period_codes and parsed.status == "REVIEW" and parsed.frequency == "Period code")):
                raise TransformationBlocked(f"Could not safely combine period values '{year}' + '{comp}'.")
            standards.append(parsed.standard)
            period_map.append({"original": f"{year} + {comp}", "standard": parsed.standard, "frequency": parsed.frequency, "status": parsed.status})
        work["__PERIOD__"] = standards

    elif finding.location == "SHEET_NAME":
        parsed = parse_period(sheet_name)
        if parsed.status != "OK" or not parsed.standard:
            raise TransformationBlocked("Sheet-name period requires confirmation before transformation.")
        work["__PERIOD__"] = parsed.standard
        period_map.append({"original": sheet_name, "standard": parsed.standard, "frequency": parsed.frequency, "status": parsed.status})
    else:
        raise TransformationBlocked(f"Unsupported period layout: {finding.location}")

    # Put fact values under a technical temporary name. Negative values change only
    # when the user explicitly selected a policy. Original values remain in lineage.
    work["__FACT_VALUE__"] = [
        _apply_negative_policy(v, negative_policy)[0] for v in table.frame[fact_internal].tolist()
    ]
    dim_headers = ordered_dim_headers
    _ensure_no_duplicate_keys(work, dim_headers, "__PERIOD__")

    period_labels = list(dict.fromkeys(work["__PERIOD__"].tolist()))
    if period_order == "ascending":
        period_labels = sorted(period_labels, key=_period_sort_key)
    elif period_order == "descending":
        period_labels = sorted(period_labels, key=_period_sort_key, reverse=True)
    elif period_order != "source":
        raise ValueError("period_order must be 'ascending', 'descending', or 'source'")

    if dim_headers:
        wide = work.set_index(dim_headers + ["__PERIOD__"])["__FACT_VALUE__"].unstack("__PERIOD__")
        wide = wide.reset_index()
    else:
        wide = work.set_index("__PERIOD__")["__FACT_VALUE__"].to_frame().T
        wide.index = [0]

    for label in period_labels:
        if label not in wide.columns:
            wide[label] = pd.NA
    wide.insert(len(dim_headers), "FACT", actual_fact_label)
    wide = wide[dim_headers + ["FACT"] + period_labels]

    if fact_detection.status == "REVIEW":
        warnings.append(f"Fact column recommendation requires user confirmation: {selected_fact_source}")

    # Each source row contributes at most one fact value in row-period layouts.
    for pos in range(len(table.frame)):
        original_index = int(table.frame.index[pos])
        value = table.frame.iloc[pos][fact_internal]
        if not _is_nonblank(value):
            continue
        source_row = table.header_end_row + 1 + original_index
        dims_map = _row_dimensions(table, pos, dims)
        standard = work.iloc[pos]["__PERIOD__"]
        if finding.location == "ROW_COLUMN":
            source_period = str(table.frame.iloc[pos][period_internal[0]])
        elif finding.location == "COMBINED_COLUMNS":
            source_period = " + ".join(str(table.frame.iloc[pos][c]) for c in period_internal)
        else:
            source_period = sheet_name
        expected, action = _apply_negative_policy(value, negative_policy)
        lineage.append(FactLineage(
            source_sheet=sheet_name,
            source_row=source_row,
            source_column=get_column_letter(fact_col.position),
            source_header=fact_col.source_header,
            source_period=source_period,
            standard_period=str(standard),
            fact_label=actual_fact_label,
            source_value=value,
            dimensions=dims_map,
            expected_value=expected,
            included_in_output=True,
            action=action,
        ))

    if duplicate_policy == "drop_exact" and duplicate_mask.any():
        warnings.append(f"{int(duplicate_mask.sum())} exact duplicate source row(s) excluded from Prepared_Data by explicit user choice")
    return TransformationPreview(
        sheet_name, "ROW_PERIODS" if finding.location != "SHEET_NAME" else "SHEET_PERIOD",
        actual_fact_label, wide, roles, period_map, warnings, lineage,
        fact_source_header=fact_col.source_header, header_start_row=table.header_start_row,
        header_end_row=table.header_end_row, period_source_columns=period_source_names,
        negative_policy=negative_policy, duplicate_policy=duplicate_policy,
    )
