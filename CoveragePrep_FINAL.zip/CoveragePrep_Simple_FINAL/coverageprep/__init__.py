"""CoveragePrep Simple local shipment-preparation package."""

__version__ = "0.7g"
