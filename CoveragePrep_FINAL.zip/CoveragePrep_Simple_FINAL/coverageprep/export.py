"""Local evidence exporter for CoveragePrep Simple Step 7F.

This module writes only to a user-selected/local output directory. It never writes
back to the source shipment file.

A PASS validation creates ``*_Prepared.xlsx``. A failed validation creates
``*_REVIEW_REQUIRED.xlsx`` so draft data can be inspected without presenting it as
validated output.

The workbook contains:
- Prepared_Data (or Prepared_Data_DRAFT)
- Source_Copy OR Source_Reference
- Field_Mapping
- Period_Map
- Validation
- Issues
- Recommendations
- Audit_Log

If Prepared_Data exceeds Excel worksheet limits it is written to CSV and the
Excel workbook becomes the evidence/control workbook.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
import csv
import math

import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from .reader import fingerprint_sha256, inventory_file, validate_source_path
from .scanner import SheetHeaderScan
from .transform import LoadedTable, TransformationPreview, load_table
from .validation import ValidationReport


EXCEL_MAX_ROWS = 1_048_576
EXCEL_MAX_COLUMNS = 16_384
# A Source_Copy is a cell-level audit ledger. Stay comfortably below Excel's row
# ceiling and avoid creating a needlessly huge duplicate of a large shipment.
DEFAULT_SOURCE_COPY_MAX_CELLS = 500_000


class ExportError(RuntimeError):
    """Raised when a local evidence package cannot be written safely."""


@dataclass(frozen=True)
class ExportResult:
    status: str
    workbook_path: str
    prepared_csv_path: str | None
    prepared_sheet_name: str | None
    source_mode: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "workbook_path": self.workbook_path,
            "prepared_csv_path": self.prepared_csv_path,
            "prepared_sheet_name": self.prepared_sheet_name,
            "source_mode": self.source_mode,
        }


def _safe_cell_value(value: Any) -> Any:
    """Normalize pandas/openpyxl missing values while preserving source content."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    return value


def _source_header_by_position(table: LoadedTable) -> dict[int, str]:
    return {col.position: col.source_header for col in table.columns}


def _read_csv_rows(path: Path) -> Iterable[list[str]]:
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            with path.open("r", encoding=encoding, newline="") as handle:
                sample = handle.read(8192)
                handle.seek(0)
                try:
                    dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|") if sample else csv.excel
                except csv.Error:
                    dialect = csv.excel
                yield from csv.reader(handle, dialect)
            return
        except UnicodeDecodeError as exc:
            last_error = exc
            continue
    raise ExportError(f"Could not decode CSV '{path.name}': {last_error}")


def _build_source_copy(
    source_path: Path,
    sheet_name: str,
    table: LoadedTable,
) -> pd.DataFrame:
    """Create a cell-level audit copy for one selected source sheet/table."""
    headers = _source_header_by_position(table)
    records: list[dict[str, Any]] = []

    if source_path.suffix.lower() in {".xlsx", ".xlsm"}:
        keep_vba = source_path.suffix.lower() == ".xlsm"
        formula_wb = load_workbook(
            source_path,
            read_only=True,
            data_only=False,
            keep_vba=keep_vba,
            keep_links=True,
        )
        value_wb = load_workbook(
            source_path,
            read_only=True,
            data_only=True,
            keep_vba=keep_vba,
            keep_links=True,
        )
        try:
            ws_formula = formula_wb[sheet_name]
            ws_value = value_wb[sheet_name]
            max_row = int(ws_formula.max_row or 0)
            max_col = int(ws_formula.max_column or 0)
            formula_rows = ws_formula.iter_rows(min_row=1, max_row=max_row, min_col=1, max_col=max_col)
            value_rows = ws_value.iter_rows(min_row=1, max_row=max_row, min_col=1, max_col=max_col)
            for row_no, (formula_row, value_row) in enumerate(zip(formula_rows, value_rows), start=1):
                for col_no, (formula_cell, value_cell) in enumerate(zip(formula_row, value_row), start=1):
                    original = formula_cell.value
                    formula = original if isinstance(original, str) and original.startswith("=") else None
                    records.append({
                        "SOURCE_SHEET": sheet_name,
                        "SOURCE_ROW": row_no,
                        "SOURCE_COLUMN": get_column_letter(col_no),
                        "SOURCE_HEADER": headers.get(col_no, ""),
                        "ORIGINAL_VALUE": _safe_cell_value(original),
                        "FORMULA": formula,
                        "CACHED_VALUE": _safe_cell_value(value_cell.value) if formula else None,
                    })
        finally:
            formula_wb.close()
            value_wb.close()
    else:
        rows = list(_read_csv_rows(source_path))
        max_col = max((len(row) for row in rows), default=0)
        for row_no, row in enumerate(rows, start=1):
            padded = list(row) + [""] * max(0, max_col - len(row))
            for col_no, value in enumerate(padded, start=1):
                records.append({
                    "SOURCE_SHEET": "(CSV)",
                    "SOURCE_ROW": row_no,
                    "SOURCE_COLUMN": get_column_letter(col_no),
                    "SOURCE_HEADER": headers.get(col_no, ""),
                    "ORIGINAL_VALUE": value,
                    "FORMULA": None,
                    "CACHED_VALUE": None,
                })

    return pd.DataFrame.from_records(
        records,
        columns=[
            "SOURCE_SHEET",
            "SOURCE_ROW",
            "SOURCE_COLUMN",
            "SOURCE_HEADER",
            "ORIGINAL_VALUE",
            "FORMULA",
            "CACHED_VALUE",
        ],
    )


def _build_source_reference(
    source_path: Path,
    sheet_name: str,
    header_scan: SheetHeaderScan,
    reason: str,
) -> pd.DataFrame:
    inv = inventory_file(source_path, preview_rows=0)
    sheet = next(item for item in inv.sheets if item.name == sheet_name)
    candidate = header_scan.recommended
    rows = [
        ("Original filename", inv.filename),
        ("Extension", inv.extension),
        ("File size bytes", inv.size_bytes),
        ("SHA-256", fingerprint_sha256(source_path)),
        ("Selected sheet", sheet_name),
        ("Source rows", sheet.rows),
        ("Source columns", sheet.columns),
        ("Header rows", f"{candidate.start_row}-{candidate.end_row}" if candidate else "Not confirmed"),
        ("Source_Copy omitted", reason),
        ("Source preservation", "Original local shipment file was not overwritten or modified"),
    ]
    return pd.DataFrame(rows, columns=["ITEM", "VALUE"])


def _build_field_mapping(preview: TransformationPreview) -> pd.DataFrame:
    output_columns = list(preview.prepared_data.columns)
    period_standards = {item.get("standard") for item in preview.period_map if item.get("standard")}
    rows: list[dict[str, Any]] = []
    for header, role in preview.field_roles.items():
        rows.append({
            "SOURCE_SHEET": preview.sheet_name,
            "SOURCE_HEADER": header,
            "ASSIGNED_ROLE": role,
            "OUTPUT_HEADER": header,
            "OUTPUT_POSITION": output_columns.index(header) + 1 if header in output_columns else None,
            "STATUS": "Included" if header in output_columns else "Not in Prepared_Data",
        })
    # Technical output role. FACT is standardized by design.
    if "FACT" in output_columns:
        rows.append({
            "SOURCE_SHEET": preview.sheet_name,
            "SOURCE_HEADER": "(confirmed fact label)",
            "ASSIGNED_ROLE": "FACT",
            "OUTPUT_HEADER": "FACT",
            "OUTPUT_POSITION": output_columns.index("FACT") + 1,
            "STATUS": "Technical standardized field",
        })
    return pd.DataFrame.from_records(
        rows,
        columns=["SOURCE_SHEET", "SOURCE_HEADER", "ASSIGNED_ROLE", "OUTPUT_HEADER", "OUTPUT_POSITION", "STATUS"],
    )


def _build_period_map(preview: TransformationPreview) -> pd.DataFrame:
    rows = []
    for item in preview.period_map:
        rows.append({
            "SOURCE_SHEET": preview.sheet_name,
            "ORIGINAL_PERIOD": item.get("original"),
            "DETECTED_FREQUENCY": item.get("frequency"),
            "STANDARD_PERIOD": item.get("standard"),
            "STATUS": item.get("status"),
        })
    return pd.DataFrame.from_records(
        rows,
        columns=["SOURCE_SHEET", "ORIGINAL_PERIOD", "DETECTED_FREQUENCY", "STANDARD_PERIOD", "STATUS"],
    )


def _build_issues(preview: TransformationPreview, report: ValidationReport) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for warning in preview.warnings:
        rows.append({
            "SEVERITY": "WARNING",
            "PHASE": "TRANSFORM",
            "SHEET": preview.sheet_name,
            "LOCATION": "",
            "ISSUE_TYPE": "TRANSFORMATION_WARNING",
            "ORIGINAL_VALUE": "",
            "DETAIL": warning,
            "RECOMMENDED_ACTION": "Review before operational use",
            "STATUS": "OPEN",
        })
    for issue in report.issues:
        rows.append({
            "SEVERITY": issue.severity,
            "PHASE": "VALIDATION",
            "SHEET": preview.sheet_name,
            "LOCATION": issue.key,
            "ISSUE_TYPE": issue.issue_type,
            "ORIGINAL_VALUE": " | ".join(issue.source_values[:10]),
            "DETAIL": issue.detail,
            "RECOMMENDED_ACTION": "Resolve blocker and rerun preparation" if issue.severity == "BLOCKER" else "Review",
            "STATUS": "OPEN",
        })
    return pd.DataFrame.from_records(
        rows,
        columns=[
            "SEVERITY", "PHASE", "SHEET", "LOCATION", "ISSUE_TYPE",
            "ORIGINAL_VALUE", "DETAIL", "RECOMMENDED_ACTION", "STATUS",
        ],
    )


def _build_recommendations(preview: TransformationPreview, report: ValidationReport) -> pd.DataFrame:
    recommendations: list[tuple[str, str]] = [
        ("Preservation", "Client source header names were preserved in Prepared_Data; only FACT and period labels are standardized."),
        ("Periods", "Monthly periods are displayed as MMM YYYY (for example Jan 2026); weekly/quarterly frequency is preserved."),
        ("Aggregation", "No automatic aggregation was performed."),
        ("Validation", f"Final validation status: {report.status}."),
    ]
    if report.status != "PASS":
        recommendations.append(("Required action", "Resolve all blocking validation issues before using the prepared file for Coverage preparation."))
    for warning in report.warnings:
        recommendations.append(("Warning", warning))
    return pd.DataFrame(recommendations, columns=["TYPE", "RECOMMENDATION"])


def _build_audit_log(
    source_path: Path,
    preview: TransformationPreview,
    report: ValidationReport,
    header_scan: SheetHeaderScan,
    period_order: str,
) -> pd.DataFrame:
    candidate = header_scan.recommended
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    entries = [
        (1, "Source file selected", source_path.name, "Accepted"),
        (2, "Source sheet selected", preview.sheet_name, "Accepted"),
        (3, "Header detection", f"Rows {candidate.start_row}-{candidate.end_row}" if candidate else "Not confirmed", "Confirmed/recommended"),
        (4, "Period standardization", "MMM YYYY for monthly; source frequency preserved", "Applied to display labels"),
        (5, "Period ordering", period_order, "Applied to Prepared_Data only"),
        (6, "FACT", preview.fact_label, "Confirmed/detected"),
        (7, "Automatic aggregation", "Disabled", "No implicit sums"),
        (8, "Transformation", preview.layout, "Complete"),
        (9, "Validation", report.status, "Complete"),
        (10, "Export timestamp", now, "Local output only"),
    ]
    return pd.DataFrame(entries, columns=["STEP", "ACTION", "USER_DECISION_OR_SETTING", "RESULT"])


def _excel_safe(value: Any) -> Any:
    # xlsxwriter is instructed not to convert strings beginning with '=' into formulas.
    return _safe_cell_value(value)


def _write_dataframe(writer: pd.ExcelWriter, sheet_name: str, frame: pd.DataFrame, *, freeze: bool = True) -> None:
    frame = frame.copy()
    # Preserve literal strings. XlsxWriter engine option strings_to_formulas=False is
    # also set at writer construction.
    frame = frame.map(_excel_safe) if not frame.empty else frame
    frame.to_excel(writer, sheet_name=sheet_name, index=False)
    workbook = writer.book
    worksheet = writer.sheets[sheet_name]

    header_fmt = workbook.add_format({
        "bold": True,
        "font_color": "#FFFFFF",
        "bg_color": "#1F4E78",
        "border": 1,
        "align": "center",
        "valign": "vcenter",
        "text_wrap": True,
    })
    text_fmt = workbook.add_format({"valign": "top"})
    wrap_fmt = workbook.add_format({"valign": "top", "text_wrap": True})

    for col_index, column in enumerate(frame.columns):
        worksheet.write(0, col_index, column, header_fmt)
        sample = [str(column)] + [str(v) for v in frame[column].head(200).tolist() if v is not None]
        max_len = max((len(v) for v in sample), default=10)
        width = min(max(max_len + 2, 10), 38)
        worksheet.set_column(col_index, col_index, width, wrap_fmt if width >= 30 else text_fmt)

    if freeze:
        worksheet.freeze_panes(1, 0)
    if len(frame.columns) > 0 and len(frame) > 0:
        worksheet.autofilter(0, 0, len(frame), len(frame.columns) - 1)
    worksheet.set_row(0, 30)


def _write_validation_sheet(writer: pd.ExcelWriter, preview: TransformationPreview, report: ValidationReport) -> None:
    workbook = writer.book
    worksheet = workbook.add_worksheet("Validation")
    writer.sheets["Validation"] = worksheet

    title_fmt = workbook.add_format({"bold": True, "font_size": 16, "font_color": "#1F4E78"})
    header_fmt = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#1F4E78", "border": 1})
    pass_fmt = workbook.add_format({"bold": True, "font_color": "#006100", "bg_color": "#C6EFCE"})
    fail_fmt = workbook.add_format({"bold": True, "font_color": "#9C0006", "bg_color": "#FFC7CE"})
    label_fmt = workbook.add_format({"bold": True, "bg_color": "#D9EAF7"})

    worksheet.write("A1", "CoveragePrep Validation Summary", title_fmt)
    summary = [
        ("Final status", report.status),
        ("Source sheet", preview.sheet_name),
        ("FACT", preview.fact_label),
        ("Source fact cells", report.source_fact_cells),
        ("Prepared fact cells", report.output_fact_cells),
        ("Missing output keys", report.missing_output_keys),
        ("Unexpected output keys", report.unexpected_output_keys),
        ("Value mismatch keys", report.value_mismatch_keys),
        ("Blocking issues", report.blocking_issue_count),
    ]
    row = 2
    for label, value in summary:
        worksheet.write(row, 0, label, label_fmt)
        if label == "Final status":
            worksheet.write(row, 1, value, pass_fmt if value == "PASS" else fail_fmt)
        else:
            worksheet.write(row, 1, value)
        row += 1

    row += 2
    worksheet.write(row, 0, "Validation Checks", title_fmt)
    row += 1
    for col, label in enumerate(["CHECK", "STATUS", "DETAIL"]):
        worksheet.write(row, col, label, header_fmt)
    row += 1
    for check in report.checks:
        worksheet.write(row, 0, check.name)
        worksheet.write(row, 1, check.status, pass_fmt if check.status == "PASS" else fail_fmt)
        worksheet.write(row, 2, check.detail)
        row += 1

    row += 2
    worksheet.write(row, 0, "Per-Period Reconciliation", title_fmt)
    row += 1
    headers = ["PERIOD", "SOURCE_FACT_CELLS", "OUTPUT_FACT_CELLS", "SOURCE_NUMERIC_TOTAL", "OUTPUT_NUMERIC_TOTAL", "DELTA", "STATUS"]
    for col, label in enumerate(headers):
        worksheet.write(row, col, label, header_fmt)
    row += 1
    for item in report.per_period:
        values = [
            item.period,
            item.source_fact_cells,
            item.output_fact_cells,
            item.source_numeric_total,
            item.output_numeric_total,
            item.numeric_delta,
            item.status,
        ]
        for col, value in enumerate(values):
            if col == 6:
                worksheet.write(row, col, value, pass_fmt if value == "PASS" else fail_fmt)
            else:
                worksheet.write(row, col, value)
        row += 1

    worksheet.set_column("A:A", 32)
    worksheet.set_column("B:B", 22)
    worksheet.set_column("C:C", 58)
    worksheet.set_column("D:G", 20)
    worksheet.freeze_panes(2, 0)


def _prepared_exceeds_excel(frame: pd.DataFrame, max_rows: int, max_columns: int) -> bool:
    # +1 row for headers.
    return len(frame) + 1 > max_rows or len(frame.columns) > max_columns


def export_transformation(
    source_file: str | Path,
    preview: TransformationPreview,
    report: ValidationReport,
    *,
    header_scan: SheetHeaderScan,
    period_order: str = "ascending",
    output_dir: str | Path = "output",
    source_copy_max_cells: int = DEFAULT_SOURCE_COPY_MAX_CELLS,
    excel_max_rows: int = EXCEL_MAX_ROWS,
    excel_max_columns: int = EXCEL_MAX_COLUMNS,
) -> ExportResult:
    """Write the final local workbook/evidence package for one transformed sheet."""
    source_path = validate_source_path(source_file)
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    status_suffix = "Prepared" if report.status == "PASS" else "REVIEW_REQUIRED"
    workbook_path = out_dir / f"{source_path.stem}_{status_suffix}.xlsx"
    prepared_sheet_name = "Prepared_Data" if report.status == "PASS" else "Prepared_Data_DRAFT"

    table = load_table(source_path, preview.sheet_name, header_scan=header_scan)
    inv = inventory_file(source_path, preview_rows=0)
    source_sheet = next(item for item in inv.sheets if item.name == preview.sheet_name)
    estimated_cells = int(source_sheet.rows) * int(source_sheet.columns)

    if estimated_cells <= source_copy_max_cells and estimated_cells + 1 <= excel_max_rows:
        source_mode = "Source_Copy"
        source_frame = _build_source_copy(source_path, preview.sheet_name, table)
        source_reference = None
    else:
        source_mode = "Source_Reference"
        reason = (
            f"Cell-level Source_Copy would require approximately {estimated_cells:,} row(s), "
            f"above the configured safe threshold of {source_copy_max_cells:,}."
        )
        source_reference = _build_source_reference(source_path, preview.sheet_name, header_scan, reason)
        source_frame = None

    prepared_csv_path: Path | None = None
    prepared_in_excel = not _prepared_exceeds_excel(preview.prepared_data, excel_max_rows, excel_max_columns)
    if not prepared_in_excel:
        csv_suffix = "Prepared_Data" if report.status == "PASS" else "REVIEW_REQUIRED_Data"
        prepared_csv_path = out_dir / f"{source_path.stem}_{csv_suffix}.csv"
        preview.prepared_data.to_csv(prepared_csv_path, index=False, encoding="utf-8-sig")
        prepared_sheet_name_out: str | None = None
    else:
        prepared_sheet_name_out = prepared_sheet_name

    field_mapping = _build_field_mapping(preview)
    period_map = _build_period_map(preview)
    issues = _build_issues(preview, report)
    recommendations = _build_recommendations(preview, report)
    audit_log = _build_audit_log(source_path, preview, report, header_scan, period_order)

    try:
        with pd.ExcelWriter(
            workbook_path,
            engine="xlsxwriter",
            engine_kwargs={"options": {"strings_to_formulas": False, "strings_to_urls": False}},
        ) as writer:
            if prepared_in_excel:
                _write_dataframe(writer, prepared_sheet_name, preview.prepared_data)
            else:
                prepared_ref = pd.DataFrame([
                    ("Prepared data format", "CSV"),
                    ("Prepared data filename", prepared_csv_path.name if prepared_csv_path else ""),
                    ("Rows", len(preview.prepared_data)),
                    ("Columns", len(preview.prepared_data.columns)),
                    ("Reason", "Prepared_Data exceeds configured Excel worksheet limits."),
                ], columns=["ITEM", "VALUE"])
                _write_dataframe(writer, "Prepared_Data_Reference", prepared_ref, freeze=False)

            if source_mode == "Source_Copy" and source_frame is not None:
                _write_dataframe(writer, "Source_Copy", source_frame)
            elif source_reference is not None:
                _write_dataframe(writer, "Source_Reference", source_reference, freeze=False)

            _write_dataframe(writer, "Field_Mapping", field_mapping)
            _write_dataframe(writer, "Period_Map", period_map)
            _write_validation_sheet(writer, preview, report)
            _write_dataframe(writer, "Issues", issues)
            _write_dataframe(writer, "Recommendations", recommendations, freeze=False)
            _write_dataframe(writer, "Audit_Log", audit_log)
    except Exception as exc:
        # Avoid leaving a misleading partial workbook behind.
        try:
            if workbook_path.exists():
                workbook_path.unlink()
        except Exception:
            pass
        raise ExportError(f"Could not write output workbook '{workbook_path.name}': {exc}") from exc

    return ExportResult(
        status=report.status,
        workbook_path=str(workbook_path),
        prepared_csv_path=str(prepared_csv_path) if prepared_csv_path else None,
        prepared_sheet_name=prepared_sheet_name_out,
        source_mode=source_mode,
    )
