"""Optional read-only workbook scan report for Step 7G."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from .reader import inventory_file, validate_source_path
from .scanner import scan_workbook_headers
from .periods import scan_sheet_periods
from .export import _write_dataframe


def export_scan_report(source_file: str | Path, output_dir: str | Path = "output") -> Path:
    source = validate_source_path(source_file)
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"{source.stem}_Scan_Report.xlsx"

    inv = inventory_file(source, preview_rows=0)
    headers = scan_workbook_headers(source)

    summary = pd.DataFrame([
        ("Filename", inv.filename),
        ("Extension", inv.extension),
        ("Size bytes", inv.size_bytes),
        ("Sheet/table count", inv.sheet_count),
        ("Mode", "Read-only scan; no transformation performed"),
    ], columns=["ITEM", "VALUE"])

    sheet_rows: list[dict[str, Any]] = []
    header_rows: list[dict[str, Any]] = []
    period_rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    recommendations: list[dict[str, Any]] = []

    by_name = {s.sheet_name: s for s in headers.sheets}
    for sheet in inv.sheets:
        hs = by_name[sheet.name]
        c = hs.recommended
        sheet_rows.append({
            "SHEET": sheet.name,
            "ROWS": sheet.rows,
            "COLUMNS": sheet.columns,
            "STATE": sheet.state,
            "HEADER_START": c.start_row if c else None,
            "HEADER_END": c.end_row if c else None,
            "HEADER_CONFIDENCE": c.confidence if c else "Review",
        })
        for rank, candidate in enumerate(hs.candidates, 1):
            header_rows.append({
                "SHEET": sheet.name,
                "RANK": rank,
                "START_ROW": candidate.start_row,
                "END_ROW": candidate.end_row,
                "CONFIDENCE": candidate.confidence,
                "SCORE": candidate.score,
                "FLATTENED_PREVIEW": " | ".join(candidate.flattened_headers[:20]),
                "REASONS": "; ".join(candidate.reasons),
            })
        for warning in hs.warnings:
            issues.append({"SEVERITY": "WARNING", "SHEET": sheet.name, "TYPE": "HEADER", "DETAIL": warning})

        if c:
            try:
                ps = scan_sheet_periods(source, sheet.name, header_scan=hs)
                for finding in ps.findings:
                    if not finding.mappings:
                        period_rows.append({
                            "SHEET": sheet.name,
                            "LOCATION": finding.location,
                            "FREQUENCY": finding.frequency,
                            "STATUS": finding.status,
                            "SOURCE_COLUMNS": ", ".join(finding.source_columns),
                            "ORIGINAL": "",
                            "STANDARD": "",
                            "CONFIDENCE": finding.confidence,
                            "REASON": finding.reason,
                        })
                    for mapping in finding.mappings:
                        period_rows.append({
                            "SHEET": sheet.name,
                            "LOCATION": finding.location,
                            "FREQUENCY": finding.frequency,
                            "STATUS": mapping.status,
                            "SOURCE_COLUMNS": ", ".join(finding.source_columns),
                            "ORIGINAL": mapping.original,
                            "STANDARD": mapping.standard,
                            "CONFIDENCE": mapping.confidence,
                            "REASON": mapping.reason,
                        })
                for collision in ps.collisions:
                    issues.append({
                        "SEVERITY": "BLOCKER",
                        "SHEET": sheet.name,
                        "TYPE": "PERIOD_COLLISION",
                        "DETAIL": f"{collision.standard_period}: {', '.join(collision.sources)}",
                    })
                if any(f.status == "OK" for f in ps.findings):
                    recommendations.append({"SHEET": sheet.name, "RECOMMENDATION": "Review/confirm detected period structure before preparation."})
                else:
                    recommendations.append({"SHEET": sheet.name, "RECOMMENDATION": "Period structure needs manual review; no period should be guessed."})
            except Exception as exc:
                issues.append({"SEVERITY": "WARNING", "SHEET": sheet.name, "TYPE": "PERIOD_SCAN", "DETAIL": str(exc)})

    with pd.ExcelWriter(
        target,
        engine="xlsxwriter",
        engine_kwargs={"options": {"strings_to_formulas": False, "strings_to_urls": False}},
    ) as writer:
        _write_dataframe(writer, "Workbook_Summary", summary, freeze=False)
        _write_dataframe(writer, "Sheet_Summary", pd.DataFrame(sheet_rows))
        _write_dataframe(writer, "Header_Detection", pd.DataFrame(header_rows))
        _write_dataframe(writer, "Period_Detection", pd.DataFrame(period_rows))
        _write_dataframe(writer, "Issues", pd.DataFrame(issues, columns=["SEVERITY", "SHEET", "TYPE", "DETAIL"]))
        _write_dataframe(writer, "Recommendations", pd.DataFrame(recommendations, columns=["SHEET", "RECOMMENDATION"]))
    return target
