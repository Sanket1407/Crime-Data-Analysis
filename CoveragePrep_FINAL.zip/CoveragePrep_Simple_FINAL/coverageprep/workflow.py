"""Final local multi-sheet workflow for CoveragePrep Simple Step 7G.

The workflow composes the already-tested single-sheet engine. It does not add
aggregation or assumptions. Each selected sheet is transformed and validated
independently, then compatible Prepared_Data results are concatenated by column
union so different client headers remain separate.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import re

import pandas as pd

from .mapping import order_headers_by_role
from .periods import parse_period, scan_sheet_periods
from .reader import inventory_file, validate_source_path
from .scanner import SheetHeaderScan, manual_header_scan, scan_sheet_headers
from .transform import TransformationBlocked, TransformationPreview, transform_selected_sheet
from .validation import ValidationReport, validate_transformation


class WorkflowBlocked(RuntimeError):
    """Raised when a multi-sheet run cannot continue safely."""


@dataclass
class SheetRunSpec:
    sheet_name: str
    header_start_row: int | None = None
    header_end_row: int | None = None
    fact_label: str | None = None
    fact_source_header: str | None = None
    field_roles: dict[str, str] | None = None
    period_order: str = "ascending"
    negative_policy: str = "keep"
    duplicate_policy: str = "keep"
    accept_period_codes: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SheetRunResult:
    spec: SheetRunSpec
    header_scan: SheetHeaderScan
    preview: TransformationPreview
    report: ValidationReport


@dataclass
class MultiSheetRun:
    source_file: str
    results: list[SheetRunResult]
    combined_data: pd.DataFrame
    status: str
    warnings: list[str]

    @property
    def previews(self) -> list[TransformationPreview]:
        return [r.preview for r in self.results]

    @property
    def reports(self) -> list[ValidationReport]:
        return [r.report for r in self.results]


def suggest_fact_label(sheet_name: str) -> str | None:
    """Return a conservative FACT label suggestion from a sheet name."""
    text = sheet_name.strip()
    patterns = [
        (r"\bkg\b|kilogram", "KG"),
        (r"\bunits?\b|\bpcs?\b|pieces?", "UNITS"),
        (r"\blit(?:re|er)s?\b|\blt\b", "LITRES"),
        (r"sales\s*value|value\s*sales", "Sales Value"),
        (r"sales\s*volume|volume", "Sales Volume"),
        (r"\bqty\b|quantity", "Quantity"),
        (r"\bcases?\b", "Cases"),
    ]
    for pattern, label in patterns:
        if re.search(pattern, text, re.I):
            return label
    return None


def _header_scan_for_spec(path: Path, spec: SheetRunSpec) -> SheetHeaderScan:
    if spec.header_start_row is not None or spec.header_end_row is not None:
        if spec.header_start_row is None or spec.header_end_row is None:
            raise WorkflowBlocked(
                f"Sheet '{spec.sheet_name}' needs both header_start_row and header_end_row."
            )
        return manual_header_scan(
            path, spec.sheet_name, spec.header_start_row, spec.header_end_row
        )
    scan = scan_sheet_headers(path, spec.sheet_name)
    if not scan.recommended:
        raise WorkflowBlocked(
            f"No reliable header recommendation for '{spec.sheet_name}'. Select the header rows manually."
        )
    return scan


def process_sheet(source_file: str | Path, spec: SheetRunSpec) -> SheetRunResult:
    path = validate_source_path(source_file)
    header_scan = _header_scan_for_spec(path, spec)
    period_scan = scan_sheet_periods(path, spec.sheet_name, header_scan=header_scan)
    if period_scan.collisions:
        details = "; ".join(
            f"{c.standard_period}: {', '.join(c.sources)}" for c in period_scan.collisions
        )
        raise WorkflowBlocked(
            f"Period collision(s) in '{spec.sheet_name}': {details}. No values were merged."
        )

    fact_label = spec.fact_label
    # Wide layouts require a FACT label. A sheet-name suggestion is safe only as a
    # suggestion; the terminal wizard still asks the user to confirm it.
    if not fact_label:
        fact_label = suggest_fact_label(spec.sheet_name)

    preview = transform_selected_sheet(
        path,
        spec.sheet_name,
        fact_label=fact_label,
        fact_source_header=spec.fact_source_header,
        field_role_overrides=spec.field_roles,
        period_order=spec.period_order,
        negative_policy=spec.negative_policy,
        duplicate_policy=spec.duplicate_policy,
        accept_period_codes=spec.accept_period_codes,
        header_scan=header_scan,
        period_scan=period_scan,
    )
    report = validate_transformation(preview)
    return SheetRunResult(spec=spec, header_scan=header_scan, preview=preview, report=report)


def _period_columns(preview: TransformationPreview) -> list[str]:
    mapped = [str(x.get("standard")) for x in preview.period_map if x.get("standard")]
    mapped_set = set(mapped)
    return [c for c in preview.prepared_data.columns if c in mapped_set]


def _period_key(label: str) -> tuple[int, int, int, str]:
    parsed = parse_period(label)
    year = parsed.year if parsed.year is not None else 9999
    freq = {"Monthly": 1, "Bimonthly": 2, "Weekly": 3, "Quarterly": 4, "Yearly": 5}.get(parsed.frequency, 9)
    seq = parsed.sequence if parsed.sequence is not None else 99
    return year, freq, seq, label


def combine_prepared_data(results: list[SheetRunResult], period_order: str = "ascending") -> tuple[pd.DataFrame, list[str]]:
    if not results:
        raise WorkflowBlocked("No processed sheets are available to combine.")

    warnings: list[str] = []
    all_periods: list[str] = []
    roles: dict[str, str] = {}
    dim_headers: list[str] = []
    role_conflicts: dict[str, set[str]] = {}

    for result in results:
        preview = result.preview
        periods = _period_columns(preview)
        for p in periods:
            if p not in all_periods:
                all_periods.append(p)
        for header, role in preview.field_roles.items():
            if header in roles and roles[header] != role:
                role_conflicts.setdefault(header, {roles[header]}).add(role)
            else:
                roles.setdefault(header, role)
        for col in preview.prepared_data.columns:
            if col != "FACT" and col not in periods and col not in dim_headers:
                dim_headers.append(col)

    if role_conflicts:
        for header, conflict_roles in role_conflicts.items():
            warnings.append(
                f"Header '{header}' had conflicting logical roles across sheets: {sorted(conflict_roles)}. First confirmed role retained for ordering."
            )

    ordered_dims = order_headers_by_role(dim_headers, roles)
    if period_order == "ascending":
        ordered_periods = sorted(all_periods, key=_period_key)
    elif period_order == "descending":
        ordered_periods = sorted(all_periods, key=_period_key, reverse=True)
    elif period_order == "source":
        ordered_periods = all_periods
    else:
        raise ValueError("period_order must be 'ascending', 'descending', or 'source'")

    final_columns = ordered_dims + ["FACT"] + ordered_periods
    frames: list[pd.DataFrame] = []
    for result in results:
        frame = result.preview.prepared_data.copy()
        for col in final_columns:
            if col not in frame.columns:
                frame[col] = pd.NA
        frames.append(frame[final_columns])
    combined = pd.concat(frames, ignore_index=True, sort=False)
    return combined, warnings


def process_multiple_sheets(
    source_file: str | Path,
    specs: list[SheetRunSpec],
    *,
    period_order: str = "ascending",
) -> MultiSheetRun:
    path = validate_source_path(source_file)
    inv = inventory_file(path, preview_rows=0)
    available = {s.name for s in inv.sheets}
    missing = [s.sheet_name for s in specs if s.sheet_name not in available]
    if missing:
        raise WorkflowBlocked(f"Selected sheet(s) not found: {', '.join(missing)}")
    if not specs:
        raise WorkflowBlocked("Select at least one sheet to process.")

    results = [process_sheet(path, spec) for spec in specs]
    combined, warnings = combine_prepared_data(results, period_order=period_order)
    status = "PASS" if all(r.report.status == "PASS" for r in results) else "REVIEW_REQUIRED"
    return MultiSheetRun(
        source_file=str(path),
        results=results,
        combined_data=combined,
        status=status,
        warnings=warnings,
    )
