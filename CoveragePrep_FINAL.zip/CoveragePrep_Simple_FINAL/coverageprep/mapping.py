"""Field-role recommendations and single-fact detection for CoveragePrep Simple.

Step 7D principles
------------------
- preserve client source header names in prepared data;
- logical roles are metadata used only for ordering / validation;
- multiple source fields may share one logical role (for example Channel L1/L2/L3);
- detect ONE shipment fact/value series per processed table;
- never treat identifiers such as SKU/UPC/EAN as facts merely because they are numeric;
- recommendations never silently change client values.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Iterable
import math
import re

import pandas as pd


ROLE_ORDER = {
    "COUNTRY": 10,
    "REGION": 20,
    "CHANNEL": 30,
    "CITY": 40,
    "STATE": 50,
    "CATEGORY": 60,
    "BRAND": 70,
    "SKU": 80,
    "EXTRA": 90,
}

_ROLE_PATTERNS: list[tuple[str, re.Pattern[str], str]] = [
    ("COUNTRY", re.compile(r"\b(country|cntry|nation)\b", re.I), "country-like header"),
    ("REGION", re.compile(r"\b(region|regn|zone|territory|area)\b", re.I), "region-like header"),
    ("CHANNEL", re.compile(r"\b(channel|chnl|trade\s*channel|route\s*to\s*market)\b", re.I), "channel-like header"),
    ("CITY", re.compile(r"\b(city|town)\b", re.I), "city-like header"),
    ("STATE", re.compile(r"\b(state|province)\b", re.I), "state-like header"),
    ("CATEGORY", re.compile(r"\b(category|catg|cat\b|product\s*(group|family|segment)|segment)\b", re.I), "category/product-group-like header"),
    ("BRAND", re.compile(r"\b(brand|brnd)\b", re.I), "brand-like header"),
    ("SKU", re.compile(r"\b(sku|upc|ean|gtin|material|item\s*(code|id|number|no)?|product\s*code|article\s*(code|id|number|no)?)\b", re.I), "SKU/identifier-like header"),
]

_FACT_HEADER_RE = re.compile(
    r"\b(sales(?:\s*value|\s*volume)?|value|volume|vol\b|qty|quantity|units?|kg|kilograms?|lit(?:re|er)s?|cases?)\b",
    re.I,
)
_IDENTIFIER_RE = re.compile(
    r"\b(sku|upc|ean|gtin|material|item|product\s*code|article|identifier|\bid\b|code)\b",
    re.I,
)
_PERIOD_COMPONENT_RE = re.compile(r"\b(year|yr|month|mnth|period|week|wk|quarter|qtr|date)\b", re.I)


@dataclass(frozen=True)
class FieldRoleSuggestion:
    source_header: str
    role: str
    confidence: str
    reason: str
    original_position: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class FactCandidate:
    source_header: str
    numeric_ratio: float
    nonblank_count: int
    header_hint: bool
    identifier_hint: bool
    score: float
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SingleFactDetection:
    status: str  # OK / REVIEW / BLOCKER / NEEDS_LABEL
    layout: str  # WIDE_PERIODS / ROW_PERIODS / SHEET_PERIOD / UNKNOWN
    source_column: str | None
    suggested_fact_label: str | None
    candidates: list[FactCandidate]
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def suggest_field_roles(headers: Iterable[str]) -> list[FieldRoleSuggestion]:
    """Recommend logical roles while preserving the exact source header text."""
    suggestions: list[FieldRoleSuggestion] = []
    for pos, header in enumerate(headers, start=1):
        text = str(header)
        role = "EXTRA"
        confidence = "Low"
        reason = "no safe standard role inferred; keep as source field"
        for candidate_role, pattern, candidate_reason in _ROLE_PATTERNS:
            if pattern.search(text):
                role = candidate_role
                confidence = "High"
                reason = candidate_reason
                break
        suggestions.append(FieldRoleSuggestion(text, role, confidence, reason, pos))
    return suggestions


def order_headers_by_role(headers: list[str], assignments: dict[str, str] | None = None) -> list[str]:
    """Return headers in logical output order; names themselves are unchanged."""
    if assignments is None:
        assignments = {s.source_header: s.role for s in suggest_field_roles(headers)}
    original_pos = {header: idx for idx, header in enumerate(headers)}
    return sorted(
        headers,
        key=lambda h: (ROLE_ORDER.get(assignments.get(h, "EXTRA"), ROLE_ORDER["EXTRA"]), original_pos[h]),
    )


def _numeric_ratio(series: pd.Series) -> tuple[float, int]:
    values = series.dropna()
    if values.empty:
        return 0.0, 0

    nonblank: list[Any] = []
    numeric = 0
    for value in values.tolist():
        if isinstance(value, str) and value.strip() == "":
            continue
        nonblank.append(value)
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)) and not (isinstance(value, float) and math.isnan(value)):
            numeric += 1
            continue
        if isinstance(value, str):
            t = value.strip().replace(",", "")
            try:
                float(t)
                numeric += 1
            except ValueError:
                pass
    return (numeric / len(nonblank) if nonblank else 0.0), len(nonblank)


def detect_single_fact(
    frame: pd.DataFrame,
    *,
    layout: str,
    period_source_columns: Iterable[str] = (),
    excluded_columns: Iterable[str] = (),
    assigned_roles: dict[str, str] | None = None,
    sheet_name: str | None = None,
) -> SingleFactDetection:
    """Detect one likely fact-value column for row/sheet-period layouts.

    For wide-period layouts, the period columns themselves already carry the one fact
    value series, so no source fact-value column is selected. A FACT label is still
    required later from the user or a trusted source label.
    """
    if layout == "WIDE_PERIODS":
        return SingleFactDetection(
            status="NEEDS_LABEL",
            layout=layout,
            source_column=None,
            suggested_fact_label=None,
            candidates=[],
            reason="period columns themselves contain the one value series; user must confirm the FACT label",
        )

    assigned_roles = assigned_roles or {}
    excluded = set(period_source_columns) | set(excluded_columns)
    candidates: list[FactCandidate] = []

    for header in frame.columns:
        header = str(header)
        if header in excluded:
            continue
        role = assigned_roles.get(header)
        if role in {"SKU", "COUNTRY", "REGION", "CHANNEL", "CITY", "STATE", "CATEGORY", "BRAND"}:
            continue
        if _PERIOD_COMPONENT_RE.search(header):
            continue

        ratio, count = _numeric_ratio(frame[header])
        if count < 1 or ratio < 0.80:
            continue

        header_hint = bool(_FACT_HEADER_RE.search(header))
        identifier_hint = bool(_IDENTIFIER_RE.search(header))
        score = ratio * 70 + (25 if header_hint else 0) - (50 if identifier_hint else 0)
        reason_parts = [f"{ratio:.0%} of nonblank sampled values are numeric"]
        if header_hint:
            reason_parts.append("header looks fact/value-like")
        if identifier_hint:
            reason_parts.append("header looks identifier-like, so fact confidence is reduced")
        candidates.append(
            FactCandidate(
                source_header=header,
                numeric_ratio=ratio,
                nonblank_count=count,
                header_hint=header_hint,
                identifier_hint=identifier_hint,
                score=score,
                reason="; ".join(reason_parts),
            )
        )

    candidates.sort(key=lambda c: c.score, reverse=True)
    safe = [c for c in candidates if not c.identifier_hint]

    if not safe:
        return SingleFactDetection(
            status="BLOCKER",
            layout=layout,
            source_column=None,
            suggested_fact_label=None,
            candidates=candidates,
            reason="no safe single numeric fact-value column could be identified",
        )

    if len(safe) == 1:
        chosen = safe[0]
        status = "OK" if chosen.header_hint else "REVIEW"
        return SingleFactDetection(
            status=status,
            layout=layout,
            source_column=chosen.source_header,
            suggested_fact_label=chosen.source_header,
            candidates=candidates,
            reason="one safe numeric value column detected" if status == "OK" else "one numeric value column detected, but the header does not clearly describe a fact",
        )

    # Multiple numeric columns can occur because dimensions such as codes are numeric.
    # If exactly one has a strong fact header and the rest do not, recommend it but
    # still require user confirmation.
    hinted = [c for c in safe if c.header_hint]
    if len(hinted) == 1 and (len(safe) == 1 or hinted[0].score >= safe[1].score + 15):
        chosen = hinted[0]
        return SingleFactDetection(
            status="REVIEW",
            layout=layout,
            source_column=chosen.source_header,
            suggested_fact_label=chosen.source_header,
            candidates=candidates,
            reason="multiple numeric fields exist; one fact-like header ranks clearly highest, so user confirmation is required",
        )

    return SingleFactDetection(
        status="BLOCKER",
        layout=layout,
        source_column=None,
        suggested_fact_label=None,
        candidates=candidates,
        reason="multiple plausible numeric value columns exist; choose the single shipment fact/value column explicitly",
    )
