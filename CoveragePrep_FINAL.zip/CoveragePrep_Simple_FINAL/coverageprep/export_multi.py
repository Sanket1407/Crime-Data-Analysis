"""Multi-sheet local exporter for CoveragePrep Simple Step 7G."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from .reader import fingerprint_sha256, inventory_file, validate_source_path
from .transform import load_table
from .workflow import MultiSheetRun
from .export import (
    EXCEL_MAX_COLUMNS,
    EXCEL_MAX_ROWS,
    DEFAULT_SOURCE_COPY_MAX_CELLS,
    ExportError,
    _build_source_copy,
    _build_field_mapping,
    _build_period_map,
    _build_issues,
    _build_recommendations,
    _prepared_exceeds_excel,
    _write_dataframe,
)


@dataclass(frozen=True)
class MultiExportResult:
    status: str
    workbook_path: str
    prepared_csv_path: str | None
    prepared_sheet_name: str | None
    source_mode: str
    config_path: str | None = None


def _source_reference(source_path: Path, run: MultiSheetRun, reason: str) -> pd.DataFrame:
    inv = inventory_file(source_path, preview_rows=0)
    selected = {r.preview.sheet_name for r in run.results}
    rows: list[tuple[str, Any]] = [
        ("Original filename", inv.filename),
        ("Extension", inv.extension),
        ("File size bytes", inv.size_bytes),
        ("SHA-256", fingerprint_sha256(source_path)),
        ("Selected sheets", ", ".join(r.preview.sheet_name for r in run.results)),
        ("Source_Copy omitted", reason),
        ("Source preservation", "Original local shipment file was not overwritten or modified"),
    ]
    for sheet in inv.sheets:
        if sheet.name in selected:
            rows.append((f"Sheet {sheet.name} rows", sheet.rows))
            rows.append((f"Sheet {sheet.name} columns", sheet.columns))
    return pd.DataFrame(rows, columns=["ITEM", "VALUE"])


def _validation_frame(run: MultiSheetRun) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for result in run.results:
        report = result.report
        rows.append({
            "SOURCE_SHEET": result.preview.sheet_name,
            "FACT": result.preview.fact_label,
            "STATUS": report.status,
            "SOURCE_FACT_CELLS": report.source_fact_cells,
            "PREPARED_FACT_CELLS": report.output_fact_cells,
            "MISSING_OUTPUT_KEYS": report.missing_output_keys,
            "UNEXPECTED_OUTPUT_KEYS": report.unexpected_output_keys,
            "VALUE_MISMATCH_KEYS": report.value_mismatch_keys,
            "BLOCKING_ISSUES": report.blocking_issue_count,
        })
        for p in report.per_period:
            rows.append({
                "SOURCE_SHEET": result.preview.sheet_name,
                "FACT": result.preview.fact_label,
                "STATUS": f"PERIOD:{p.status}",
                "PERIOD": p.period,
                "SOURCE_FACT_CELLS": p.source_fact_cells,
                "PREPARED_FACT_CELLS": p.output_fact_cells,
                "SOURCE_NUMERIC_TOTAL": p.source_numeric_total,
                "PREPARED_NUMERIC_TOTAL": p.output_numeric_total,
                "NUMERIC_DELTA": p.numeric_delta,
            })
    return pd.DataFrame(rows)


def _audit_frame(source_path: Path, run: MultiSheetRun) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    step = 1
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    rows.append({"STEP": step, "ACTION": "Source file selected", "SHEET": "", "SETTING": source_path.name, "RESULT": "Accepted"}); step += 1
    for result in run.results:
        p = result.preview
        rows.extend([
            {"STEP": step, "ACTION": "Sheet selected", "SHEET": p.sheet_name, "SETTING": p.sheet_name, "RESULT": "Accepted"},
            {"STEP": step + 1, "ACTION": "Header rows", "SHEET": p.sheet_name, "SETTING": f"{p.header_start_row}-{p.header_end_row}", "RESULT": "Confirmed/recommended"},
            {"STEP": step + 2, "ACTION": "FACT", "SHEET": p.sheet_name, "SETTING": p.fact_label, "RESULT": "Confirmed/detected"},
            {"STEP": step + 3, "ACTION": "Negative policy", "SHEET": p.sheet_name, "SETTING": p.negative_policy, "RESULT": "Applied"},
            {"STEP": step + 4, "ACTION": "Duplicate policy", "SHEET": p.sheet_name, "SETTING": p.duplicate_policy, "RESULT": "Applied"},
            {"STEP": step + 5, "ACTION": "Validation", "SHEET": p.sheet_name, "SETTING": result.report.status, "RESULT": "Complete"},
        ])
        step += 6
    rows.append({"STEP": step, "ACTION": "Combined Prepared_Data", "SHEET": "", "SETTING": f"{len(run.combined_data):,} rows", "RESULT": run.status}); step += 1
    rows.append({"STEP": step, "ACTION": "Export timestamp", "SHEET": "", "SETTING": now, "RESULT": "Local output only"})
    return pd.DataFrame(rows, columns=["STEP", "ACTION", "SHEET", "SETTING", "RESULT"])


def export_multisheet_run(
    source_file: str | Path,
    run: MultiSheetRun,
    *,
    output_dir: str | Path = "output",
    source_copy_max_cells: int = DEFAULT_SOURCE_COPY_MAX_CELLS,
    excel_max_rows: int = EXCEL_MAX_ROWS,
    excel_max_columns: int = EXCEL_MAX_COLUMNS,
) -> MultiExportResult:
    source_path = validate_source_path(source_file)
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    suffix = "Prepared" if run.status == "PASS" else "REVIEW_REQUIRED"
    workbook_path = out_dir / f"{source_path.stem}_{suffix}.xlsx"
    prepared_name = "Prepared_Data" if run.status == "PASS" else "Prepared_Data_DRAFT"

    inv = inventory_file(source_path, preview_rows=0)
    selected_names = [r.preview.sheet_name for r in run.results]
    selected_inv = [s for s in inv.sheets if s.name in selected_names]
    estimated_source_copy_rows = sum(int(s.rows) * int(s.columns) for s in selected_inv)

    source_frames: list[pd.DataFrame] = []
    source_mode = "Source_Copy"
    source_reference = None
    if (
        estimated_source_copy_rows <= source_copy_max_cells
        and estimated_source_copy_rows + 1 <= excel_max_rows
    ):
        for result in run.results:
            table = load_table(source_path, result.preview.sheet_name, header_scan=result.header_scan)
            source_frames.append(_build_source_copy(source_path, result.preview.sheet_name, table))
        source_frame = pd.concat(source_frames, ignore_index=True) if source_frames else pd.DataFrame()
    else:
        source_mode = "Source_Reference"
        source_frame = None
        reason = (
            f"Cell-level Source_Copy would require approximately {estimated_source_copy_rows:,} row(s), "
            f"above the configured safe threshold of {source_copy_max_cells:,}."
        )
        source_reference = _source_reference(source_path, run, reason)

    prepared_csv_path: Path | None = None
    prepared_in_excel = not _prepared_exceeds_excel(run.combined_data, excel_max_rows, excel_max_columns)
    if not prepared_in_excel:
        csv_suffix = "Prepared_Data" if run.status == "PASS" else "REVIEW_REQUIRED_Data"
        prepared_csv_path = out_dir / f"{source_path.stem}_{csv_suffix}.csv"
        run.combined_data.to_csv(prepared_csv_path, index=False, encoding="utf-8-sig")
        prepared_sheet_name_out = None
    else:
        prepared_sheet_name_out = prepared_name

    mapping_frames = [_build_field_mapping(r.preview) for r in run.results]
    field_mapping = pd.concat(mapping_frames, ignore_index=True) if mapping_frames else pd.DataFrame()
    period_frames = [_build_period_map(r.preview) for r in run.results]
    period_map = pd.concat(period_frames, ignore_index=True) if period_frames else pd.DataFrame()
    issue_frames = [_build_issues(r.preview, r.report) for r in run.results]
    issues = pd.concat(issue_frames, ignore_index=True) if issue_frames else pd.DataFrame()
    if run.warnings:
        extra = pd.DataFrame([
            {
                "SEVERITY": "WARNING",
                "PHASE": "COMBINE",
                "SHEET": "",
                "LOCATION": "",
                "ISSUE_TYPE": "COMBINATION_WARNING",
                "ORIGINAL_VALUE": "",
                "DETAIL": w,
                "RECOMMENDED_ACTION": "Review",
                "STATUS": "OPEN",
            }
            for w in run.warnings
        ])
        issues = pd.concat([issues, extra], ignore_index=True)
    rec_frames = [_build_recommendations(r.preview, r.report) for r in run.results]
    recommendations = pd.concat(rec_frames, ignore_index=True).drop_duplicates() if rec_frames else pd.DataFrame()
    validation = _validation_frame(run)
    audit = _audit_frame(source_path, run)

    try:
        with pd.ExcelWriter(
            workbook_path,
            engine="xlsxwriter",
            engine_kwargs={"options": {"strings_to_formulas": False, "strings_to_urls": False}},
        ) as writer:
            if prepared_in_excel:
                _write_dataframe(writer, prepared_name, run.combined_data)
            else:
                prepared_ref = pd.DataFrame([
                    ("Prepared data format", "CSV"),
                    ("Prepared data filename", prepared_csv_path.name if prepared_csv_path else ""),
                    ("Rows", len(run.combined_data)),
                    ("Columns", len(run.combined_data.columns)),
                    ("Reason", "Prepared_Data exceeds configured Excel worksheet limits."),
                ], columns=["ITEM", "VALUE"])
                _write_dataframe(writer, "Prepared_Data_Reference", prepared_ref, freeze=False)

            if source_mode == "Source_Copy" and source_frame is not None:
                _write_dataframe(writer, "Source_Copy", source_frame)
            elif source_reference is not None:
                _write_dataframe(writer, "Source_Reference", source_reference, freeze=False)

            _write_dataframe(writer, "Field_Mapping", field_mapping)
            _write_dataframe(writer, "Period_Map", period_map)
            _write_dataframe(writer, "Validation", validation)
            _write_dataframe(writer, "Issues", issues)
            _write_dataframe(writer, "Recommendations", recommendations, freeze=False)
            _write_dataframe(writer, "Audit_Log", audit)
    except Exception as exc:
        try:
            if workbook_path.exists():
                workbook_path.unlink()
        except Exception:
            pass
        raise ExportError(f"Could not write multi-sheet output workbook '{workbook_path.name}': {exc}") from exc

    return MultiExportResult(
        status=run.status,
        workbook_path=str(workbook_path),
        prepared_csv_path=str(prepared_csv_path) if prepared_csv_path else None,
        prepared_sheet_name=prepared_sheet_name_out,
        source_mode=source_mode,
    )
