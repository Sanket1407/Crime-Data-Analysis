"""Validation layer for CoveragePrep Simple Step 7E.

The validator works from the transformation preview's source lineage. It does not
re-read or modify the shipment file and it does not rely on a grand total alone.

Checks include:
- source vs prepared fact-cell counts;
- exact source-value preservation by dimension + FACT + standardized period;
- unexpected/missing output keys;
- per-period counts and numeric reconciliation;
- source lineage uniqueness;
- overall value multiset preservation.

Step 7E still creates no final Excel output. Export is intentionally left for the
next approved stage.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any
import math
import numbers

import pandas as pd

from .transform import FactLineage, TransformationPreview


@dataclass(frozen=True)
class ValidationCheck:
    name: str
    status: str  # PASS / FAIL / WARNING
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PeriodValidation:
    period: str
    source_fact_cells: int
    output_fact_cells: int
    source_numeric_total: str | None
    output_numeric_total: str | None
    numeric_delta: str | None
    status: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ValidationIssue:
    issue_type: str
    severity: str
    key: str
    source_values: list[str]
    output_values: list[str]
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ValidationReport:
    status: str  # PASS / REVIEW_REQUIRED
    source_fact_cells: int
    output_fact_cells: int
    missing_output_keys: int
    unexpected_output_keys: int
    value_mismatch_keys: int
    checks: list[ValidationCheck]
    per_period: list[PeriodValidation]
    issues: list[ValidationIssue]
    warnings: list[str]

    @property
    def blocking_issue_count(self) -> int:
        return sum(1 for issue in self.issues if issue.severity == "BLOCKER")

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "source_fact_cells": self.source_fact_cells,
            "output_fact_cells": self.output_fact_cells,
            "missing_output_keys": self.missing_output_keys,
            "unexpected_output_keys": self.unexpected_output_keys,
            "value_mismatch_keys": self.value_mismatch_keys,
            "blocking_issue_count": self.blocking_issue_count,
            "checks": [c.to_dict() for c in self.checks],
            "per_period": [p.to_dict() for p in self.per_period],
            "issues": [i.to_dict() for i in self.issues],
            "warnings": list(self.warnings),
        }


def _is_blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return value == "" or value.strip() == ""
    try:
        result = pd.isna(value)
        if isinstance(result, bool):
            return result
    except Exception:
        pass
    return False


def _decimal(value: Any) -> Decimal | None:
    if _is_blank(value) or isinstance(value, bool):
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, numbers.Number):
        try:
            if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                return None
            return Decimal(str(value))
        except (InvalidOperation, ValueError):
            return None
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        if not text:
            return None
        try:
            return Decimal(text)
        except InvalidOperation:
            return None
    return None


def _canonical(value: Any) -> tuple[str, str]:
    if _is_blank(value):
        return ("blank", "")
    num = _decimal(value)
    if num is not None:
        normalized = num.normalize()
        if normalized == 0:
            normalized = Decimal(0)
        return ("number", format(normalized, "f"))
    if isinstance(value, datetime):
        return ("datetime", value.isoformat(sep=" "))
    if isinstance(value, date):
        return ("date", value.isoformat())
    return ("text", str(value))


def _display_canonical(value: tuple[str, str]) -> str:
    kind, text = value
    return text if kind != "blank" else "(blank)"




def _expected_value(lineage: FactLineage) -> Any:
    # Step 7G can intentionally transform negative values after explicit user choice.
    # expected_value records that approved result while source_value preserves origin.
    if lineage.expected_value is not None or lineage.source_value is None:
        return lineage.expected_value
    return lineage.source_value

def _source_key(lineage: FactLineage) -> tuple[Any, ...]:
    dims = tuple(sorted((name, _canonical(value)) for name, value in lineage.dimensions.items()))
    return dims + (("FACT", _canonical(lineage.fact_label)), ("PERIOD", _canonical(lineage.standard_period)))


def _output_key(row: pd.Series, dimension_headers: list[str], fact_label: Any, period: str) -> tuple[Any, ...]:
    dims = tuple(sorted((name, _canonical(row[name])) for name in dimension_headers))
    return dims + (("FACT", _canonical(fact_label)), ("PERIOD", _canonical(period)))


def _key_text(key: tuple[Any, ...]) -> str:
    parts: list[str] = []
    for name, canonical in key:
        parts.append(f"{name}={_display_canonical(canonical)}")
    return " | ".join(parts)


def _counter_to_display(counter: Counter[tuple[str, str]]) -> list[str]:
    output: list[str] = []
    for value, count in sorted(counter.items(), key=lambda item: (item[0][0], item[0][1])):
        label = _display_canonical(value)
        output.extend([label] * count)
    return output


def _period_order_from_preview(preview: TransformationPreview) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for line in preview.lineage:
        if line.standard_period not in seen:
            seen.add(line.standard_period)
            ordered.append(line.standard_period)
    # Respect the actual Prepared_Data order when possible.
    prepared_periods = [c for c in preview.prepared_data.columns if c in seen]
    missing = [p for p in ordered if p not in prepared_periods]
    return prepared_periods + missing


def _build_source_groups(preview: TransformationPreview) -> tuple[dict[tuple[Any, ...], Counter], dict[str, list[Any]]]:
    groups: dict[tuple[Any, ...], Counter] = defaultdict(Counter)
    periods: dict[str, list[Any]] = defaultdict(list)
    for line in preview.lineage:
        if not line.included_in_output:
            continue
        value = _expected_value(line)
        if _is_blank(value):
            continue
        groups[_source_key(line)][_canonical(value)] += 1
        periods[line.standard_period].append(value)
    return dict(groups), dict(periods)


def _build_output_groups(preview: TransformationPreview) -> tuple[dict[tuple[Any, ...], Counter], dict[str, list[Any]], int]:
    periods = _period_order_from_preview(preview)
    dimension_headers = [c for c in preview.prepared_data.columns if c not in {"FACT", *periods}]
    groups: dict[tuple[Any, ...], Counter] = defaultdict(Counter)
    period_values: dict[str, list[Any]] = defaultdict(list)
    count = 0

    for _, row in preview.prepared_data.iterrows():
        fact_value = row["FACT"] if "FACT" in preview.prepared_data.columns else preview.fact_label
        for period in periods:
            if period not in preview.prepared_data.columns:
                continue
            value = row[period]
            if _is_blank(value):
                continue
            count += 1
            key = _output_key(row, dimension_headers, fact_value, period)
            groups[key][_canonical(value)] += 1
            period_values[period].append(value)
    return dict(groups), dict(period_values), count


def _numeric_summary(values: list[Any]) -> tuple[Decimal | None, int, int]:
    total = Decimal(0)
    numeric_count = 0
    nonnumeric_count = 0
    for value in values:
        if _is_blank(value):
            continue
        num = _decimal(value)
        if num is None:
            nonnumeric_count += 1
        else:
            numeric_count += 1
            total += num
    return (total if numeric_count else None), numeric_count, nonnumeric_count


def _decimal_text(value: Decimal | None) -> str | None:
    if value is None:
        return None
    normalized = value.normalize()
    if normalized == 0:
        normalized = Decimal(0)
    return format(normalized, "f")


def validate_transformation(preview: TransformationPreview) -> ValidationReport:
    """Validate one transformed sheet against its source lineage.

    The validator treats dimension + FACT + standardized period as the association
    key and compares the complete multiset of source/output values for each key.
    This catches value swaps that a grand-total-only check would miss.
    """
    checks: list[ValidationCheck] = []
    issues: list[ValidationIssue] = []
    warnings = list(preview.warnings)

    source_groups, source_period_values = _build_source_groups(preview)
    output_groups, output_period_values, output_fact_cells = _build_output_groups(preview)
    source_fact_cells = sum(sum(counter.values()) for counter in source_groups.values())

    # 1) Source lineage coordinates must be unique.
    coordinates = [
        (line.source_sheet, line.source_row, line.source_column)
        for line in preview.lineage
        if not _is_blank(line.source_value)
    ]
    unique_coordinates = len(set(coordinates))
    lineage_unique = unique_coordinates == len(coordinates)
    checks.append(ValidationCheck(
        "Source lineage uniqueness",
        "PASS" if lineage_unique else "FAIL",
        f"{unique_coordinates:,} unique source fact cell(s) out of {len(coordinates):,}",
    ))
    if not lineage_unique:
        issues.append(ValidationIssue(
            "DUPLICATE_LINEAGE",
            "BLOCKER",
            "source coordinates",
            [],
            [],
            "One or more source fact cells were recorded more than once in lineage.",
        ))

    # 2) Fact-cell counts.
    count_match = source_fact_cells == output_fact_cells
    checks.append(ValidationCheck(
        "Fact-cell count preservation",
        "PASS" if count_match else "FAIL",
        f"source={source_fact_cells:,}; prepared={output_fact_cells:,}",
    ))
    if not count_match:
        issues.append(ValidationIssue(
            "FACT_CELL_COUNT_MISMATCH",
            "BLOCKER",
            "all fact cells",
            [str(source_fact_cells)],
            [str(output_fact_cells)],
            "Prepared_Data contains a different number of nonblank fact values than the source lineage.",
        ))

    # 3) Exact key/value association comparison.
    source_keys = set(source_groups)
    output_keys = set(output_groups)
    missing_keys = source_keys - output_keys
    unexpected_keys = output_keys - source_keys
    common_keys = source_keys & output_keys
    mismatched_keys = {key for key in common_keys if source_groups[key] != output_groups[key]}

    for key in sorted(missing_keys, key=_key_text)[:100]:
        issues.append(ValidationIssue(
            "MISSING_OUTPUT_KEY",
            "BLOCKER",
            _key_text(key),
            _counter_to_display(source_groups[key]),
            [],
            "A source dimension + FACT + period combination has no corresponding prepared output value.",
        ))
    for key in sorted(unexpected_keys, key=_key_text)[:100]:
        issues.append(ValidationIssue(
            "UNEXPECTED_OUTPUT_KEY",
            "BLOCKER",
            _key_text(key),
            [],
            _counter_to_display(output_groups[key]),
            "Prepared_Data contains a dimension + FACT + period combination not present in source lineage.",
        ))
    for key in sorted(mismatched_keys, key=_key_text)[:100]:
        issues.append(ValidationIssue(
            "VALUE_ASSOCIATION_MISMATCH",
            "BLOCKER",
            _key_text(key),
            _counter_to_display(source_groups[key]),
            _counter_to_display(output_groups[key]),
            "The output values for this exact dimension + FACT + period combination differ from the source.",
        ))

    association_ok = not missing_keys and not unexpected_keys and not mismatched_keys
    checks.append(ValidationCheck(
        "Dimension + FACT + period association",
        "PASS" if association_ok else "FAIL",
        f"missing={len(missing_keys)}; unexpected={len(unexpected_keys)}; value mismatches={len(mismatched_keys)}",
    ))

    # 4) Overall value multiset preservation (independent of key).
    source_multiset: Counter[tuple[str, str]] = Counter()
    for counter in source_groups.values():
        source_multiset.update(counter)
    output_multiset: Counter[tuple[str, str]] = Counter()
    for counter in output_groups.values():
        output_multiset.update(counter)
    multiset_ok = source_multiset == output_multiset
    checks.append(ValidationCheck(
        "Overall fact-value multiset",
        "PASS" if multiset_ok else "FAIL",
        f"source unique values={len(source_multiset):,}; prepared unique values={len(output_multiset):,}",
    ))
    if not multiset_ok:
        issues.append(ValidationIssue(
            "VALUE_MULTISET_MISMATCH",
            "BLOCKER",
            "all fact values",
            _counter_to_display(source_multiset)[:50],
            _counter_to_display(output_multiset)[:50],
            "The prepared output does not preserve the complete multiset of source fact values.",
        ))

    # 5) Per-period count and numeric reconciliation.
    period_results: list[PeriodValidation] = []
    all_periods = _period_order_from_preview(preview)
    for period in all_periods:
        source_values = source_period_values.get(period, [])
        output_values = output_period_values.get(period, [])
        source_total, source_numeric, source_nonnumeric = _numeric_summary(source_values)
        output_total, output_numeric, output_nonnumeric = _numeric_summary(output_values)
        delta = None
        numeric_ok = True
        if source_total is not None or output_total is not None:
            if source_total is None or output_total is None:
                numeric_ok = False
            else:
                delta = output_total - source_total
                numeric_ok = delta == 0 and source_numeric == output_numeric
        count_ok = len(source_values) == len(output_values)
        nonnumeric_ok = source_nonnumeric == output_nonnumeric
        status = "PASS" if count_ok and numeric_ok and nonnumeric_ok else "FAIL"
        period_results.append(PeriodValidation(
            period=period,
            source_fact_cells=len(source_values),
            output_fact_cells=len(output_values),
            source_numeric_total=_decimal_text(source_total),
            output_numeric_total=_decimal_text(output_total),
            numeric_delta=_decimal_text(delta),
            status=status,
        ))
        if status == "FAIL":
            issues.append(ValidationIssue(
                "PERIOD_RECONCILIATION_MISMATCH",
                "BLOCKER",
                period,
                [f"count={len(source_values)}", f"numeric_total={_decimal_text(source_total)}"],
                [f"count={len(output_values)}", f"numeric_total={_decimal_text(output_total)}"],
                "Source and prepared values do not reconcile for this period.",
            ))

    periods_ok = all(p.status == "PASS" for p in period_results)
    checks.append(ValidationCheck(
        "Per-period reconciliation",
        "PASS" if periods_ok else "FAIL",
        f"{sum(p.status == 'PASS' for p in period_results):,}/{len(period_results):,} period(s) passed",
    ))

    status = "PASS" if all(c.status != "FAIL" for c in checks) and not any(i.severity == "BLOCKER" for i in issues) else "REVIEW_REQUIRED"
    return ValidationReport(
        status=status,
        source_fact_cells=source_fact_cells,
        output_fact_cells=output_fact_cells,
        missing_output_keys=len(missing_keys),
        unexpected_output_keys=len(unexpected_keys),
        value_mismatch_keys=len(mismatched_keys),
        checks=checks,
        per_period=period_results,
        issues=issues,
        warnings=warnings,
    )
