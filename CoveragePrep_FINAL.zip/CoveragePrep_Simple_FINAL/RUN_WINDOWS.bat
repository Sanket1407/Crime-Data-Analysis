@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  call ".venv\Scripts\python.exe" main.py
) else (
  echo Virtual environment not found.
  echo Run SETUP_AND_RUN_WINDOWS.bat first.
  pause
)
