from datetime import date
from pathlib import Path

from openpyxl import Workbook

from coverageprep.periods import parse_period, scan_sheet_periods
from coverageprep.reader import fingerprint_sha256
from coverageprep.scanner import scan_sheet_headers


def test_monthly_period_variants_standardize_to_mmm_yyyy():
    cases = {
        "JAN-26": "Jan 2026",
        "January 2026": "Jan 2026",
        "2026 Jan": "Jan 2026",
        "01/2026": "Jan 2026",
        "2026-01": "Jan 2026",
        "202601": "Jan 2026",
        "Dec 2024": "Dec 2024",
    }
    for source, expected in cases.items():
        parsed = parse_period(source)
        assert parsed.status == "OK", source
        assert parsed.frequency == "Monthly", source
        assert parsed.standard == expected, source


def test_native_date_standardizes_monthly():
    parsed = parse_period(date(2026, 2, 17))
    assert parsed.standard == "Feb 2026"
    assert parsed.frequency == "Monthly"


def test_weekly_and_quarterly_formats_preserve_frequency():
    weekly = ["W05 2026", "WK05-26", "Week 5 2026", "2026-W05", "2026W05"]
    for source in weekly:
        parsed = parse_period(source)
        assert parsed.status == "OK", source
        assert parsed.frequency == "Weekly", source
        assert parsed.standard == "W05 2026", source

    quarterly = ["Q1 2026", "QTR1-26", "Quarter 1 2026", "2026-Q1"]
    for source in quarterly:
        parsed = parse_period(source)
        assert parsed.status == "OK", source
        assert parsed.frequency == "Quarterly", source
        assert parsed.standard == "Q1 2026", source


def test_bimonthly_is_not_forced_to_monthly():
    parsed = parse_period("Jan-Feb 2026")
    assert parsed.status == "OK"
    assert parsed.frequency == "Bimonthly"
    assert parsed.standard == "Jan-Feb 2026"


def test_ambiguous_periods_are_not_guessed():
    month = parse_period("Jan")
    assert month.status == "AMBIGUOUS"
    assert month.standard == "Jan"

    period_code = parse_period("P01")
    assert period_code.status == "AMBIGUOUS"
    assert period_code.standard == "P01"

    fiscal = parse_period("FY26 P01")
    assert fiscal.status == "REVIEW"
    assert fiscal.frequency == "Fiscal"


def test_period_code_with_year_requires_confirmation():
    parsed = parse_period("P01 2026")
    assert parsed.status == "REVIEW"
    assert parsed.standard == "Jan 2026"


def test_multirow_year_month_headers_are_detected(tmp_path: Path):
    path = tmp_path / "multi.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append([2026, 2025, 2024, 2026, 2023, 2023, 2022])
    ws.append(["Jan", "Dec", "Nov", "Feb", "Mar", "Apr", "Dec"])
    ws.append([3462, 2457, 245, 42574, 4513, 6857, 4688])
    ws.append([100, 200, 300, 400, 500, 600, 700])
    wb.save(path)

    header = scan_sheet_headers(path, "Data")
    scan = scan_sheet_periods(path, "Data", header_scan=header)
    column_findings = [f for f in scan.findings if f.location == "COLUMN_HEADER"]
    assert column_findings
    standards = [p.standard for p in column_findings[0].mappings]
    assert standards == [
        "Jan 2026", "Dec 2025", "Nov 2024", "Feb 2026",
        "Mar 2023", "Apr 2023", "Dec 2022",
    ]
    assert not scan.collisions


def test_repeated_year_headers_create_collision(tmp_path: Path):
    path = tmp_path / "years.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append([2026, 2025, 2024, 2026, 2023, 2023, 2022])
    ws.append([3462, 2457, 245, 42574, 4513, 6857, 4688])
    ws.append([100, 200, 300, 400, 500, 600, 700])
    wb.save(path)

    header = scan_sheet_headers(path, "Data")
    scan = scan_sheet_periods(path, "Data", header_scan=header)
    standards = {c.standard_period for c in scan.collisions}
    assert "2026" in standards
    assert "2023" in standards


def test_periods_in_rows_are_detected(tmp_path: Path):
    path = tmp_path / "long.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Brand", "Period", "Sales Value"])
    ws.append(["ABC", "JAN-26", 100])
    ws.append(["ABC", "Feb 2026", 120])
    ws.append(["ABC", "03/2026", 130])
    wb.save(path)

    header = scan_sheet_headers(path, "Shipment")
    scan = scan_sheet_periods(path, "Shipment", header_scan=header)
    row_findings = [f for f in scan.findings if f.location == "ROW_COLUMN"]
    assert len(row_findings) == 1
    assert row_findings[0].source == "Period"
    assert [p.standard for p in row_findings[0].mappings] == ["Jan 2026", "Feb 2026", "Mar 2026"]


def test_year_plus_month_columns_are_detected(tmp_path: Path):
    path = tmp_path / "yearmonth.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Brand", "Year", "Month", "Sales Value"])
    ws.append(["ABC", 2026, "Jan", 100])
    ws.append(["ABC", 2026, "Feb", 120])
    ws.append(["ABC", 2026, "Mar", 130])
    wb.save(path)

    header = scan_sheet_headers(path, "Shipment")
    scan = scan_sheet_periods(path, "Shipment", header_scan=header)
    combined = [f for f in scan.findings if f.location == "COMBINED_COLUMNS"]
    assert len(combined) == 1
    assert combined[0].source_columns == ["Year", "Month"]
    assert [p.standard for p in combined[0].mappings] == ["Jan 2026", "Feb 2026", "Mar 2026"]


def test_sheet_name_period_is_detected(tmp_path: Path):
    path = tmp_path / "sheet_period.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Jan 2026"
    ws.append(["Brand", "Sales"])
    ws.append(["ABC", 100])
    ws.append(["XYZ", 120])
    wb.save(path)

    header = scan_sheet_headers(path, "Jan 2026")
    scan = scan_sheet_periods(path, "Jan 2026", header_scan=header)
    sheet_findings = [f for f in scan.findings if f.location == "SHEET_NAME"]
    assert len(sheet_findings) == 1
    assert sheet_findings[0].mappings[0].standard == "Jan 2026"


def test_period_scan_does_not_modify_source(tmp_path: Path):
    path = tmp_path / "safe.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand", "Jan-26", "Feb-26"])
    ws.append(["ABC", 100, 120])
    wb.save(path)

    before = fingerprint_sha256(path)
    header = scan_sheet_headers(path, "Data")
    scan_sheet_periods(path, "Data", header_scan=header)
    after = fingerprint_sha256(path)
    assert before == after


def test_compact_named_month_year_is_standardized():
    from coverageprep.periods import parse_period
    assert parse_period("FEB2026").standard == "Feb 2026"
    assert parse_period("Apr26").standard == "Apr 2026"
