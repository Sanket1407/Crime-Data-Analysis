from pathlib import Path

from openpyxl import Workbook, load_workbook

from coverageprep.reader import fingerprint_sha256
from coverageprep.scanner import scan_sheet_headers
from coverageprep.transform import transform_selected_sheet
from coverageprep.validation import validate_transformation
from coverageprep.export import export_transformation


def _make_wide(path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Region Name", "Brand Desc", "JAN-26", "Feb 2026"])
    ws.append(["West", "ABC", 100, 120])
    ws.append(["East", "XYZ", 80, 90])
    wb.save(path)


def _build_preview_report(path: Path):
    header = scan_sheet_headers(path, "Data")
    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value", header_scan=header)
    report = validate_transformation(preview)
    return header, preview, report


def test_pass_export_creates_expected_workbook_and_preserves_source(tmp_path: Path):
    source = tmp_path / "shipment.xlsx"
    _make_wide(source)
    before = fingerprint_sha256(source)
    header, preview, report = _build_preview_report(source)

    result = export_transformation(
        source,
        preview,
        report,
        header_scan=header,
        output_dir=tmp_path / "output",
    )

    assert report.status == "PASS"
    assert result.status == "PASS"
    assert result.prepared_sheet_name == "Prepared_Data"
    assert fingerprint_sha256(source) == before

    wb = load_workbook(result.workbook_path, read_only=True, data_only=False)
    try:
        assert wb.sheetnames == [
            "Prepared_Data",
            "Source_Copy",
            "Field_Mapping",
            "Period_Map",
            "Validation",
            "Issues",
            "Recommendations",
            "Audit_Log",
        ]
        ws = wb["Prepared_Data"]
        assert ws["A1"].value == "Region Name"
        assert "FACT" in [cell.value for cell in ws[1]]
        assert "Jan 2026" in [cell.value for cell in ws[1]]
        val = wb["Validation"]
        assert val["B3"].value == "PASS"
    finally:
        wb.close()


def test_review_required_export_uses_draft_sheet_and_filename(tmp_path: Path):
    source = tmp_path / "shipment.xlsx"
    _make_wide(source)
    header, preview, _ = _build_preview_report(source)
    preview.prepared_data.loc[0, "Jan 2026"] = 999
    report = validate_transformation(preview)
    assert report.status == "REVIEW_REQUIRED"

    result = export_transformation(
        source,
        preview,
        report,
        header_scan=header,
        output_dir=tmp_path / "output",
    )
    assert result.workbook_path.endswith("shipment_REVIEW_REQUIRED.xlsx")
    assert result.prepared_sheet_name == "Prepared_Data_DRAFT"

    wb = load_workbook(result.workbook_path, read_only=True)
    try:
        assert "Prepared_Data_DRAFT" in wb.sheetnames
        assert "Prepared_Data" not in wb.sheetnames
    finally:
        wb.close()


def test_source_reference_mode_when_copy_threshold_is_small(tmp_path: Path):
    source = tmp_path / "shipment.xlsx"
    _make_wide(source)
    header, preview, report = _build_preview_report(source)

    result = export_transformation(
        source,
        preview,
        report,
        header_scan=header,
        output_dir=tmp_path / "output",
        source_copy_max_cells=2,
    )
    assert result.source_mode == "Source_Reference"
    wb = load_workbook(result.workbook_path, read_only=True)
    try:
        assert "Source_Reference" in wb.sheetnames
        assert "Source_Copy" not in wb.sheetnames
        ref = wb["Source_Reference"]
        values = {ref.cell(row=i, column=1).value: ref.cell(row=i, column=2).value for i in range(2, ref.max_row + 1)}
        assert values["Original filename"] == "shipment.xlsx"
        assert len(values["SHA-256"]) == 64
    finally:
        wb.close()


def test_prepared_csv_fallback_can_be_forced_with_small_excel_limit(tmp_path: Path):
    source = tmp_path / "shipment.xlsx"
    _make_wide(source)
    header, preview, report = _build_preview_report(source)

    result = export_transformation(
        source,
        preview,
        report,
        header_scan=header,
        output_dir=tmp_path / "output",
        excel_max_rows=2,  # header + two data rows would exceed this test ceiling
    )
    assert result.prepared_csv_path is not None
    assert Path(result.prepared_csv_path).exists()
    assert result.prepared_sheet_name is None

    wb = load_workbook(result.workbook_path, read_only=True)
    try:
        assert "Prepared_Data_Reference" in wb.sheetnames
        assert "Prepared_Data" not in wb.sheetnames
    finally:
        wb.close()


def test_source_copy_records_formula_as_literal_audit_content(tmp_path: Path):
    source = tmp_path / "formula.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand Desc", "JAN-26", "Feb 2026"])
    ws.append(["ABC", "=1+2", 120])
    wb.save(source)

    # Use numeric values only for the actual transform so this test focuses on source evidence.
    # The formula cell remains preserved in Source_Copy and is not executed in the output workbook.
    # Replace the fact with a literal for safe validation after saving a separate auditable formula
    # in a non-period title cell.
    wb = load_workbook(source)
    ws = wb["Data"]
    ws["A3"] = "=LITERAL_SOURCE_TEXT"
    ws["B2"] = 100
    wb.save(source)

    header, preview, report = _build_preview_report(source)
    result = export_transformation(
        source,
        preview,
        report,
        header_scan=header,
        output_dir=tmp_path / "output",
    )
    out = load_workbook(result.workbook_path, read_only=True, data_only=False)
    try:
        copy = out["Source_Copy"]
        headers = [c.value for c in copy[1]]
        original_idx = headers.index("ORIGINAL_VALUE") + 1
        values = [copy.cell(row=r, column=original_idx).value for r in range(2, copy.max_row + 1)]
        assert "=LITERAL_SOURCE_TEXT" in values
    finally:
        out.close()
