from pathlib import Path

import pandas as pd
from openpyxl import Workbook
import pytest

from coverageprep.mapping import detect_single_fact, order_headers_by_role, suggest_field_roles
from coverageprep.transform import TransformationBlocked, transform_selected_sheet


def test_field_roles_preserve_source_names_and_allow_multiple_channel_fields():
    headers = [
        "Market Desc", "Region Name", "Channel Level 1", "Channel Level 2",
        "Product Family", "Brand Desc", "Material Code", "Pack Size",
    ]
    suggestions = suggest_field_roles(headers)
    by_header = {s.source_header: s.role for s in suggestions}
    assert by_header["Region Name"] == "REGION"
    assert by_header["Channel Level 1"] == "CHANNEL"
    assert by_header["Channel Level 2"] == "CHANNEL"
    assert by_header["Product Family"] == "CATEGORY"
    assert by_header["Brand Desc"] == "BRAND"
    assert by_header["Material Code"] == "SKU"
    # Original names are not rewritten.
    assert [s.source_header for s in suggestions] == headers


def test_role_order_groups_fields_without_renaming():
    headers = ["Brand Desc", "Channel Level 2", "Region Name", "Channel Level 1", "Pack Size"]
    ordered = order_headers_by_role(headers)
    assert ordered == ["Region Name", "Channel Level 2", "Channel Level 1", "Brand Desc", "Pack Size"]


def test_single_fact_detection_does_not_treat_numeric_sku_as_fact():
    frame = pd.DataFrame({
        "SKU": [10001, 10002, 10003],
        "Period": ["Jan 2026", "Feb 2026", "Mar 2026"],
        "Sales Value": [3462, 2457, 245],
    })
    result = detect_single_fact(
        frame,
        layout="ROW_PERIODS",
        period_source_columns=["Period"],
        assigned_roles={"SKU": "SKU"},
    )
    assert result.source_column == "Sales Value"
    assert result.status == "OK"


def test_wide_period_transform_keeps_header_names_and_one_fact_series(tmp_path: Path):
    path = tmp_path / "wide.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Region Name", "Channel Level 1", "Brand Desc", "JAN-26", "Feb 2026", "03/2026"])
    ws.append(["West", "MT", "ABC", 100, 120, 130])
    ws.append(["East", "GT", "XYZ", 80, 90, 95])
    wb.save(path)

    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value")
    assert list(preview.prepared_data.columns) == [
        "Region Name", "Channel Level 1", "Brand Desc", "FACT", "Jan 2026", "Feb 2026", "Mar 2026"
    ]
    assert preview.prepared_data["FACT"].tolist() == ["Sales Value", "Sales Value"]
    assert preview.prepared_data["Jan 2026"].tolist() == [100, 80]


def test_long_period_transform_pivots_without_sum(tmp_path: Path):
    path = tmp_path / "long.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Region Name", "Brand Desc", "Period", "Sales Value"])
    ws.append(["West", "ABC", "JAN-26", 100])
    ws.append(["West", "ABC", "Feb 2026", 120])
    ws.append(["West", "ABC", "03/2026", 130])
    wb.save(path)

    preview = transform_selected_sheet(path, "Shipment")
    assert list(preview.prepared_data.columns) == [
        "Region Name", "Brand Desc", "FACT", "Jan 2026", "Feb 2026", "Mar 2026"
    ]
    assert preview.prepared_data.iloc[0]["FACT"] == "Sales Value"
    assert preview.prepared_data.iloc[0]["Jan 2026"] == 100
    assert preview.prepared_data.iloc[0]["Mar 2026"] == 130


def test_year_month_transform(tmp_path: Path):
    path = tmp_path / "ym.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Brand Desc", "Year", "Month", "Sales Value"])
    ws.append(["ABC", 2026, "Jan", 100])
    ws.append(["ABC", 2026, "Feb", 120])
    wb.save(path)

    preview = transform_selected_sheet(path, "Shipment")
    assert list(preview.prepared_data.columns) == ["Brand Desc", "FACT", "Jan 2026", "Feb 2026"]
    assert preview.prepared_data.iloc[0]["Jan 2026"] == 100


def test_multirow_year_month_header_uses_one_fact_series(tmp_path: Path):
    path = tmp_path / "multi.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Product", "Product", "Period", "Period", "Period", "Period"])
    ws.append(["Identity", "Identity", 2026, 2025, 2024, 2026])
    ws.append(["Brand Desc", "Material Code", "Jan", "Dec", "Nov", "Feb"])
    ws.append(["ABC", "A1", 3462, 2457, 245, 42574])
    wb.save(path)

    preview = transform_selected_sheet(path, "Shipment", fact_label="Sales Value")
    assert list(preview.prepared_data.columns) == [
        "Brand Desc", "Material Code", "FACT", "Nov 2024", "Dec 2025", "Jan 2026", "Feb 2026"
    ]
    row = preview.prepared_data.iloc[0]
    assert row["Nov 2024"] == 245
    assert row["Jan 2026"] == 3462
    assert row["Feb 2026"] == 42574


def test_duplicate_pivot_keys_block_instead_of_aggregating(tmp_path: Path):
    path = tmp_path / "dup.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Brand Desc", "Period", "Sales Value"])
    ws.append(["ABC", "Jan 2026", 100])
    ws.append(["ABC", "Jan 2026", 50])
    wb.save(path)

    with pytest.raises(TransformationBlocked, match="aggregation"):
        transform_selected_sheet(path, "Shipment")


def test_numeric_identifier_and_value_column_requires_only_sales_value(tmp_path: Path):
    path = tmp_path / "numeric_id.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Material Code", "Period", "Sales Value"])
    ws.append([10001, "Jan 2026", 3462])
    ws.append([10002, "Feb 2026", 2457])
    wb.save(path)

    # Material Code maps to SKU, so it remains a dimension even though numeric.
    preview = transform_selected_sheet(path, "Shipment")
    assert "Material Code" in preview.prepared_data.columns
    assert preview.fact_label == "Sales Value"


def test_transform_preview_does_not_modify_source(tmp_path: Path):
    from coverageprep.reader import fingerprint_sha256

    path = tmp_path / "safe_transform.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand Desc", "Jan-26", "Feb-26"])
    ws.append(["ABC", 100, 120])
    wb.save(path)

    before = fingerprint_sha256(path)
    transform_selected_sheet(path, "Data", fact_label="Sales Value")
    after = fingerprint_sha256(path)
    assert before == after


def test_formula_fact_cells_block_automatic_transformation(tmp_path: Path):
    path = tmp_path / "formula_fact.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand Desc", "Jan-26", "Feb-26"])
    ws.append(["ABC", "=1+2", 120])
    wb.save(path)
    with pytest.raises(TransformationBlocked, match="formula-derived fact"):
        transform_selected_sheet(path, "Data", fact_label="Sales Value")
