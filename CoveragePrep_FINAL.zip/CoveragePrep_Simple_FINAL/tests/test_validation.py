from pathlib import Path

from openpyxl import Workbook

from coverageprep.transform import transform_selected_sheet
from coverageprep.validation import validate_transformation


def _wide_book(path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Region Name", "Brand Desc", "JAN-26", "Feb 2026"])
    ws.append(["West", "ABC", 100, 120])
    ws.append(["East", "XYZ", 80, 90])
    wb.save(path)


def test_validation_passes_for_wide_period_data(tmp_path: Path):
    path = tmp_path / "wide.xlsx"
    _wide_book(path)
    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value")
    report = validate_transformation(preview)
    assert report.status == "PASS"
    assert report.source_fact_cells == 4
    assert report.output_fact_cells == 4
    assert report.blocking_issue_count == 0
    assert all(item.status == "PASS" for item in report.per_period)


def test_validation_passes_for_row_period_pivot(tmp_path: Path):
    path = tmp_path / "long.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Region Name", "Brand Desc", "Period", "Sales Value"])
    ws.append(["West", "ABC", "Jan-26", 100])
    ws.append(["West", "ABC", "Feb 2026", 120])
    ws.append(["East", "XYZ", "Jan-26", 80])
    ws.append(["East", "XYZ", "Feb 2026", 90])
    wb.save(path)

    preview = transform_selected_sheet(path, "Shipment")
    report = validate_transformation(preview)
    assert report.status == "PASS"
    assert report.source_fact_cells == 4
    assert report.value_mismatch_keys == 0


def test_validation_catches_tampered_value_even_when_shape_is_unchanged(tmp_path: Path):
    path = tmp_path / "tamper.xlsx"
    _wide_book(path)
    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value")
    preview.prepared_data.loc[0, "Jan 2026"] = 999

    report = validate_transformation(preview)
    assert report.status == "REVIEW_REQUIRED"
    assert report.value_mismatch_keys >= 1
    assert any(i.issue_type == "VALUE_ASSOCIATION_MISMATCH" for i in report.issues)


def test_validation_catches_swapped_values_with_same_grand_total(tmp_path: Path):
    path = tmp_path / "swap.xlsx"
    _wide_book(path)
    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value")

    # Same overall total, but values are attached to the wrong Region/Brand.
    a = preview.prepared_data.loc[0, "Jan 2026"]
    b = preview.prepared_data.loc[1, "Jan 2026"]
    preview.prepared_data.loc[0, "Jan 2026"] = b
    preview.prepared_data.loc[1, "Jan 2026"] = a

    report = validate_transformation(preview)
    assert report.status == "REVIEW_REQUIRED"
    assert report.value_mismatch_keys == 2
    # The period total still reconciles, proving association validation adds value.
    jan = next(p for p in report.per_period if p.period == "Jan 2026")
    assert jan.numeric_delta == "0"
    assert jan.status == "PASS"


def test_validation_catches_missing_output_fact_cell(tmp_path: Path):
    path = tmp_path / "missing.xlsx"
    _wide_book(path)
    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value")
    preview.prepared_data.loc[0, "Feb 2026"] = None

    report = validate_transformation(preview)
    assert report.status == "REVIEW_REQUIRED"
    assert report.source_fact_cells == 4
    assert report.output_fact_cells == 3
    assert report.missing_output_keys >= 1
    assert any(i.issue_type == "FACT_CELL_COUNT_MISMATCH" for i in report.issues)


def test_validation_lineage_contains_real_source_coordinates(tmp_path: Path):
    path = tmp_path / "coords.xlsx"
    _wide_book(path)
    preview = transform_selected_sheet(path, "Data", fact_label="Sales Value")
    coords = {(x.source_row, x.source_column) for x in preview.lineage}
    # Header is row 1; first data fact cells are C2/D2 and then C3/D3.
    assert coords == {(2, "C"), (2, "D"), (3, "C"), (3, "D")}
    report = validate_transformation(preview)
    check = next(c for c in report.checks if c.name == "Source lineage uniqueness")
    assert check.status == "PASS"


def test_validation_passes_for_multirow_header_fact_series(tmp_path: Path):
    path = tmp_path / "multi.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Product", "Product", "Period", "Period", "Period", "Period"])
    ws.append(["Identity", "Identity", 2026, 2025, 2024, 2026])
    ws.append(["Brand Desc", "Material Code", "Jan", "Dec", "Nov", "Feb"])
    ws.append(["ABC", "A1", 3462, 2457, 245, 42574])
    wb.save(path)

    preview = transform_selected_sheet(path, "Shipment", fact_label="Sales Value")
    report = validate_transformation(preview)
    assert report.status == "PASS"
    assert report.source_fact_cells == 4
    assert [p.period for p in report.per_period] == ["Nov 2024", "Dec 2025", "Jan 2026", "Feb 2026"]
