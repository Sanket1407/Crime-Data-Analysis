from pathlib import Path
import csv

from openpyxl import Workbook

from coverageprep.reader import inventory_file, fingerprint_sha256


def test_inventory_xlsx_all_sheets(tmp_path: Path):
    path = tmp_path / "shipment.xlsx"
    wb = Workbook()
    ws1 = wb.active
    ws1.title = "KG"
    ws1.append(["Brand", "Jan-26"])
    ws1.append(["ABC", 100])
    ws2 = wb.create_sheet("Units")
    ws2.append(["Brand", "Jan-26"])
    ws2.append(["ABC", 5])
    wb.save(path)

    before = fingerprint_sha256(path)
    inv = inventory_file(path, preview_rows=2)
    after = fingerprint_sha256(path)

    assert inv.sheet_count == 2
    assert [s.name for s in inv.sheets] == ["KG", "Units"]
    assert inv.sheets[0].rows == 2
    assert inv.sheets[0].columns == 2
    assert inv.sheets[0].preview[0] == ["Brand", "Jan-26"]
    assert before == after


def test_inventory_csv(tmp_path: Path):
    path = tmp_path / "shipment.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Brand", "Period", "Sales"])
        writer.writerow(["ABC", "Jan-26", "100"])
        writer.writerow(["ABC", "Feb-26", "120"])

    inv = inventory_file(path, preview_rows=2)

    assert inv.sheet_count == 1
    assert inv.sheets[0].name == "(CSV)"
    assert inv.sheets[0].rows == 3
    assert inv.sheets[0].columns == 3
    assert inv.sheets[0].preview[0] == ["Brand", "Period", "Sales"]
