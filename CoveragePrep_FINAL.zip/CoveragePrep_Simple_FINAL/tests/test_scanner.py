from pathlib import Path
import csv

from openpyxl import Workbook

from coverageprep.reader import fingerprint_sha256
from coverageprep.scanner import scan_sheet_headers


def test_detects_single_header_after_title_rows(tmp_path: Path):
    path = tmp_path / "shipment.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Client Shipment File", None, None, None])
    ws.append([None, None, None, None])
    ws.append(["Generated for internal use", None, None, None])
    ws.append(["Country", "Brand", "SKU", "Sales"])
    ws.append(["India", "ABC", "A1", 100])
    ws.append(["India", "ABC", "A2", 120])
    wb.save(path)

    scan = scan_sheet_headers(path, "Data")

    assert scan.recommended is not None
    assert scan.recommended.start_row == 4
    assert scan.recommended.end_row == 4
    assert scan.recommended.flattened_headers[:4] == ["Country", "Brand", "SKU", "Sales"]


def test_detects_multirow_header(tmp_path: Path):
    path = tmp_path / "multiheader.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Product", None, "Sales Period", None, None])
    ws.append(["Brand", "SKU", "Jan-26", "Feb-26", "Mar-26"])
    ws.append(["ABC", "A1", 100, 120, 130])
    ws.append(["XYZ", "X1", 80, 90, 95])
    wb.save(path)

    scan = scan_sheet_headers(path, "Shipment")

    assert scan.recommended is not None
    assert scan.recommended.start_row == 1
    assert scan.recommended.end_row == 2
    assert scan.recommended.depth == 2
    assert scan.recommended.flattened_headers[:5] == [
        "Product | Brand",
        "Product | SKU",
        "Sales Period | Jan-26",
        "Sales Period | Feb-26",
        "Sales Period | Mar-26",
    ]


def test_detects_numeric_year_header(tmp_path: Path):
    path = tmp_path / "years.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Sales"
    ws.append([2026, 2025, 2024, 2023, 2022])
    ws.append([3462, 2457, 245, 4513, 4688])
    ws.append([4262, 2557, 345, 4613, 4788])
    wb.save(path)

    scan = scan_sheet_headers(path, "Sales")

    assert scan.recommended is not None
    assert scan.recommended.start_row == 1
    assert scan.recommended.end_row == 1
    assert scan.recommended.flattened_headers[:5] == ["2026", "2025", "2024", "2023", "2022"]


def test_detects_csv_header(tmp_path: Path):
    path = tmp_path / "shipment.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Country", "Brand", "Period", "Sales"])
        writer.writerow(["India", "ABC", "Jan-26", "100"])
        writer.writerow(["India", "ABC", "Feb-26", "120"])

    scan = scan_sheet_headers(path, "(CSV)")

    assert scan.recommended is not None
    assert scan.recommended.start_row == 1
    assert scan.recommended.end_row == 1


def test_scanner_does_not_modify_source(tmp_path: Path):
    path = tmp_path / "shipment.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.append(["Brand", "Jan-26"])
    ws.append(["ABC", 100])
    wb.save(path)

    before = fingerprint_sha256(path)
    scan_sheet_headers(path, "Sheet")
    after = fingerprint_sha256(path)

    assert before == after


def test_detects_dense_year_month_multirow_header(tmp_path: Path):
    path = tmp_path / "year_month.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append([2026, 2025, 2024, 2026, 2023, 2023, 2022])
    ws.append(["Jan", "Dec", "Nov", "Feb", "Mar", "Apr", "Dec"])
    ws.append([3462, 2457, 245, 42574, 4513, 6857, 4688])
    ws.append([100, 200, 300, 400, 500, 600, 700])
    wb.save(path)

    scan = scan_sheet_headers(path, "Data")

    assert scan.recommended is not None
    assert scan.recommended.start_row == 1
    assert scan.recommended.end_row == 2
    assert scan.recommended.flattened_headers == [
        "2026 | Jan", "2025 | Dec", "2024 | Nov", "2026 | Feb",
        "2023 | Mar", "2023 | Apr", "2022 | Dec",
    ]


def test_detects_three_row_header(tmp_path: Path):
    path = tmp_path / "three_rows.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Product", None, "Sales", None, None, None])
    ws.append(["Identity", None, 2025, None, 2026, None])
    ws.append(["Brand", "SKU", "Jan", "Feb", "Jan", "Feb"])
    ws.append(["ABC", "A1", 10, 12, 20, 22])
    ws.append(["XYZ", "X1", 8, 9, 15, 18])
    wb.save(path)

    scan = scan_sheet_headers(path, "Data")

    assert scan.recommended is not None
    assert scan.recommended.start_row == 1
    assert scan.recommended.end_row == 3
    assert scan.recommended.depth == 3
