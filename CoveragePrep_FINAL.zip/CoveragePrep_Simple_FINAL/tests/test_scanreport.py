from pathlib import Path
from openpyxl import Workbook, load_workbook
from coverageprep.scanreport import export_scan_report


def test_scan_report_exports_expected_sheets(tmp_path: Path):
    source = tmp_path / "scan.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand", "JAN-26", "FEB2026"])
    ws.append(["ABC", 100, 120])
    wb.save(source)
    target = export_scan_report(source, tmp_path / "out")
    out = load_workbook(target, read_only=True)
    try:
        assert out.sheetnames == [
            "Workbook_Summary", "Sheet_Summary", "Header_Detection",
            "Period_Detection", "Issues", "Recommendations"
        ]
    finally:
        out.close()
