# CoveragePrep IQ — Final Implementation Guide
## What the model does, how each step works, which tool is used, and why

This guide explains the final Hackfest 2026 working model end-to-end. It is written so a team member can understand the business logic, run the application, defend the architecture to judges, and extend it inside the NIQ-approved environment.

---

## 1. Problem translated into an engineering contract

The challenge is not to perform Coverage Analysis itself. The operational problem is the preparation of client shipment files that arrive in inconsistent shapes, names, layouts, time formats and quality levels.

The final model therefore follows four mandatory phases:

1. **Ingest** — read the workbook/CSV, identify structure and possible cleaning issues.
2. **Interpret / Flag** — identify ambiguous fields and let the coverage expert decide; do not guess client meaning.
3. **Transform** — create the standardized row dimensions plus period columns.
4. **Validate** — prove the final output still carries the correct numbers and associations from source.

The most important design constraint is **flexibility first**. Column names can be misleading or completely unrelated to concepts such as Brand or Channel, so the application proposes structure but keeps the user in control.

---

## 2. Why this architecture is stronger than a simple LLM upload prompt

A generic "upload Excel → ask an LLM to clean it" design would be difficult to audit, costly on large files, vulnerable to hallucination, and inconsistent with the requirement to preserve client numbers.

CoveragePrep IQ splits responsibilities deliberately:

- **Agent / AI layer:** decomposes the job and recommends configuration.
- **Human decision layer:** confirms ambiguous semantics and consequential actions.
- **Deterministic transformation layer:** performs pivoting, date formatting, negative-value handling and duplicate operations.
- **Validation layer:** independently checks whether the transformed facts reconcile.

This is why the project's statement is:

> **Agent recommends. Rules transform. Validation proves.**

---

## 3. Tool stack and why each tool is used

| Tool / library | Used for | Why it is appropriate |
|---|---|---|
| **Python** | Entire backend and testable business logic | Mature data ecosystem, easy to audit, works well for hackathon prototyping and production services. |
| **Streamlit** | Human-in-the-loop application UI | Fastest way to provide file upload, editable tables, selectors, approval checkboxes, evidence panels and downloads without building a full frontend stack. |
| **pandas** | Table manipulation and deterministic transformations | Reliable for the provided examples and makes transformation logic transparent to judges. |
| **openpyxl** | Reading `.xlsx` workbooks | Reads Excel sheets without executing macros. |
| **XlsxWriter** | Safe `.xlsx` evidence export | Allows disabling formula/string interpretation and generating multiple evidence sheets. |
| **python-dateutil** | Conservative parsing of period labels | Handles multiple human date formats while the application still requires user confirmation. |
| **hashlib / SHA-256** | Integrity digests | Provides repeatable evidence that numeric facts and dimension-period-value associations were preserved. |
| **zipfile** | XLSX package validation / CSV evidence package | XLSX is an OOXML ZIP; checking the package helps reject invalid or macro-containing inputs. |
| **requests** | Optional NIQ-approved AI API | Keeps the AI integration isolated behind one adapter. |
| **difflib** | Deterministic mapping candidate similarity | Provides a zero-external-dependency fuzzy fallback; recommendation only. |
| **pytest** | Repeatable evidence suite | Judges can rerun the same tests and see pass/fail evidence rather than trust slides. |

### Why Polars / DuckDB are not required in the hackathon model

The final code documents them as the production scaling path for hundreds-of-MB / GB files. The prototype keeps pandas because it is easier to review and demonstrate. The transformation contract is isolated in modules, so a production worker can swap execution engines without changing the UI/approval model.

---

## 4. Final system flow

```text
Client CSV/XLSX
      │
      ▼
[1] SecureIngest
    - extension and file-signature validation
    - reject macro-enabled / unsupported files
      │
      ▼
[2] StructureProfiler
    - candidate header row
    - numeric/date-like fields
    - layout recommendation
      │
      ├──────────── optional ────────────┐
      ▼                                 │
[3] Approved AI Schema Advisor          │
    - structural metadata only           │
    - recommendation, never execution    │
      │                                 │
      └─────────────────────────────────┘
      ▼
[4] Human Mapping Gate
    - retain/delete fields
    - assign roles
    - order/rename
    - define fact/time semantics
    - choose negative/duplicate policies
      │
      ▼
[5] Deterministic Layout Transformer
    - wide / long / matrix / sheet-period
    - preserve row/value lineage
      │
      ▼
[6] Data Quality Agent
    - missing, duplicate, mixed type, negative,
      formatting, blank standard-field warnings
      │
      ▼
[7] Standardization Advisor
    - UOM / pack format / text surface variants
    - explicit human approval only
      │
      ▼
[8] Optional Mapping Advisor
    - approved history → exact ID → exact normalized
      text → fuzzy candidate ranking → optional AI tie-break
    - recommendation only
      │
      ▼
[9] Integrity Gate
    - totals
    - per-period totals
    - numeric multiset
    - fact-cell count
    - dimension+period+value association digest
      │
      ├── FAIL → block export / review
      │
      └── PASS
            ▼
[10] Export Router
     - Excel evidence package if within Excel limits
     - CSV ZIP package if limits are exceeded
```

---

## 5. Step-by-step application walkthrough

### Step 1 — Secure ingest

**UI:** Choose `Upload file` or `Bundled structural demo`.

**Code:** `coverageprep/security.py` + `coverageprep/profiler.py`

**What happens:**

- only `.csv` and `.xlsx` are accepted;
- `.xlsx` must have an OOXML ZIP signature;
- macro content is rejected;
- external-link parts are surfaced as warnings and are never followed;
- file size is checked against a configured cap;
- workbook sheets are listed and profiled.

**Why:** client shipment data is confidential and the Hackfest first-level filter explicitly evaluates secure handling, input validation and data privacy.

---

### Step 2 — Profile the workbook

**Code:** `coverageprep/profiler.py`

The profiler scans each sheet and reports:

- raw shape;
- likely header-row position;
- date-like columns;
- numeric-like columns;
- duplicate/blank headers;
- suggested structural layout;
- confidence and warnings.

The profiler is intentionally **structural**. It does not decide that an arbitrary client field "must be Brand" just because its name looks similar.

---

### Step 3 — Agent plan and optional approved AI

**Code:** `coverageprep/orchestrator.py` and `coverageprep/ai_assist.py`

The orchestrator decomposes the job into tools and approval gates. The plan is visible in the UI so judges can see that the application is agentic rather than a hidden sequence of hard-coded buttons.

If the NIQ-approved endpoint is configured, the Schema Advisor receives structural metadata such as sheet names, shapes and candidate fields. It recommends a layout and ambiguities.

**It cannot directly alter the file.**

Why this is useful:

- deterministic profiling handles obvious structures cheaply;
- AI helps on ambiguous structures;
- the human remains responsible for semantic mapping.

---

### Step 4 — Choose the transformation layout

The user chooses or confirms one of four patterns.

#### A. Wide period columns

Example shape:

```text
Brand | Jan-2025 | Feb-2025 | Mar-2025
```

Tool: `transform_wide()`.

The engine melts the period columns internally, applies approved policies, and pivots back while preserving duplicate occurrence order instead of silently summing rows.

#### B. Long period + value

Example:

```text
Year | Period | Brand | Sales
2024 | P01    | A     | 100
2024 | P02    | A     | 120
```

Tool: `transform_long()`.

The selected period components become a single period label and the selected fact column becomes one output column per period.

#### C. Matrix / crosstab

Example:

```text
             Customer A  Customer B
Period SKU
P01    X          10          20
P02    X          12          22
```

Tool: `transform_matrix()`.

The user identifies:

- where data rows start;
- where matrix values start;
- row descriptor columns;
- header rows that describe matrix columns;
- which matrix dimension is the period.

This is the strongest demo because it proves the application handles data that is not already a normal table.

#### D. Sheet-per-period

Each sheet name is a time period and rows contain the fact value. Tool: `transform_sheet_per_period()`.

Multiple tabs are combined into one period-wide output.

---

### Step 5 — Field designer / human mapping gate

**UI:** editable table with:

- `Keep`;
- `Role`;
- `Output Name`;
- `Position`.

**Why:** the challenge owners explicitly said users need to choose which source fields represent concepts such as Region, Channel, Brand and Category, because client names are not dependable.

Canonical roles are:

```text
Country, Region, Channel, City, State, Category, Brand, SKU, Fact, Extra
```

`Extra` allows useful client information to remain without force-fitting it into an NIQ role.

---

### Step 6 — Choose output mode

#### Generic NIQ Standard

Orders:

```text
Country → Region → Channel → City → State → Category → Brand → SKU → Fact → periods
```

If a canonical role is absent, it is added as a **blank placeholder** only. No source value is guessed.

#### Guide-Specific / Flexible

Uses only the source fields the user decides are required for that example/client.

This allows the model to satisfy the generic target without breaking example-specific requirements.

---

### Step 7 — Date handling

**Tool:** `parse_period()`, `combine_period_components()`, `normalize_period_label()`.

Supported output display formats:

- preserve;
- `YYYY-MM`;
- `MMM-YYYY`;
- `MM.YYYY`;
- `YYYYMM`.

The important rule is that the **source frequency is preserved**. The system does not turn weekly or bi-monthly data into monthly data automatically.

---

### Step 8 — Negative-value policy

The UI has the exact three required options:

- do nothing;
- convert negative to positive;
- convert negative to zero.

The chosen action is recorded with the number of affected cells and the numeric delta.

Why: changing a negative is consequential, so it is never an automatic cleanup rule.

---

### Step 9 — Duplicate policy

Options:

- keep all rows — default;
- remove exact duplicate records;
- aggregate by sum using explicit user-selected keys.

The transformation engine uses an internal occurrence number during pivoting so repeated rows are not accidentally aggregated by pandas.

---

### Step 10 — Data Quality Agent

**Tool:** `coverageprep/quality.py`

The dashboard reports severity, category, field, count/percentage and a recommended next action.

Checks include:

- missing/blank values;
- exact duplicate output rows;
- mixed numeric/text fields;
- whitespace inconsistency;
- case/spacing variants;
- negative period values;
- non-numeric period values;
- absent or blank canonical fields;
- workbook structural warnings.

The agent **flags** issues. It does not repair them silently.

---

### Step 11 — Standardization Advisor

**Tool:** `coverageprep/standardize.py`

This addresses the portal outcome asking for standardization of product descriptions, packs, units, brands, categories, markets and channels while still respecting the deep-dive rule not to assume/overwrite data.

The advisor is conservative:

- **Text / Brand / Category / Channel / Market:** case/spacing/punctuation-equivalent surface variants only.
- **Product Description:** spacing/punctuation formatting only; words are not invented, translated or removed.
- **Pack Size:** format-only parser such as `6X330 ML` → `6 x 330 ML`; quantities are not converted.
- **Unit/UOM:** deterministic synonym map such as `kilograms` → `KG`; no numeric conversion.

Each suggestion shows:

- original value;
- suggested value;
- method;
- confidence;
- affected rows;
- reason;
- approval checkbox.

Nothing changes until the user clicks **Apply approved standardizations**.

After approval, the same approved text mapping is applied to the internal lineage copy and the Integrity Gate is rerun.

---

### Step 12 — Optional Mapping Advisor

**Tool:** `coverageprep/mapping.py`

This is deliberately **recommendation-only**. It allows the project to demonstrate the broader portal requirement without crossing into actual Coverage Analysis.

Candidate cascade:

1. **Previously approved historical identifier mapping**.
2. **Exact identifier match**.
3. **Exact normalized text composite**.
4. **Deterministic fuzzy similarity**.
5. **Optional NIQ-approved AI tie-breaker** for existing candidates only.

The AI tie-breaker has additional guardrails:

- user must explicitly approve sending selected descriptive text;
- no sales values are sent;
- the model may only rank supplied candidates;
- it cannot invent a new product or mapping;
- it still does not write the mapping into shipment output.

The bundled reference is synthetic and exists only to demo the workflow.

---

### Step 13 — Integrity Gate

**Tool:** `coverageprep/validation.py`

This is the project's strongest control.

#### Check 1: overall numeric reconciliation

```text
output total == expected total after explicit user actions
```

#### Check 2: period-level reconciliation

Each output period total must match the internal transformed source representation.

#### Check 3: numeric-value multiset digest

The system hashes the sorted set including duplicate counts of all numeric fact values. This detects lost/duplicated/changed facts even when the grand total happens to match.

#### Check 4: dimension-period-value association digest

The system hashes the full records:

```text
selected dimensions + Fact + period + numeric value
```

This catches a dangerous failure where, for example, `100` moves from Brand A to Brand B while the total remains unchanged.

The evidence suite contains a deliberate negative-control test that swaps values and confirms export is blocked.

#### Check 5: fact-cell count

The number of numeric fact cells after approved actions must match the output fact-cell count.

#### Check 6: unparseable fact cells

Selected fact cells that are non-numeric are flagged rather than coerced or guessed.

**Export is only enabled when the gate passes.**

---

### Step 14 — KPI evidence

**Tool:** `coverageprep/metrics.py`

The application records measurable evidence such as:

- sheets processed;
- output rows/columns;
- fact cells before/after;
- engine runtime;
- integrity status;
- numeric delta;
- exceptions;
- DQ severity counts;
- number of approved standardization changes;
- mapping rows assessed / review required.

The UI also permits a manually measured baseline to be entered. This is deliberately optional because the project must not invent a "manual 4 hours" baseline without measurement.

---

### Step 15 — Export Router

**Tool:** `coverageprep/exporter.py`

If output fits Excel limits, the model writes a multi-sheet XLSX evidence package. If the output exceeds Excel limits, it emits a ZIP containing CSV plus JSON/CSV evidence files.

The XLSX package contains:

1. `Prepared_Data`
2. `Validation_Summary`
3. `Validation_Checks`
4. `Exceptions`
5. `Audit_Log`
6. `Data_Quality`
7. `Standardization`
8. `Mapping_Advisor`
9. `KPI_Summary`
10. `Configuration`

This makes the result reviewable and audit-friendly rather than returning only a flat output file.

---

## 6. Security and Responsible AI controls

The final model includes the following controls:

- file extension and OOXML signature validation;
- reject macro content;
- do not execute external workbook links;
- no credentials in source code;
- endpoint/token/model loaded from environment variables;
- AI is optional and isolated;
- structural metadata only by default;
- human approval before text changes, deletion, aggregation or mapping use;
- audit trail for actions;
- formula-like text detection;
- XLSX export disables formula-string interpretation;
- export blocked when numerical integrity fails.

Production deployment should add NIQ SSO/RBAC, approved object storage, encrypted worker queues, retention policy enforcement and centralized audit logging.

---

## 7. How to run the model

### Windows — recommended

```bat
cd CoveragePrep_IQ_Final
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python benchmarks\generate_benchmarks.py
streamlit run app.py
```

### Automated tests

```bat
python -m pip install -r requirements-dev.txt
python benchmark_runner.py
```

### Evidence report

```bat
python evidence_runner.py
```

### Full non-UI demo

```bat
python demo_run.py
```

### CLI execution from a reusable plan

```bat
python cli.py --input data\benchmark_cases\case2_long_period.xlsx --plan demo_outputs\Transformation_Plan_Demo.json --generic-standard --output demo_outputs\CLI_Validated_Output.xlsx
```

---

## 8. Recommended judge demo

Use two examples.

### Demo A — long-format + standardization + mapping

`case2_long_period.xlsx`

Show:

1. profiler;
2. Year + Period selection;
3. field mapping;
4. transform;
5. DQ issues;
6. Standardization Advisor on Brand/Product Description/Pack Size/Unit;
7. Mapping Advisor with synthetic reference;
8. Integrity Gate PASS;
9. download output workbook.

### Demo B — matrix / KG-UN-LT structure

`case4_matrix_multifact.xlsx`

Show that the same application handles a fundamentally different shape. This is the best proof of generalization.

---

## 9. Current evidence

Run `python benchmark_runner.py` and `python evidence_runner.py` to regenerate evidence.

Current bundled evidence at project finalization:

- 12/12 automated tests pass.
- 8/8 evidence scenarios pass.
- five different structural layouts/process patterns are exercised;
- standardization is approved and revalidated;
- mapping recommendation cascade works against a synthetic reference;
- a deliberately tampered value is correctly rejected by the association-level Integrity Gate.

The bundled evidence is synthetic. Before the final Hackfest submission, run the same harness using the official challenge workbooks inside the approved NIQ environment and capture the measured output/runtime.

---

## 10. Known limitations and production path

The final hackathon model intentionally does not claim that pandas/Streamlit alone is the production architecture for a 1.2 GB or 5 GB workbook.

Production path:

- UI uploads to approved temporary object storage;
- create a job rather than hold the full file in the Streamlit process;
- use Polars/DuckDB lazy scanning for CSV/Parquet;
- use `openpyxl` read-only streaming or approved Excel conversion for large XLSX;
- split transform from UI into a FastAPI/worker service;
- persist the recipe and audit metadata rather than raw data where possible;
- use NIQ SSO/RBAC and least-privilege service identities;
- produce a signed validation/output manifest.

This is a realistic path from hackathon prototype to enterprise implementation without changing the business workflow or validation contract.
