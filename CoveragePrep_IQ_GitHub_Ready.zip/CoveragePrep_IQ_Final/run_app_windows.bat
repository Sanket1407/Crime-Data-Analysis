@echo off
setlocal
python -m venv .venv
call .venv\Scripts\activate
python -m pip install -r requirements.txt
python benchmarks\generate_benchmarks.py
streamlit run app.py
endlocal
