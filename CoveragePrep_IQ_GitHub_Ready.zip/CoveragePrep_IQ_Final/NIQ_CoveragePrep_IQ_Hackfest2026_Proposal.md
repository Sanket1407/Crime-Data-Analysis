# CoveragePrep IQ
## Intelligent Client Data Preparation for Coverage Analysis — Hackfest 2026

### Executive summary
CoveragePrep IQ is a policy-constrained agentic preparation application that converts inconsistent client shipment files into a standardized, reviewable and numerically validated structure for downstream Coverage Analysis. It is deliberately scoped to preparation: it does not calculate Coverage, infer missing client facts, expand ambiguous abbreviations, or silently change shipment data.

Its design principle is:

> **Agent recommends. Rules transform. Validation proves.**

### End-to-end workflow
1. **Secure Ingest** — validate CSV/XLSX input, workbook structure and safe file type.
2. **Profile** — detect likely header rows, date/numeric candidates and structural layout.
3. **Agent Plan** — deterministic orchestration plus optional NIQ-approved AI schema advice.
4. **Human Mapping Gate** — user confirms fields, roles, period/fact semantics, deletion/order and negative/duplicate policies.
5. **Deterministic Transform** — wide, long, matrix/crosstab and sheet-per-period layouts; multi-tab to one prepared output.
6. **Data Quality Review** — missing/inconsistent/duplicate/mixed-type/negative/format issues with actionable recommendations.
7. **Standardization Advisor** — proposes safe surface-format standardizations for product description, pack format, UOM and categorical variants; nothing changes without explicit approval.
8. **Optional Mapping Advisor** — recommends candidate reference mappings using approved history, identifiers, normalized text, deterministic similarity and—when explicitly enabled—approved AI candidate ranking. Mapping advice is separate from shipment transformation and does not calculate Coverage.
9. **Integrity Gate** — reconciles totals, per-period totals, numeric values, fact-cell counts and dimension+period+value associations.
10. **Export Router** — evidence-rich XLSX within Excel limits; CSV ZIP evidence package when limits are exceeded.

### Why this is a strong Hackfest fit
- **Flexibility first:** source headers do not have to match NIQ terminology.
- **Human-controlled semantics:** coverage experts decide what client fields mean when the source is ambiguous.
- **No silent data loss:** deletion, duplicate handling, aggregation, negative handling and standardization are explicit decisions.
- **Validation is a hard gate:** production export is blocked if transformed values or their associations do not reconcile.
- **Agentic, not a chat wrapper:** the orchestrator decomposes the goal and routes through dedicated ingestion, profiling, quality, advice, transform, validation and export tools.
- **Responsible AI:** AI is optional, recommendation-focused, constrained to approved endpoints and subject to human approval.
- **Security-aware:** invalid/unsupported workbooks and macro-enabled content are rejected; raw client data is not sent to arbitrary external services.
- **Evidence-backed:** automated tests, structural benchmark cases, a negative control and exported evidence sheets are bundled with the project.

### Demo differentiator
Use the matrix/multi-fact case to demonstrate non-tabular transformation. Then show the Integrity Gate and the negative-control evidence: a deliberately moved value can preserve the same grand total yet still fail the association digest. This demonstrates why numeric total equality alone is insufficient.

### Current bundled evidence
- 12/12 automated tests pass.
- 8/8 repeatable evidence scenarios pass.
- 5 synthetic structural patterns pass.
- Full demo output reconciles 390.0 source to 390.0 output with 0.0 delta.

The synthetic files reproduce structural patterns for demonstration only. Official client/challenge data must be tested only in the approved NIQ environment.

### Pilot KPIs
- median analyst preparation time per workbook;
- first-pass Integrity Gate success rate;
- manual decisions per workbook;
- exception/customer-clarification rate;
- share completed without developer intervention;
- runtime for representative file sizes;
- approved-AI latency/token cost when enabled.

No percentage time saving should be claimed until an actual analyst baseline is measured.

### Production path
Move execution to an approved worker service with governed temporary storage and lazy/streaming processing for large files, keep recipes/audit evidence versioned, connect the NIQ-approved Luna endpoint behind least-privilege credentials, and hand only validated prepared outputs into the existing downstream Coverage workflow.
