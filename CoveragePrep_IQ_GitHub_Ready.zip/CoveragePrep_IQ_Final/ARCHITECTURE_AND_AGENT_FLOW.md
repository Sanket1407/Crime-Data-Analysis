# CoveragePrep IQ — Architecture and Agent Flow

## Logical architecture

```text
┌───────────────────────────┐
│ Streamlit Human-in-Loop UI│
│ upload / configure / review│
└─────────────┬─────────────┘
              │
              ▼
┌───────────────────────────┐
│ Preparation Orchestrator  │
│ goal decomposition        │
│ approvals + failure policy│
└──────┬───────────┬────────┘
       │           │ optional
       │           ▼
       │   ┌─────────────────────┐
       │   │ NIQ-approved AI     │
       │   │ schema recommendation│
       │   │ candidate tie-break │
       │   └─────────────────────┘
       ▼
┌───────────────────────────┐
│ Deterministic Data Tools  │
│ security / profiling      │
│ transformation / DQ       │
│ standardization / mapping │
└─────────────┬─────────────┘
              ▼
┌───────────────────────────┐
│ Integrity Validator       │
│ totals / periods / hashes │
│ association preservation  │
└─────────────┬─────────────┘
        PASS  │    FAIL → block
              ▼
┌───────────────────────────┐
│ Evidence Export Router    │
│ XLSX or CSV ZIP package   │
└───────────────────────────┘
```

## Why this qualifies as agentic

The project does not use "agentic" as a synonym for chat. The orchestrator decomposes a goal into specialist tools, exposes uncertainty, inserts approval gates and selects a deterministic transformer based on the chosen/identified data shape.

The AI is a specialist advisor, not the executor. This separation is important because the high-risk part of the workflow is preservation of client facts, which is better handled with deterministic code and independently verifiable checks.

## Tool selection logic

| Condition | Selected tool | Reason |
|---|---|---|
| date-like fields already appear as columns | Wide transformer | minimal reshape required |
| period fields + one/more fact columns | Long transformer | explicit pivot from row periods to columns |
| values lie at row×column intersections | Matrix transformer | planar column selection is insufficient |
| time is encoded in worksheet names | Sheet-per-period transformer | preserves sheet time semantics |
| unclear structure | profiler + optional approved AI + human decision | avoid brittle guessing |
| missing/ambiguous text | DQ flag | no source-value assumptions |
| superficial text variants | Standardization Advisor | deterministic, reviewable formatting normalization |
| product/reference candidate search | Mapping Advisor | recommendation only; separate from transformation |
| output facts ready | Integrity Validator | must prove correctness before export |
| Excel limits exceeded | CSV package | prevents failed/invalid Excel export |

## Failure policy

- unsupported file → reject;
- invalid XLSX signature → reject;
- macro content → reject;
- unparseable selected period → stop and ask user to revise configuration;
- non-numeric selected fact → exception + validation failure;
- ambiguous standardization → leave unchanged unless approved;
- mapping uncertainty → `Review Required`;
- numeric/association reconciliation failure → block export;
- approved AI unavailable → continue with deterministic workflow.
