# Migration from the previous AutoCoverage MVP

## Decision
Use the previous MVP as an idea/code baseline, but **replace its product direction** with CoveragePrep IQ because several original features conflict with the deep-dive guardrails.

| Previous MVP behavior | Why it is risky for this challenge | CoveragePrep IQ change |
|---|---|---|
| Fuzzy-resolve brands against a master list | Can infer/replace client meaning; challenge says no assumptions/overwriting | Removed from core pipeline. Brand is a user-mapped source field, preserved as-is. |
| Classify channels into Retailer/Semi-Retailer/Wholesaler | Downstream semantic mapping is not the requested preparation task and can misclassify client-defined fields | Removed. User maps/reorders source fields; ambiguities are flagged. |
| Parse/normalize pack sizes and units | Alters representation and can create unsupported conversions | Removed from default transformation. No unit conversion is performed. |
| “Coverage Readiness Score” | Can be mistaken for actual Coverage Analysis/readiness and introduces arbitrary scoring | Replaced with **Integrity PASS/FAIL** and unresolved-exception counts. |
| 3-year history / value-vs-volume / brand readiness as blocking checks | Useful Coverage context, but not the core challenge and not always relevant to cleaning | Kept out of the transform gate. Can be added later only as non-blocking advisory checks. |
| Persistent client-ID mapping memory | Challenge notes client identity may be unavailable and data must not be shared; cross-client memory creates governance risk | Removed. Reusable transformation plan contains no client values and is user-controlled. |
| One-sheet-at-a-time processing | Does not satisfy multi-tab → one-tab expectation | Added multi-sheet combination across long, wide, matrix and sheet-period patterns. |
| Basic total checks | Challenge expects numerical correctness after transformation | Added overall, per-period and numeric-multiset reconciliation, with export blocking on failure. |
| No explicit required handling for negative values / duplicates | Deep-dive requirements explicitly call these out | Added Keep / Absolute / Zero; Keep / Drop exact / Aggregate sum with human approval. |
| Limited protection against hostile spreadsheet content | Cybersecurity is a first-level gate | Added file-signature validation, macro rejection, external-link non-execution, formula-string-safe XLSX writing and credential isolation. |

## What was worth keeping conceptually
- Streamlit for a fast interactive demo.
- Human-in-the-loop review.
- Confidence-aware planning.
- Modular Python pipeline.
- Optional enterprise-AI assistance.

The new project keeps those strengths while making the solution much closer to the actual challenge statement and judging framework.
