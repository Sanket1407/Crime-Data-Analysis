from __future__ import annotations

import io
import json
import time
from copy import deepcopy
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
import streamlit as st

from coverageprep.ai_assist import ApprovedAIClient
from coverageprep.design import apply_standard_placeholders
from coverageprep.exporter import choose_export, excel_feasible
from coverageprep.mapping import mapping_summary, recommend_mappings
from coverageprep.metrics import build_kpis
from coverageprep.models import CANONICAL_ROLES, DimensionSpec, MatrixHeaderSpec, SheetPlan
from coverageprep.orchestrator import PreparationOrchestrator
from coverageprep.profiler import build_dataframe, parse_period, profile_workbook, read_raw_grid
from coverageprep.quality import analyze_data_quality, summarize_quality
from coverageprep.security import formula_like_text_report, validate_upload
from coverageprep.standardize import (
    STANDARDIZATION_TYPES,
    apply_standardization_decisions,
    generate_standardization_suggestions,
    suggest_standardization_type,
)
from coverageprep.transform import (
    combine_prepared_results,
    revalidate_after_approved_text_changes,
    transform_raw_matrix,
    transform_table,
)


ROOT = Path(__file__).resolve().parent

st.set_page_config(page_title="CoveragePrep IQ", page_icon="🧭", layout="wide")
st.markdown(
    """
    <style>
    .small-note {color:#5d6673;font-size:.90rem}
    .pass {background:#e8f5e9;border:1px solid #90c695;padding:.7rem;border-radius:.5rem}
    .fail {background:#ffebee;border:1px solid #ef9a9a;padding:.7rem;border-radius:.5rem}
    .guard {background:#f6f8fa;border-left:4px solid #3b82f6;padding:.7rem 1rem;border-radius:.25rem}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("🧭 CoveragePrep IQ")
st.caption("Intelligent client shipment preparation for Coverage Analysis: agent recommends, rules transform, validation proves.")
st.markdown(
    '<div class="guard"><b>Scope guardrail:</b> this application prepares shipment data. It does not calculate Coverage, invent missing client values, or silently map client terminology to NIQ data.</div>',
    unsafe_allow_html=True,
)

# Clear stale outputs when the user changes to a new input file.
def clear_result_state() -> None:
    for key in [
        "coverageprep_result", "coverageprep_plan", "coverageprep_assigned_roles",
        "coverageprep_output_roles", "coverageprep_runtime", "std_suggestions",
        "mapping_recommendations", "last_input_signature",
    ]:
        st.session_state.pop(key, None)


with st.sidebar:
    st.header("Guardrails")
    st.markdown(
        "- CSV/XLSX only\n"
        "- No client-value guessing\n"
        "- No automatic column deletion\n"
        "- No default aggregation\n"
        "- Text standardization is recommendation-first\n"
        "- Mapping is recommendation-only\n"
        "- Human approval before consequential actions\n"
        "- Export blocked when numeric integrity fails"
    )
    st.divider()
    st.header("Approved AI")
    ai = ApprovedAIClient()
    st.write("✅ Configured" if ai.configured else "⚪ Not configured")
    st.caption("The deterministic engine works without AI. Configure only the NIQ-approved Hackfest endpoint/token/model.")


# ---------------------------------------------------------------------------
# 1. INGEST
# ---------------------------------------------------------------------------
source_mode = st.radio("Input source", ["Upload file", "Bundled structural demo"], horizontal=True)
if source_mode == "Upload file":
    uploaded = st.file_uploader("Upload a client shipment file", type=["csv", "xlsx"])
    if uploaded is None:
        st.info("Upload a CSV or XLSX. CoveragePrep IQ profiles the workbook before any value-changing action is available.")
        st.stop()
    file_bytes = uploaded.getvalue()
    filename = uploaded.name
else:
    demo_dir = ROOT / "data" / "benchmark_cases"
    demo_files = sorted(demo_dir.glob("*.xlsx"))
    if not demo_files:
        st.error("Bundled benchmark files are missing. Run: python benchmarks/generate_benchmarks.py")
        st.stop()
    demo_name = st.selectbox("Choose a structural demo", [x.name for x in demo_files], index=1 if len(demo_files) > 1 else 0)
    demo_path = demo_dir / demo_name
    file_bytes = demo_path.read_bytes()
    filename = demo_path.name
    st.caption("Bundled demos are synthetic structural analogues of the supplied challenge examples; they contain no client data.")

input_signature = f"{filename}:{len(file_bytes)}:{hash(file_bytes[:2048])}"
if st.session_state.get("last_input_signature") not in {None, input_signature}:
    clear_result_state()
st.session_state["last_input_signature"] = input_signature

try:
    security_warnings = validate_upload(filename, file_bytes)
except Exception as e:
    st.error(f"Upload rejected: {e}")
    st.stop()
for w in security_warnings:
    st.warning(w)


@st.cache_data(show_spinner=False)
def cached_profiles(b: bytes, name: str):
    return [p.to_dict() for p in profile_workbook(b, name)]


profiles = cached_profiles(file_bytes, filename)
prof_df = pd.DataFrame(profiles)
show_cols = [
    "sheet_name", "raw_shape", "header_row_candidate", "predicted_layout",
    "layout_confidence", "date_like_columns", "numeric_like_columns", "warnings",
]

st.subheader("1 · Secure ingest & structure profile")
st.dataframe(prof_df[show_cols], use_container_width=True, hide_index=True)

all_sheets = [p["sheet_name"] for p in profiles]
selected_sheets = st.multiselect("Sheets to prepare", all_sheets, default=all_sheets[:1])
if not selected_sheets:
    st.stop()

reference_sheet = selected_sheets[0]
profile_map = {p["sheet_name"]: p for p in profiles}
ref_profile = profile_map[reference_sheet]

layout_options = ["wide_periods", "long_period_value", "matrix", "sheet_per_period"]
predicted = ref_profile.get("predicted_layout")
layout = st.selectbox(
    "Transformation layout",
    layout_options,
    index=layout_options.index(predicted) if predicted in layout_options else 0,
    format_func=lambda x: {
        "wide_periods": "Wide: period values already in columns",
        "long_period_value": "Long: period field(s) + fact/value field(s)",
        "matrix": "Matrix/crosstab: row descriptors × column headers",
        "sheet_per_period": "Sheet-per-period: each tab represents a period",
    }[x],
)

orchestrator = PreparationOrchestrator()
agent_plan = orchestrator.build_plan(layout, use_ai_suggestion=ai.configured, use_mapping_advisor=True)
with st.expander("Agent flow / tool orchestration", expanded=False):
    st.dataframe(pd.DataFrame([x.to_dict() for x in agent_plan]), hide_index=True, use_container_width=True)
    st.caption("The orchestration is intentionally policy-constrained: recommendations can be automatic; deletions, relabeling and mappings require a person.")

with st.expander("Approved AI schema advisor (optional)", expanded=False):
    if st.button("Ask approved AI for structural recommendation", key="ai_schema"):
        metadata = {
            "filename_extension": Path(filename).suffix.lower(),
            "selected_sheets": selected_sheets,
            "profiles": [{k: v for k, v in profile_map[s].items() if k != "warnings"} for s in selected_sheets],
        }
        rec = ai.recommend_plan(metadata)
        if rec.available:
            st.json(rec.recommendation)
        else:
            st.info(rec.provider_note)
    st.caption("Only structural metadata is sent by default. The suggestion never modifies the workbook.")

# Header row configuration is only used for planar layouts.
header_row = int(ref_profile["header_row_candidate"])
if layout != "matrix":
    header_row = st.number_input("Header row index (0-based)", min_value=0, value=header_row, step=1)
    ref_raw = read_raw_grid(file_bytes, filename, None if reference_sheet == "(CSV)" else reference_sheet)
    if header_row >= len(ref_raw):
        st.error("Header row is outside the sheet.")
        st.stop()
    ref_df = build_dataframe(ref_raw, int(header_row))
    st.caption(f"Reference table: {len(ref_df):,} rows × {len(ref_df.columns):,} columns")
    st.dataframe(ref_df.head(12), use_container_width=True)
else:
    ref_raw = read_raw_grid(file_bytes, filename, None if reference_sheet == "(CSV)" else reference_sheet)
    st.dataframe(ref_raw.head(18), use_container_width=True)


# ---------------------------------------------------------------------------
# 2. INTERPRET + CONFIGURE
# ---------------------------------------------------------------------------
st.subheader("2 · Interpret, configure & approve")

output_mode = st.radio(
    "Output mode",
    ["Generic NIQ Standard", "Guide-Specific / Flexible"],
    horizontal=True,
    help="Generic mode prioritizes Country, Region, Channel, City, State, Category, Brand, SKU, Fact and adds absent roles as blank placeholders. Guide-Specific mode emits only the user-selected source fields plus Fact and periods.",
)

DATE_FORMATS = ["preserve", "YYYY-MM", "MMM-YYYY", "MM.YYYY", "YYYYMM"]
negative_policy = st.radio(
    "Negative numeric values",
    ["keep", "absolute", "zero"],
    horizontal=True,
    format_func=lambda x: {"keep": "Do nothing", "absolute": "Transform to positive", "zero": "Transform to 0"}[x],
)
date_format = st.selectbox("Period output format", DATE_FORMATS, index=1 if layout != "wide_periods" else 0)

duplicate_action = st.radio(
    "Duplicate handling",
    ["keep", "drop_exact", "aggregate_sum"],
    horizontal=True,
    format_func=lambda x: {
        "keep": "Keep all rows (default)",
        "drop_exact": "Drop exact duplicate records",
        "aggregate_sum": "Aggregate duplicate keys by sum (explicit opt-in)",
    }[x],
)
if duplicate_action != "keep":
    st.warning("This is a consequential action. CoveragePrep IQ records it in the audit trail and re-runs reconciliation. Aggregation is never automatic.")

result = None
plan = None
assigned_roles: List[str] = []
output_roles: Dict[str, str] = {}


def role_suggestion(name: str) -> str:
    n = name.strip().lower()
    exact = {
        "country": "Country", "pais": "Country", "país": "Country",
        "region": "Region", "channel": "Channel", "city": "City", "state": "State",
        "category": "Category", "categoria": "Category", "brand": "Brand", "marca": "Brand",
        "sku": "SKU", "product code": "SKU", "item code": "SKU",
    }
    return exact.get(n, "Extra")


def dimension_editor(df_columns: List[str], default_dimensions: List[str]) -> List[DimensionSpec]:
    rows = []
    for pos, col in enumerate(df_columns):
        role = role_suggestion(col)
        rows.append({
            "Source": col,
            "Keep": col in default_dimensions,
            "Role": role,
            "Output Name": role if (role != "Extra" and col in default_dimensions) else col,
            "Position": pos + 1,
        })
    edited = st.data_editor(
        pd.DataFrame(rows),
        hide_index=True,
        use_container_width=True,
        disabled=["Source"],
        column_config={
            "Keep": st.column_config.CheckboxColumn(),
            "Role": st.column_config.SelectboxColumn(options=CANONICAL_ROLES),
            "Position": st.column_config.NumberColumn(min_value=1, step=1),
        },
        key=f"dimension_editor_{layout}_{reference_sheet}",
    )
    specs = []
    for _, r in edited.iterrows():
        if bool(r["Keep"]):
            out_name = str(r["Output Name"]).strip() if pd.notna(r["Output Name"]) else str(r["Source"])
            specs.append(DimensionSpec(
                source=str(r["Source"]), keep=True, role=str(r["Role"]),
                output_name=out_name, position=int(r["Position"]),
            ))
    return specs


def finalize_and_store(res, active_plan, roles: List[str], role_map: Dict[str, str], elapsed: float) -> None:
    generic = output_mode == "Generic NIQ Standard"
    designed, design_audit = apply_standard_placeholders(res.prepared, roles + ["Fact"], add_missing_blank=generic)
    res.prepared = designed
    res.audit_log.extend(design_audit)
    res.metadata["output_mode"] = output_mode
    res.metadata["output_roles"] = role_map
    res.metadata["sheets_processed"] = len(selected_sheets)
    res.metadata["processing_runtime_seconds"] = elapsed
    # Re-run validation after output design. Blank placeholder columns are ignored by the lineage digest.
    res = revalidate_after_approved_text_changes(res, [])
    st.session_state["coverageprep_result"] = res
    st.session_state["coverageprep_plan"] = active_plan
    st.session_state["coverageprep_assigned_roles"] = roles
    st.session_state["coverageprep_output_roles"] = role_map
    st.session_state["coverageprep_runtime"] = elapsed
    st.session_state.pop("std_suggestions", None)
    st.session_state.pop("mapping_recommendations", None)


if layout in {"wide_periods", "long_period_value", "sheet_per_period"}:
    columns = list(map(str, ref_df.columns))
    period_columns: List[str] = []
    period_components: List[str] = []
    value_columns: List[str] = []

    if layout == "wide_periods":
        default_periods = [c for c in columns if parse_period(c) is not None]
        period_columns = st.multiselect("Period columns", columns, default=default_periods)
        default_dims = [c for c in columns if c not in period_columns]
    elif layout == "long_period_value":
        period_components = st.multiselect("Period component column(s)", columns, default=[])
        candidate_numeric = [c for c in columns if c in ref_profile.get("numeric_like_columns", []) and c not in period_components]
        value_columns = st.multiselect("Fact/value column(s)", columns, default=candidate_numeric[:1])
        default_dims = [c for c in columns if c not in set(period_components + value_columns)]
    else:
        candidate_numeric = [c for c in columns if c in ref_profile.get("numeric_like_columns", [])]
        value_columns = st.multiselect("Fact/value column(s)", columns, default=candidate_numeric[:1])
        default_dims = [c for c in columns if c not in value_columns]
        st.caption("Each selected worksheet name becomes the period label; source row values are not used to invent a period.")

    st.markdown("**Output field designer** — choose what stays, its role, final name and order.")
    dimensions = dimension_editor(columns, default_dims)
    assigned_roles = [d.role for d in dimensions]
    output_roles = {d.final_name(): d.role for d in dimensions}
    output_roles["Fact"] = "Fact"
    duplicate_keys = st.multiselect("Duplicate key fields (only used if aggregation is selected)", [d.final_name() for d in dimensions] + ["Fact", "__period"])

    plan = SheetPlan(
        sheet_name=reference_sheet,
        layout=layout,
        header_row=int(header_row),
        dimensions=dimensions,
        period_columns=period_columns,
        period_components=period_components,
        value_columns=value_columns,
        date_format=date_format,
        negative_policy=negative_policy,
        duplicate_action=duplicate_action,
        duplicate_keys=duplicate_keys,
    )

    if st.button("▶ Execute approved preparation plan", type="primary"):
        start = time.perf_counter()
        results = []
        errors = []
        for sheet in selected_sheets:
            try:
                raw = read_raw_grid(file_bytes, filename, None if sheet == "(CSV)" else sheet)
                df = build_dataframe(raw, int(header_row))
                p = deepcopy(plan)
                p.sheet_name = sheet
                if layout == "sheet_per_period":
                    p.sheet_period_value = sheet
                results.append(transform_table(df, p))
            except Exception as e:
                errors.append(f"{sheet}: {e}")
        elapsed = time.perf_counter() - start
        for e in errors:
            st.error(e)
        if results:
            combined = combine_prepared_results(results) if len(results) > 1 else results[0]
            finalize_and_store(combined, plan, assigned_roles, output_roles, elapsed)
            st.success(f"Preparation completed in {elapsed:.3f}s. Review data-quality and integrity evidence below.")

else:
    raw = ref_raw
    nrows, ncols = raw.shape
    c1, c2 = st.columns(2)
    with c1:
        data_start = st.number_input("First data row index (0-based)", min_value=0, max_value=max(0, nrows - 1), value=min(3, max(0, nrows - 1)), step=1)
    with c2:
        value_start = st.number_input("First matrix value column index (0-based)", min_value=1, max_value=max(1, ncols - 1), value=min(4, max(1, ncols - 1)), step=1)

    row_col_options = list(range(0, int(value_start)))
    selected_row_cols = st.multiselect("Row descriptor column indexes", row_col_options, default=row_col_options)
    row_name_rows = []
    for idx in selected_row_cols:
        sample_name = str(raw.iat[max(0, int(data_start) - 1), idx]) if int(data_start) > 0 else f"Column_{idx}"
        if sample_name.strip() in {"", "nan", "None"}:
            sample_name = f"RowDim_{idx}"
        row_name_rows.append({"Column Index": idx, "Output Name": sample_name, "Role": role_suggestion(sample_name)})
    row_editor = st.data_editor(
        pd.DataFrame(row_name_rows), hide_index=True, use_container_width=True,
        disabled=["Column Index"],
        column_config={"Role": st.column_config.SelectboxColumn(options=CANONICAL_ROLES)},
        key="matrix_row_dim_editor",
    ) if row_name_rows else pd.DataFrame()

    header_row_options = list(range(0, int(data_start)))
    selected_header_rows = st.multiselect("Matrix column-header row indexes", header_row_options, default=header_row_options[-1:] if header_row_options else [])
    header_rows = [{"Header Row": idx, "Output Name": f"ColumnDim_{idx}", "Role": "Extra"} for idx in selected_header_rows]
    header_editor = st.data_editor(
        pd.DataFrame(header_rows), hide_index=True, use_container_width=True,
        disabled=["Header Row"],
        column_config={"Role": st.column_config.SelectboxColumn(options=CANONICAL_ROLES)},
        key="matrix_header_editor",
    ) if header_rows else pd.DataFrame()

    matrix_row_dimensions: Dict[int, str] = {}
    assigned_roles = []
    output_roles = {"Fact": "Fact"}
    if not row_editor.empty:
        for _, r in row_editor.iterrows():
            name = str(r["Output Name"])
            role = str(r["Role"])
            matrix_row_dimensions[int(r["Column Index"])] = name
            assigned_roles.append(role)
            output_roles[name] = role
    matrix_headers: List[MatrixHeaderSpec] = []
    if not header_editor.empty:
        for _, r in header_editor.iterrows():
            name = str(r["Output Name"])
            role = str(r["Role"])
            matrix_headers.append(MatrixHeaderSpec(int(r["Header Row"]), name, role))
            assigned_roles.append(role)
            output_roles[name] = role

    period_candidates = list(matrix_row_dimensions.values()) + [h.output_name for h in matrix_headers]
    matrix_period_col = st.selectbox("Which matrix dimension is the period?", period_candidates if period_candidates else [""])
    fact_from_sheet = st.checkbox("Use sheet name as Fact label (recommended for KG/UN/LT-style tabs)", value=len(selected_sheets) > 1)
    fixed_fact = st.text_input("Fixed Fact label", value="Value", disabled=fact_from_sheet)
    duplicate_keys = st.multiselect("Duplicate key fields (only used if aggregation is selected)", period_candidates + ["Fact", "__period"])

    plan = SheetPlan(
        sheet_name=reference_sheet,
        layout="matrix",
        matrix_data_start_row=int(data_start),
        matrix_value_start_col=int(value_start),
        matrix_row_dimensions=matrix_row_dimensions,
        matrix_column_headers=matrix_headers,
        matrix_period_column=matrix_period_col,
        matrix_fact_label=None if fact_from_sheet else fixed_fact,
        date_format=date_format,
        negative_policy=negative_policy,
        duplicate_action=duplicate_action,
        duplicate_keys=duplicate_keys,
    )

    if st.button("▶ Execute approved matrix plan", type="primary"):
        start = time.perf_counter()
        results = []
        errors = []
        for sheet in selected_sheets:
            try:
                raw_sheet = read_raw_grid(file_bytes, filename, None if sheet == "(CSV)" else sheet)
                p = deepcopy(plan)
                p.sheet_name = sheet
                if fact_from_sheet:
                    p.matrix_fact_label = sheet
                results.append(transform_raw_matrix(raw_sheet, p))
            except Exception as e:
                errors.append(f"{sheet}: {e}")
        elapsed = time.perf_counter() - start
        for e in errors:
            st.error(e)
        if results:
            combined = combine_prepared_results(results) if len(results) > 1 else results[0]
            finalize_and_store(combined, plan, assigned_roles, output_roles, elapsed)
            st.success(f"Preparation completed in {elapsed:.3f}s. Review data-quality and integrity evidence below.")


# ---------------------------------------------------------------------------
# 3. QUALITY + STANDARDIZATION + OPTIONAL MAPPING
# ---------------------------------------------------------------------------
result = st.session_state.get("coverageprep_result")
plan = st.session_state.get("coverageprep_plan")
if result is None:
    st.stop()

assigned_roles = st.session_state.get("coverageprep_assigned_roles", [])
output_roles = st.session_state.get("coverageprep_output_roles", {})
runtime_seconds = float(st.session_state.get("coverageprep_runtime", 0.0))
profile_warnings = [w for s in selected_sheets for w in profile_map.get(s, {}).get("warnings", [])]

st.subheader("3 · Data quality & advisory standardization")
quality_issues = analyze_data_quality(result.prepared, assigned_roles=assigned_roles, profile_warnings=profile_warnings)
result.metadata["quality_issues"] = quality_issues
qsum = summarize_quality(quality_issues)
q1, q2, q3, q4 = st.columns(4)
q1.metric("Critical / High", qsum["Critical"] + qsum["High"])
q2.metric("Medium", qsum["Medium"])
q3.metric("Low", qsum["Low"])
q4.metric("Informational", qsum["Info"])
st.dataframe(quality_issues, hide_index=True, use_container_width=True)

with st.expander("Standardization Advisor — recommendations only until approved", expanded=True):
    st.caption("Use this for product descriptions, pack sizes, UOM, brands, categories, markets and channels. Rules are conservative: no brand expansion, no quantity conversion and no taxonomy mapping.")
    eligible_cols = [c for c in result.prepared.columns if c != "Fact" and parse_period(c) is None]
    profile_rows = []
    for c in eligible_cols:
        role = output_roles.get(c, c if c in CANONICAL_ROLES else "Extra")
        profile_rows.append({
            "Use": True,
            "Column": c,
            "Mapped Role": role,
            "Standardization Type": suggest_standardization_type(c, role),
        })
    profile_editor = st.data_editor(
        pd.DataFrame(profile_rows),
        hide_index=True,
        use_container_width=True,
        disabled=["Column", "Mapped Role"],
        column_config={
            "Use": st.column_config.CheckboxColumn(),
            "Standardization Type": st.column_config.SelectboxColumn(options=STANDARDIZATION_TYPES),
        },
        key="standardization_profile_editor",
    ) if profile_rows else pd.DataFrame()

    if st.button("Generate standardization recommendations"):
        profiles_selected = {
            str(r["Column"]): str(r["Standardization Type"])
            for _, r in profile_editor.iterrows() if bool(r["Use"])
        }
        st.session_state["std_suggestions"] = generate_standardization_suggestions(result.prepared, profiles_selected)

    suggestions = st.session_state.get("std_suggestions")
    if isinstance(suggestions, pd.DataFrame):
        if suggestions.empty:
            st.success("No conservative standardization opportunities were detected in the selected fields.")
        else:
            edited_suggestions = st.data_editor(
                suggestions,
                hide_index=True,
                use_container_width=True,
                disabled=["Column", "Profile", "Original", "Suggested", "Method", "Confidence", "Affected Rows", "Reason"],
                column_config={"Apply": st.column_config.CheckboxColumn("Approve")},
                key="standardization_suggestions_editor",
            )
            approved_count = int(edited_suggestions["Apply"].fillna(False).sum())
            st.caption(f"{approved_count} recommendation(s) selected. Nothing changes until you click Apply.")
            if st.button("Apply approved standardizations", disabled=approved_count == 0):
                updated, audit, applied_records = apply_standardization_decisions(result.prepared, edited_suggestions)
                result.prepared = updated
                result.audit_log.extend(audit)
                applied_df = pd.DataFrame(applied_records)
                prior = result.metadata.get("standardization_decisions")
                if isinstance(prior, pd.DataFrame) and not prior.empty:
                    applied_df = pd.concat([prior, applied_df], ignore_index=True)
                result.metadata["standardization_decisions"] = applied_df
                result = revalidate_after_approved_text_changes(result, applied_records)
                st.session_state["coverageprep_result"] = result
                st.session_state.pop("std_suggestions", None)
                st.success("Approved text changes applied and the Integrity Gate was re-run.")
                st.rerun()


with st.expander("Optional Mapping Advisor — recommendation only", expanded=False):
    st.caption("This feature reconciles the broader portal outcome with the deep-dive guardrail: it can recommend candidates against an approved reference, but it never performs Coverage Analysis and never writes the mapping into shipment data automatically.")
    mapping_source = st.radio("Reference source", ["Bundled synthetic reference", "Upload approved reference", "Skip"], horizontal=True)
    reference_df = None
    historical_df = None
    if mapping_source == "Bundled synthetic reference":
        ref_path = ROOT / "data" / "demo_reference" / "niq_product_reference_demo.csv"
        hist_path = ROOT / "data" / "demo_reference" / "historical_mappings_demo.csv"
        if ref_path.exists():
            reference_df = pd.read_csv(ref_path)
            historical_df = pd.read_csv(hist_path) if hist_path.exists() else None
            st.caption("Synthetic reference for demo only — not an NIQ production taxonomy.")
            st.dataframe(reference_df, hide_index=True, use_container_width=True)
    elif mapping_source == "Upload approved reference":
        ref_upload = st.file_uploader("Approved reference CSV/XLSX", type=["csv", "xlsx"], key="mapping_ref_upload")
        hist_upload = st.file_uploader("Optional previously-approved mapping history CSV/XLSX", type=["csv", "xlsx"], key="mapping_hist_upload")

        def read_small_table(up):
            if up is None:
                return None
            b = up.getvalue()
            if up.name.lower().endswith(".csv"):
                return pd.read_csv(io.BytesIO(b))
            return pd.read_excel(io.BytesIO(b))

        reference_df = read_small_table(ref_upload)
        historical_df = read_small_table(hist_upload)

    if reference_df is not None and not reference_df.empty:
        client_cols = [c for c in result.prepared.columns if parse_period(c) is None and c != "Fact"]
        ref_cols = list(map(str, reference_df.columns))
        none_option = "(none)"
        c_id = st.selectbox("Client identifier field", [none_option] + client_cols)
        r_id = st.selectbox("Reference identifier field", [none_option] + ref_cols, index=1 if ref_cols else 0)
        c_text = st.multiselect("Client descriptive fields", client_cols, default=[c for c in client_cols if c in {"Brand", "Category", "SKU", "Product Description", "Marca", "Categoria"}][:3])
        r_text = st.multiselect("Reference descriptive fields", ref_cols, default=ref_cols[1:4] if len(ref_cols) > 1 else ref_cols)
        r_out = st.multiselect("Reference fields to show in recommendation", ref_cols, default=ref_cols[: min(4, len(ref_cols))])
        review_threshold = st.slider("Human review threshold", min_value=0.50, max_value=1.00, value=0.90, step=0.01)

        hist_client_col = hist_ref_col = None
        if historical_df is not None and not historical_df.empty:
            hcols = list(map(str, historical_df.columns))
            st.caption("Optional historical mapping is used before identifier/text similarity.")
            hist_client_col = st.selectbox("Historical client key", [none_option] + hcols)
            hist_ref_col = st.selectbox("Historical reference ID", [none_option] + hcols, index=min(2, len(hcols)) if hcols else 0)

        if st.button("Generate mapping recommendations"):
            recs = recommend_mappings(
                result.prepared,
                reference_df,
                client_identifier_col=None if c_id == none_option else c_id,
                reference_identifier_col=None if r_id == none_option else r_id,
                client_text_cols=c_text,
                reference_text_cols=r_text,
                reference_output_cols=r_out,
                historical_df=historical_df,
                historical_client_identifier_col=None if hist_client_col in {None, none_option} else hist_client_col,
                historical_reference_identifier_col=None if hist_ref_col in {None, none_option} else hist_ref_col,
                top_n=3,
                review_threshold=review_threshold,
            )
            st.session_state["mapping_recommendations"] = recs
            result.metadata["mapping_recommendations"] = recs
            st.session_state["coverageprep_result"] = result

        recs = st.session_state.get("mapping_recommendations")
        if isinstance(recs, pd.DataFrame) and not recs.empty:
            result.metadata["mapping_recommendations"] = recs
            ms = mapping_summary(recs)
            m1, m2, m3 = st.columns(3)
            m1.metric("Client rows assessed", ms["rows"])
            m2.metric("Exact/history candidates", ms["auto_exact"])
            m3.metric("Require review", ms["review_required"])
            st.dataframe(recs.head(500), hide_index=True, use_container_width=True)

            if ai.configured:
                st.markdown("**Optional approved-AI tie-breaker**")
                allow_ai_values = st.checkbox("I approve sending only the selected descriptive text/candidate labels to the NIQ-approved model. No sales values are sent.")
                if allow_ai_values and "Client Row" in recs.columns:
                    row_choice = st.selectbox("Client row to rank", sorted(recs["Client Row"].dropna().unique().tolist()))
                    if st.button("Ask approved AI to rank existing candidates"):
                        subset = recs[recs["Client Row"] == row_choice].head(3)
                        client_text = {c: subset.iloc[0].get(f"Client::{c}") for c in c_text if f"Client::{c}" in subset.columns}
                        candidate_records = subset[[c for c in subset.columns if c.startswith("Candidate::") or c in {"Rank", "Method", "Confidence"}]].to_dict("records")
                        ai_rec = ai.rank_mapping_candidates(client_text, candidate_records)
                        st.json(ai_rec.recommendation if ai_rec.available else {"note": ai_rec.provider_note})


# ---------------------------------------------------------------------------
# 4. VALIDATE
# ---------------------------------------------------------------------------
result = st.session_state.get("coverageprep_result")
quality_issues = analyze_data_quality(result.prepared, assigned_roles=assigned_roles, profile_warnings=profile_warnings)
result.metadata["quality_issues"] = quality_issues
mapping_recs = st.session_state.get("mapping_recommendations")
if isinstance(mapping_recs, pd.DataFrame):
    result.metadata["mapping_recommendations"] = mapping_recs
std_decisions = result.metadata.get("standardization_decisions")
if not isinstance(std_decisions, pd.DataFrame):
    std_decisions = pd.DataFrame()

kpis = build_kpis(
    prepared=result.prepared,
    validation=result.validation,
    elapsed_seconds=runtime_seconds,
    exceptions_count=len(result.exceptions),
    quality_issues=quality_issues,
    standardization_decisions=std_decisions,
    mapping_recommendations=mapping_recs if isinstance(mapping_recs, pd.DataFrame) else pd.DataFrame(),
    sheets_processed=int(result.metadata.get("sheets_processed", len(selected_sheets))),
)
result.metadata["kpis"] = kpis
st.session_state["coverageprep_result"] = result

st.subheader("4 · Integrity Gate & measurable evidence")
val = result.validation
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Integrity", "PASS" if val.passed else "FAIL")
c2.metric("Source numeric total", f"{val.source_numeric_total:,.6g}")
c3.metric("Expected after actions", f"{val.expected_total_after_user_actions:,.6g}")
c4.metric("Output numeric total", f"{val.output_numeric_total:,.6g}", delta=f"{val.delta:,.6g}")
c5.metric("Engine runtime", f"{runtime_seconds:.3f}s")

if val.passed:
    st.markdown('<div class="pass"><b>Export gate passed.</b> Totals reconcile overall and by period; the numeric multiset and the dimension-period-value association digest also reconcile after approved actions.</div>', unsafe_allow_html=True)
else:
    st.markdown('<div class="fail"><b>Export gate failed.</b> Review exceptions/configuration. Production export remains blocked.</div>', unsafe_allow_html=True)

with st.expander("Validation evidence", expanded=True):
    check_rows = [{k: v for k, v in c.items() if k != "details"} for c in val.checks]
    st.dataframe(pd.DataFrame(check_rows), use_container_width=True, hide_index=True)
    for c in val.checks:
        if c.get("check") == "period_level_reconciliation":
            st.markdown("**Period-level reconciliation**")
            st.dataframe(pd.DataFrame(c.get("details", [])), use_container_width=True, hide_index=True)

if result.exceptions:
    st.warning(f"{len(result.exceptions):,} exception(s) were flagged rather than guessed or overwritten.")
    st.dataframe(pd.DataFrame(result.exceptions).head(500), use_container_width=True, hide_index=True)
else:
    st.success("No fact-value parsing exceptions were detected.")

with st.expander("KPI summary for judging / evidence", expanded=True):
    st.dataframe(pd.DataFrame([kpis]), hide_index=True, use_container_width=True)
    manual_baseline = st.number_input("Optional measured manual baseline (minutes) — enter only if your team actually measures it", min_value=0.0, value=0.0, step=1.0)
    if manual_baseline > 0:
        automated_minutes = runtime_seconds / 60.0
        reduction = max(0.0, (1.0 - automated_minutes / manual_baseline) * 100.0)
        st.metric("Engine-time reduction vs entered baseline", f"{reduction:.1f}%")
        st.caption("This compares engine processing time only. For the final pitch, measure the complete human workflow separately before claiming end-to-end TAT reduction.")


# ---------------------------------------------------------------------------
# 5. OUTPUT + AUDIT
# ---------------------------------------------------------------------------
st.subheader("5 · Standardized output preview & audit")
st.caption(f"Output mode: **{result.metadata.get('output_mode', 'Unknown')}**")
st.dataframe(result.prepared.head(100), use_container_width=True)

formula_report = formula_like_text_report(result.prepared)
if formula_report["count_sampled"]:
    st.info(f"Potential spreadsheet-formula-like text detected in {formula_report['count_sampled']} sampled cells. XLSX export disables formula interpretation without altering the values.")

with st.expander("Audit trail", expanded=False):
    st.dataframe(pd.DataFrame(result.audit_log), use_container_width=True, hide_index=True)

if not std_decisions.empty:
    with st.expander("Approved standardization decisions", expanded=False):
        st.dataframe(std_decisions, use_container_width=True, hide_index=True)


# ---------------------------------------------------------------------------
# 6. EXPORT
# ---------------------------------------------------------------------------
st.subheader("6 · Export validated evidence package")
fmt = "XLSX" if excel_feasible(result.prepared) else "CSV package (Excel limits exceeded)"
st.write(f"Export router decision: **{fmt}**")

if val.passed:
    ext, out_name, payload = choose_export(result, plan)
    mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if ext == "xlsx" else "application/zip"
    st.download_button("⬇ Download validated output + evidence", data=payload, file_name=out_name, mime=mime, type="primary")
    st.download_button(
        "⬇ Download transformation plan (reusable, no client values)",
        data=json.dumps(plan.to_dict(), ensure_ascii=False, indent=2),
        file_name="Transformation_Plan.json",
        mime="application/json",
    )
else:
    st.error("Export is blocked until the Integrity Gate passes. This is intentional and is part of the project security/data-governance design.")
