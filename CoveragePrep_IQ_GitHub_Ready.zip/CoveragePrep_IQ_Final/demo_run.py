from __future__ import annotations

import json
import time
from pathlib import Path

import pandas as pd

from coverageprep.design import apply_standard_placeholders
from coverageprep.exporter import to_excel_bytes
from coverageprep.mapping import recommend_mappings
from coverageprep.metrics import build_kpis
from coverageprep.models import DimensionSpec, SheetPlan
from coverageprep.profiler import build_dataframe, read_raw_grid
from coverageprep.quality import analyze_data_quality
from coverageprep.standardize import apply_standardization_decisions, generate_standardization_suggestions
from coverageprep.transform import revalidate_after_approved_text_changes, transform_table

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "demo_outputs"
OUT.mkdir(parents=True, exist_ok=True)


def main() -> None:
    source_path = ROOT / "data" / "benchmark_cases" / "case2_long_period.xlsx"
    b = source_path.read_bytes()
    df = build_dataframe(read_raw_grid(b, source_path.name, "Sheet1"), 0)

    dims = [
        DimensionSpec("Pais", True, "Country", "Country", 1),
        DimensionSpec("Channel", True, "Channel", "Channel", 2),
        DimensionSpec("Categoria", True, "Category", "Category", 3),
        DimensionSpec("Marca", True, "Brand", "Brand", 4),
        DimensionSpec("Product Description", True, "Extra", "Product Description", 5),
        DimensionSpec("Pack Size", True, "Extra", "Pack Size", 6),
        DimensionSpec("Unit", True, "Extra", "Unit", 7),
    ]
    plan = SheetPlan(
        sheet_name="Sheet1",
        layout="long_period_value",
        dimensions=dims,
        period_components=["Año", "Periodo"],
        value_columns=["Sum of Total"],
        date_format="YYYY-MM",
        negative_policy="keep",
        duplicate_action="keep",
    )

    start = time.perf_counter()
    result = transform_table(df, plan)
    result.prepared, design_audit = apply_standard_placeholders(
        result.prepared,
        assigned_roles=["Country", "Channel", "Category", "Brand", "Fact"],
        add_missing_blank=True,
    )
    result.audit_log.extend(design_audit)
    result = revalidate_after_approved_text_changes(result, [])

    profiles = {
        "Brand": "Brand",
        "Channel": "Channel",
        "Category": "Category",
        "Product Description": "Product Description",
        "Pack Size": "Pack Size",
        "Unit": "Unit/UOM",
    }
    suggestions = generate_standardization_suggestions(result.prepared, profiles)
    # Synthetic demonstration of the UI approval step: only high-confidence deterministic suggestions are approved.
    approved = suggestions.copy()
    if not approved.empty:
        approved["Apply"] = approved["Confidence"] >= 0.99
    updated, audit, applied = apply_standardization_decisions(result.prepared, approved)
    result.prepared = updated
    result.audit_log.extend(audit)
    result.metadata["standardization_decisions"] = pd.DataFrame(applied)
    result = revalidate_after_approved_text_changes(result, applied)

    quality = analyze_data_quality(result.prepared, assigned_roles=["Country", "Channel", "Category", "Brand", "Fact"])
    result.metadata["quality_issues"] = quality

    ref = pd.read_csv(ROOT / "data" / "demo_reference" / "niq_product_reference_demo.csv")
    hist = pd.read_csv(ROOT / "data" / "demo_reference" / "historical_mappings_demo.csv")
    mappings = recommend_mappings(
        result.prepared,
        ref,
        client_identifier_col="Brand",
        reference_identifier_col="NIQ_Product_ID",
        client_text_cols=["Brand", "Category", "Product Description"],
        reference_text_cols=["Brand", "Category", "Standard_Product"],
        reference_output_cols=["NIQ_Product_ID", "Brand", "Category", "Standard_Product", "Standard_Pack"],
        historical_df=hist,
        historical_client_identifier_col="Client_Key",
        historical_reference_identifier_col="NIQ_Product_ID",
        top_n=2,
        review_threshold=0.90,
    )
    result.metadata["mapping_recommendations"] = mappings

    elapsed = time.perf_counter() - start
    result.metadata["kpis"] = build_kpis(
        prepared=result.prepared,
        validation=result.validation,
        elapsed_seconds=elapsed,
        exceptions_count=len(result.exceptions),
        quality_issues=quality,
        standardization_decisions=result.metadata["standardization_decisions"],
        mapping_recommendations=mappings,
        sheets_processed=1,
    )

    xlsx = OUT / "CoveragePrep_IQ_Demo_Output.xlsx"
    xlsx.write_bytes(to_excel_bytes(result, plan))
    report = {
        "input": source_path.name,
        "output": xlsx.name,
        "validation_passed": result.validation.passed,
        "source_numeric_total": result.validation.source_numeric_total,
        "output_numeric_total": result.validation.output_numeric_total,
        "numeric_delta": result.validation.delta,
        "approved_standardization_decisions": len(applied),
        "mapping_recommendation_rows": int(len(mappings)),
        "runtime_seconds": round(elapsed, 3),
        "tests_reference": "Run python benchmark_runner.py for the full 12-test suite.",
    }
    (OUT / "CoveragePrep_IQ_Demo_Report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
