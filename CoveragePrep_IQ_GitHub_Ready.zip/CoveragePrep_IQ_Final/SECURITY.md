# Security and data-handling policy

CoveragePrep IQ is a Hackfest prototype for preparing client shipment data. Treat real client data, credentials, mappings, and approved AI endpoints as confidential.

## Repository rules

- Keep this repository **private** unless NIQ explicitly approves public release.
- Do not commit real client shipment files, customer names, production mappings, API tokens, passwords, or `.env` files.
- Use only synthetic/demo data in source control.
- Store runtime secrets in approved environment variables or an approved secret manager.
- Do not send client data to external/unapproved AI services.
- Review `SECURITY_RESPONSIBLE_AI.md` before using the optional AI adapter.

## Built-in controls

The application includes input validation, macro rejection, human approval for consequential transformations, deterministic transformation logic, an audit trail, and an Integrity Gate that can block export when validation fails.

## Reporting a security concern

For an NIQ-internal deployment, follow the applicable NIQ security reporting process and notify the project owner/team lead. Do not post confidential security details in a public issue.
