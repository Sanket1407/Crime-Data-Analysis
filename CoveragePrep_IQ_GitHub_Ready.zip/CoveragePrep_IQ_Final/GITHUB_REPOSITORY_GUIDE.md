# GitHub Repository Guide — Beginner / VS Code

## Recommended repository settings

- **Repository name:** `coverageprep-iq-hackfest-2026`
- **Visibility:** **Private**
- **Default branch:** `main`
- **Description:** Human-in-the-loop Python/Streamlit application for intelligent client shipment data preparation and integrity validation for NIQ Coverage Analysis.

Keep the repository private because the project is NIQ Hackfest work and the production use case involves confidential client data.

## What is safe to commit

The repository package contains source code, documentation, synthetic benchmark workbooks, synthetic demo references, test evidence, and demo output files.

Do **not** commit real client shipment files, production reference/master data, real API tokens, passwords, `.env`, Streamlit secrets, or files copied from restricted internal systems unless your NIQ team has explicitly approved source-control storage.

## VS Code: clone after the remote repository exists

Open VS Code and press `Ctrl+Shift+P`, then run **Git: Clone**, paste the repository URL, choose a local folder, and open the cloned folder.

Or use the VS Code terminal:

```bat
git clone <REPOSITORY_URL>
cd coverageprep-iq-hackfest-2026
```

## First Python setup

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
python benchmarks\generate_benchmarks.py
python -m pytest -q
streamlit run app.py
```

## Daily Git workflow in VS Code

Before editing:

```bat
git pull
```

Create a branch:

```bat
git switch -c feature/my-change
```

After editing and testing:

```bat
python -m pytest -q
git status
git add .
git commit -m "Describe the change"
git push -u origin feature/my-change
```

Then create a Pull Request on GitHub and merge it into `main` after review.

## Important secret rule

`.env` and `.streamlit/secrets.toml` are ignored by Git. Never remove those protections to upload tokens.

An example file, `.env.example`, shows which environment-variable names the optional approved AI adapter expects without storing real credentials.
