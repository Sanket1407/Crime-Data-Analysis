from __future__ import annotations

import json
import time
from copy import deepcopy
from pathlib import Path

import pandas as pd

from coverageprep.mapping import recommend_mappings
from coverageprep.models import DimensionSpec, MatrixHeaderSpec, SheetPlan
from coverageprep.profiler import build_dataframe, read_raw_grid
from coverageprep.standardize import apply_standardization_decisions, generate_standardization_suggestions
from coverageprep.transform import combine_prepared_results, revalidate_after_approved_text_changes, transform_raw_matrix, transform_table
from coverageprep.validation import validate_transformation

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "benchmark_cases"
OUT = ROOT / "evidence"
OUT.mkdir(exist_ok=True)


def dims(*names: str):
    return [DimensionSpec(n, True, "Extra", n, i + 1) for i, n in enumerate(names)]


def timed(name, fn):
    start = time.perf_counter()
    r = fn()
    sec = time.perf_counter() - start
    return {
        "case": name,
        "passed": bool(r.validation.passed),
        "runtime_seconds": round(sec, 4),
        "source_total": r.validation.source_numeric_total,
        "output_total": r.validation.output_numeric_total,
        "delta": r.validation.delta,
        "output_rows": len(r.prepared),
        "output_columns": len(r.prepared.columns),
        "exceptions": len(r.exceptions),
    }, r


def case1():
    b = (DATA / "case1_wide_periods.xlsx").read_bytes()
    df = build_dataframe(read_raw_grid(b, "case1_wide_periods.xlsx", "Sheet1"), 0)
    p = SheetPlan(sheet_name="Sheet1", layout="wide_periods", dimensions=dims("L1_3 - Bottler", "L1_2 - Division", "Brand"), period_columns=["2025 Feb", "2025 Jan", "2025 Mar"], date_format="YYYY-MM")
    return transform_table(df, p)


def case2():
    b = (DATA / "case2_long_period.xlsx").read_bytes()
    df = build_dataframe(read_raw_grid(b, "case2_long_period.xlsx", "Sheet1"), 0)
    p = SheetPlan(sheet_name="Sheet1", layout="long_period_value", dimensions=dims("Pais", "Channel", "Categoria", "Marca", "Product Description", "Pack Size", "Unit"), period_components=["Año", "Periodo"], value_columns=["Sum of Total"], date_format="YYYY-MM")
    return transform_table(df, p)


def case3():
    b = (DATA / "case3_multisheet_years.xlsx").read_bytes()
    base = SheetPlan(sheet_name="", layout="long_period_value", dimensions=dims("Channel", "Brand", "SKU"), period_components=["DisplayYear", "DisplayMonth"], value_columns=["RDBN_Quantity"], date_format="YYYY-MM")
    rs = []
    for sheet in ["2022", "2023", "2024"]:
        df = build_dataframe(read_raw_grid(b, "case3_multisheet_years.xlsx", sheet), 0)
        p = deepcopy(base); p.sheet_name = sheet
        rs.append(transform_table(df, p))
    return combine_prepared_results(rs)


def case4():
    b = (DATA / "case4_matrix_multifact.xlsx").read_bytes()
    rs = []
    for sheet in ["KG", "UN", "LT"]:
        raw = read_raw_grid(b, "case4_matrix_multifact.xlsx", sheet)
        p = SheetPlan(sheet_name=sheet, layout="matrix", matrix_data_start_row=3, matrix_value_start_col=3, matrix_row_dimensions={0: "Period", 1: "SKU"}, matrix_column_headers=[MatrixHeaderSpec(0, "Customer"), MatrixHeaderSpec(1, "Customer Group")], matrix_period_column="Period", matrix_fact_label=sheet, date_format="MM.YYYY")
        rs.append(transform_raw_matrix(raw, p))
    return combine_prepared_results(rs)


def case5():
    b = (DATA / "case5_sheet_per_period.xlsx").read_bytes()
    rs = []
    for sheet in ["2023-01", "2023-02", "2023-03"]:
        df = build_dataframe(read_raw_grid(b, "case5_sheet_per_period.xlsx", sheet), 0)
        p = SheetPlan(sheet_name=sheet, layout="sheet_per_period", dimensions=dims("Distributor", "SKU"), value_columns=["VOL"], sheet_period_value=sheet, date_format="YYYY-MM")
        rs.append(transform_table(df, p))
    return combine_prepared_results(rs)


def main():
    rows = []
    results = {}
    for name, fn in [
        ("1 - Wide period columns", case1),
        ("2 - Long Year/Period + value", case2),
        ("3 - Multi-sheet years", case3),
        ("4 - Matrix multi-fact", case4),
        ("5 - Sheet-per-period", case5),
    ]:
        row, r = timed(name, fn)
        rows.append(row); results[name] = r

    # Standardization evidence on case 2.
    r2 = results["2 - Long Year/Period + value"]
    profiles = {"Marca": "Brand", "Product Description": "Product Description", "Pack Size": "Pack Size", "Unit": "Unit/UOM"}
    suggestions = generate_standardization_suggestions(r2.prepared, profiles)
    approved = suggestions.copy()
    if not approved.empty:
        approved["Apply"] = approved["Confidence"] >= 0.99
    updated, audit, applied = apply_standardization_decisions(r2.prepared, approved)
    r2.prepared = updated; r2.audit_log.extend(audit)
    r2 = revalidate_after_approved_text_changes(r2, applied)
    rows.append({
        "case": "6 - Approved text standardization + revalidation",
        "passed": bool(r2.validation.passed),
        "runtime_seconds": None,
        "source_total": r2.validation.source_numeric_total,
        "output_total": r2.validation.output_numeric_total,
        "delta": r2.validation.delta,
        "output_rows": len(r2.prepared),
        "output_columns": len(r2.prepared.columns),
        "exceptions": len(r2.exceptions),
        "extra_evidence": f"{len(applied)} approved suggestions applied",
    })

    # Mapping evidence using synthetic reference/history.
    ref = pd.read_csv(ROOT / "data" / "demo_reference" / "niq_product_reference_demo.csv")
    hist = pd.read_csv(ROOT / "data" / "demo_reference" / "historical_mappings_demo.csv")
    # case2 uses source-style field names because this runner did not rename dimensions.
    maps = recommend_mappings(r2.prepared, ref, client_identifier_col="Marca", reference_identifier_col="NIQ_Product_ID", client_text_cols=["Marca", "Categoria", "Product Description"], reference_text_cols=["Brand", "Category", "Standard_Product"], reference_output_cols=["NIQ_Product_ID", "Brand", "Category"], historical_df=hist, historical_client_identifier_col="Client_Key", historical_reference_identifier_col="NIQ_Product_ID", top_n=2)
    rows.append({
        "case": "7 - Mapping Advisor recommendation cascade",
        "passed": bool(not maps.empty and (maps["Method"] != "unresolved").all()),
        "runtime_seconds": None,
        "source_total": None,
        "output_total": None,
        "delta": None,
        "output_rows": len(maps),
        "output_columns": len(maps.columns),
        "exceptions": int((maps["Method"] == "unresolved").sum()),
        "extra_evidence": "recommendation-only; shipment values unchanged",
    })

    # Negative control: deliberately swap values across brands and verify validator rejects it.
    tamper = case2()
    period_cols = [c for c in tamper.prepared.columns if str(c).startswith("2024-")]
    if len(tamper.prepared) >= 2 and period_cols:
        c = period_cols[0]
        a, b = tamper.prepared.index[:2]
        tamper.prepared.loc[a, c], tamper.prepared.loc[b, c] = tamper.prepared.loc[b, c], tamper.prepared.loc[a, c]
    v = validate_transformation(long_df=tamper.metadata["_long_df"], prepared=tamper.prepared, source_numeric_total=tamper.validation.source_numeric_total, expected_numeric_total=tamper.validation.expected_total_after_user_actions, fact_cells_before=tamper.validation.fact_cell_count_before, row_count_before=tamper.validation.row_count_before, exceptions=tamper.exceptions)
    rows.append({
        "case": "8 - Negative control: mis-associated value is blocked",
        "passed": bool(not v.passed),
        "runtime_seconds": None,
        "source_total": v.source_numeric_total,
        "output_total": v.output_numeric_total,
        "delta": v.delta,
        "output_rows": v.row_count_after,
        "output_columns": len(tamper.prepared.columns),
        "exceptions": 0,
        "extra_evidence": "PASS means the validator correctly rejected the tampered output",
    })

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "evidence_report.csv", index=False)
    summary = {
        "generated": True,
        "all_evidence_cases_passed": bool(df["passed"].all()),
        "evidence_cases": int(len(df)),
        "structural_cases": 5,
        "report": rows,
        "important_note": "All bundled workbooks and reference mappings are synthetic structural analogues. Run the same evidence harness against the official challenge examples before final submission.",
    }
    (OUT / "evidence_report.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(df.to_string(index=False))
    print("\nAll passed:", summary["all_evidence_cases_passed"])


if __name__ == "__main__":
    main()
