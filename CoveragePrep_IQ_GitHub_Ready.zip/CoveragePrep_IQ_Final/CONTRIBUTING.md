# Contributing

This repository is intended for the Hackfest 2026 project team.

1. Create a short-lived branch from `main`.
2. Keep client/confidential data out of commits.
3. Add or update tests for transformation or validation changes.
4. Run `python -m pytest -q` before opening a pull request.
5. Explain any change that can alter shipment values, row associations, date handling, duplicate handling, or export behavior.
6. Do not weaken the Integrity Gate or human-approval safeguards without explicit team review.

Suggested branch names:

- `feature/<short-name>`
- `fix/<short-name>`
- `docs/<short-name>`
