# CoveragePrep IQ — Hackfest 2026 Evaluation Map

## 25% Technical Implementation & Scalability

**What to show**

- Upload a synthetic workbook.
- Profile sheets and detect candidate layout.
- Configure/approve fields.
- Transform at least one long-format example and one matrix example.
- Apply a standardization recommendation.
- Show Integrity Gate PASS.
- Download the evidence workbook.

**Code evidence**

- `coverageprep/profiler.py`
- `coverageprep/transform.py`
- `coverageprep/validation.py`
- `coverageprep/exporter.py`
- `cli.py`

**Scalability story**

The hackathon UI is local/interactive. Production moves raw files to approved object storage and runs the same plan in a worker using streaming/lazy engines such as Polars/DuckDB, while the UI exchanges only recipes, status and evidence.

---

## 25% Business Value

**Target user:** Customer Support / Customer Success associate preparing client shipment data.

**Value:** replaces repeated manual reshape, date handling, duplicate decisions, QA checks and reconciliation with one standardized, reviewable workflow.

**Measured prototype evidence:** runtime, rows/columns, exceptions, DQ counts and 0-delta validation are captured automatically.

**Do not invent:** manual-hours saved. Measure a real baseline in the NIQ environment before final submission.

---

## 20% Agentic Quality

The visible orchestrator decomposes the preparation goal into:

1. SecureIngest
2. StructureProfiler
3. Optional ApprovedAISchemaAdvisor
4. HumanMappingGate
5. layout-specific Transformer
6. DataQualityAgent
7. StandardizationAdvisor
8. optional MappingAdvisor
9. IntegrityValidator
10. ExportRouter

The agent selects specialist tools, handles uncertainty and routes consequential decisions to a person. It is not an LLM chat wrapper.

---

## 10% Outcome Accuracy & Evidence

Current bundled evidence:

- 12 automated tests passing.
- 8 evidence scenarios passing.
- overall and period-level numeric reconciliation.
- value multiset preservation.
- fact-cell count preservation.
- dimension+period+value association digest.
- deliberate tamper negative-control test correctly blocks export.

Files:

- `benchmark_results.json`
- `evidence/evidence_report.csv`
- `evidence/evidence_report.json`
- `demo_outputs/CoveragePrep_IQ_Demo_Output.xlsx`

---

## 10% Responsible AI & Security

- supported file validation;
- macro rejection;
- no embedded credentials;
- approved AI only;
- structural metadata only by default;
- optional descriptive-text candidate ranking requires explicit user consent;
- no sales values sent to AI mapping tie-breaker;
- human approval for deletion/aggregation/text changes;
- audit trail;
- fail-closed export when integrity fails.

---

## 10% Presentation & Communication

The 5-minute demo should show a working flow, not architecture-only slides.

Recommended story:

1. 30 sec — problem.
2. 45 sec — upload/profile and agent plan.
3. 75 sec — field mapping + transform.
4. 60 sec — DQ + standardization + optional mapping recommendation.
5. 60 sec — Integrity Gate including association check.
6. 30 sec — evidence/impact/scale and close.
