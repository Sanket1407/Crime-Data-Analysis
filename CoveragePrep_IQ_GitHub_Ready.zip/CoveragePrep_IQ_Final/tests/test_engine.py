from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import io

import pandas as pd

from coverageprep.models import DimensionSpec, MatrixHeaderSpec, SheetPlan
from coverageprep.profiler import build_dataframe, read_raw_grid
from coverageprep.transform import transform_table, transform_raw_matrix, combine_prepared_results
from coverageprep.exporter import excel_feasible

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "benchmark_cases"


def _bytes(name: str) -> bytes:
    return (DATA / name).read_bytes()


def _dims(*names: str):
    return [DimensionSpec(n, True, "Extra", n, i + 1) for i, n in enumerate(names)]


def test_case1_wide_periods_preserves_values_and_orders_periods():
    b = _bytes("case1_wide_periods.xlsx")
    raw = read_raw_grid(b, "case1_wide_periods.xlsx", "Sheet1")
    df = build_dataframe(raw, 0)
    plan = SheetPlan(
        sheet_name="Sheet1", layout="wide_periods",
        dimensions=_dims("L1_3 - Bottler", "L1_2 - Division", "Brand"),
        period_columns=["2025 Feb", "2025 Jan", "2025 Mar"], date_format="YYYY-MM",
        negative_policy="keep",
    )
    r = transform_table(df, plan)
    assert r.validation.passed
    assert r.validation.source_numeric_total == 95.0
    assert r.validation.output_numeric_total == 95.0
    assert [c for c in r.prepared.columns if c.startswith("2025-")] == ["2025-01", "2025-02", "2025-03"]


def test_negative_policy_is_explicit_and_reconciled():
    b = _bytes("case1_wide_periods.xlsx")
    df = build_dataframe(read_raw_grid(b, "case1_wide_periods.xlsx", "Sheet1"), 0)
    plan = SheetPlan(
        sheet_name="Sheet1", layout="wide_periods",
        dimensions=_dims("Brand"), period_columns=["2025 Feb", "2025 Jan", "2025 Mar"],
        date_format="YYYY-MM", negative_policy="absolute",
    )
    r = transform_table(df, plan)
    assert r.validation.passed
    assert r.validation.source_numeric_total == 95.0
    assert r.validation.expected_total_after_user_actions == 105.0
    assert r.validation.output_numeric_total == 105.0


def test_case2_long_period_pivots_without_implicit_sum():
    b = _bytes("case2_long_period.xlsx")
    df = build_dataframe(read_raw_grid(b, "case2_long_period.xlsx", "Sheet1"), 0)
    plan = SheetPlan(
        sheet_name="Sheet1", layout="long_period_value",
        dimensions=_dims("Pais", "Channel", "Categoria", "Marca"),
        period_components=["Año", "Periodo"], value_columns=["Sum of Total"], date_format="YYYY-MM",
    )
    r = transform_table(df, plan)
    assert r.validation.passed
    assert r.validation.output_numeric_total == 390.0
    assert {"2024-01", "2024-02"}.issubset(set(r.prepared.columns))


def test_case3_multisheet_combines_to_one_period_wide_output():
    b = _bytes("case3_multisheet_years.xlsx")
    base = SheetPlan(
        sheet_name="", layout="long_period_value",
        dimensions=_dims("Channel", "Brand", "SKU"),
        period_components=["DisplayYear", "DisplayMonth"], value_columns=["RDBN_Quantity"], date_format="YYYY-MM",
    )
    results = []
    for sheet in ["2022", "2023", "2024"]:
        df = build_dataframe(read_raw_grid(b, "case3_multisheet_years.xlsx", sheet), 0)
        p = deepcopy(base); p.sheet_name = sheet
        results.append(transform_table(df, p))
    r = combine_prepared_results(results)
    assert r.validation.passed
    assert r.validation.output_numeric_total == sum([11,13,17,19,23,29])
    assert {"2022-01", "2022-02", "2023-01", "2023-02", "2024-01", "2024-02"}.issubset(r.prepared.columns)
    # Same SKU rows should have periods from multiple sheets on one row rather than one row per sheet.
    assert len(r.prepared) == 2


def test_case4_matrix_multifact():
    b = _bytes("case4_matrix_multifact.xlsx")
    results = []
    for sheet in ["KG", "UN", "LT"]:
        raw = read_raw_grid(b, "case4_matrix_multifact.xlsx", sheet)
        plan = SheetPlan(
            sheet_name=sheet, layout="matrix",
            matrix_data_start_row=3, matrix_value_start_col=3,
            matrix_row_dimensions={0: "Period", 1: "SKU"},
            matrix_column_headers=[
                MatrixHeaderSpec(0, "Customer"),
                MatrixHeaderSpec(1, "Customer Group"),
            ],
            matrix_period_column="Period", matrix_fact_label=sheet,
            date_format="MM.YYYY",
        )
        results.append(transform_raw_matrix(raw, plan))
    r = combine_prepared_results(results)
    assert r.validation.passed
    expected = (10+20+12+22+5+7+6+8) * (1+10+2)
    assert r.validation.output_numeric_total == expected
    assert set(r.prepared["Fact"]) == {"KG", "UN", "LT"}
    assert {"01.2020", "02.2020"}.issubset(r.prepared.columns)


def test_case5_sheet_per_period_combines_sheets():
    b = _bytes("case5_sheet_per_period.xlsx")
    results = []
    for sheet in ["2023-01", "2023-02", "2023-03"]:
        df = build_dataframe(read_raw_grid(b, "case5_sheet_per_period.xlsx", sheet), 0)
        plan = SheetPlan(
            sheet_name=sheet, layout="sheet_per_period",
            dimensions=_dims("Distributor", "SKU"),
            value_columns=["VOL"], sheet_period_value=sheet, date_format="YYYY-MM",
        )
        results.append(transform_table(df, plan))
    r = combine_prepared_results(results)
    assert r.validation.passed
    assert len(r.prepared) == 2
    assert r.validation.output_numeric_total == 330.0
    assert {"2023-01", "2023-02", "2023-03"}.issubset(r.prepared.columns)


def test_duplicate_rows_are_not_aggregated_by_default():
    df = pd.DataFrame({"Brand": ["A", "A"], "Year": [2024, 2024], "Month": [1, 1], "Sales": [10, 10]})
    plan = SheetPlan(
        sheet_name="x", layout="long_period_value", dimensions=_dims("Brand"),
        period_components=["Year", "Month"], value_columns=["Sales"], date_format="YYYY-MM",
        duplicate_action="keep",
    )
    r = transform_table(df, plan)
    assert r.validation.passed
    assert len(r.prepared) == 2
    assert r.validation.output_numeric_total == 20


def test_excel_feasibility_guard():
    assert excel_feasible(pd.DataFrame({"x": [1,2,3]}))


def test_integrity_gate_catches_value_attached_to_wrong_dimension():
    df = pd.DataFrame({"Brand": ["A", "B"], "Year": [2024, 2024], "Month": [1, 1], "Sales": [10, 20]})
    plan = SheetPlan(
        sheet_name="x", layout="long_period_value", dimensions=_dims("Brand"),
        period_components=["Year", "Month"], value_columns=["Sales"], date_format="YYYY-MM",
    )
    r = transform_table(df, plan)
    assert r.validation.passed
    # Swap values across brands without changing totals. The stronger lineage digest must fail.
    r.prepared.loc[0, "2024-01"], r.prepared.loc[1, "2024-01"] = r.prepared.loc[1, "2024-01"], r.prepared.loc[0, "2024-01"]
    from coverageprep.validation import validate_transformation
    v = validate_transformation(
        long_df=r.metadata["_long_df"], prepared=r.prepared,
        source_numeric_total=r.validation.source_numeric_total,
        expected_numeric_total=r.validation.expected_total_after_user_actions,
        fact_cells_before=r.validation.fact_cell_count_before,
        row_count_before=r.validation.row_count_before,
        exceptions=r.exceptions,
    )
    assert not v.passed
    assoc = [c for c in v.checks if c["check"] == "dimension_period_value_association_preserved"][0]
    assert assoc["passed"] is False


def test_standardization_is_explicit_and_revalidated():
    from coverageprep.standardize import generate_standardization_suggestions, apply_standardization_decisions
    from coverageprep.transform import revalidate_after_approved_text_changes
    df = pd.DataFrame({"Brand": ["Oreo", " OREO "], "Year": [2024, 2024], "Month": [1, 2], "Sales": [10, 20]})
    plan = SheetPlan(
        sheet_name="x", layout="long_period_value", dimensions=_dims("Brand"),
        period_components=["Year", "Month"], value_columns=["Sales"], date_format="YYYY-MM",
    )
    r = transform_table(df, plan)
    sugg = generate_standardization_suggestions(r.prepared, {"Brand": "Brand"})
    assert not sugg.empty
    target = sugg[sugg["Original"].astype(str).str.contains("OREO", case=False, regex=False)].head(1).copy()
    target.loc[:, "Apply"] = True
    updated, audit, applied = apply_standardization_decisions(r.prepared, target)
    r.prepared = updated
    r.audit_log.extend(audit)
    r = revalidate_after_approved_text_changes(r, applied)
    assert r.validation.passed
    assert len(applied) == 1


def test_mapping_advisor_exact_identifier_and_reviewable_fuzzy():
    from coverageprep.mapping import recommend_mappings
    client = pd.DataFrame({"SKU": ["A", "X"], "Brand": ["MAGGI", "OREO CHOCO"]})
    ref = pd.DataFrame({"NIQ_ID": ["A", "B"], "Brand": ["MAGGI", "OREO CHOCO"], "Category": ["Food", "Food"]})
    recs = recommend_mappings(
        client, ref,
        client_identifier_col="SKU", reference_identifier_col="NIQ_ID",
        client_text_cols=["Brand"], reference_text_cols=["Brand"],
        reference_output_cols=["Brand", "Category"], top_n=1,
    )
    row0 = recs[recs["Client Row"] == 0].iloc[0]
    assert row0["Method"] == "exact_identifier"
    assert float(row0["Confidence"]) == 1.0
    row1 = recs[recs["Client Row"] == 1].iloc[0]
    assert row1["Method"] in {"exact_normalized_text", "fuzzy_text_rank"}


def test_quality_dashboard_flags_blank_and_duplicates():
    from coverageprep.quality import analyze_data_quality
    df = pd.DataFrame({"Brand": ["A", "A"], "SKU": ["", ""], "2024-01": [10, 10]})
    issues = analyze_data_quality(df, assigned_roles=["Brand", "SKU"])
    assert (issues["Category"] == "Duplicates").any()
    assert ((issues["Category"] == "Completeness") & (issues["Field"] == "SKU")).any()
