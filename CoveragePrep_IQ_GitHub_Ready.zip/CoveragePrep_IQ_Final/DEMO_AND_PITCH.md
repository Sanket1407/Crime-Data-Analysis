# CoveragePrep IQ — 5-Minute Demo & Pitch Runbook

## Opening — 0:00–0:30

"Coverage Analysis can only start after Customer Support turns client shipment files into a clean, standardized and trusted structure. The difficult part is that every client can send a different workbook shape. CoveragePrep IQ makes that preparation repeatable without asking AI to rewrite client numbers."

Show one-line principle:

**Agent recommends. Rules transform. Validation proves.**

## 0:30–1:15 — Ingest and understand

Use **Bundled structural demo → `case2_long_period.xlsx`**.

Show:

- workbook profile;
- candidate layout;
- agent-flow expander;
- optional AI schema advisor (only if approved endpoint is available).

Narration:

"AI is an advisor, not the calculator. The deterministic profiler works even when AI is unavailable."

## 1:15–2:15 — Human mapping and deterministic transform

Choose:

- layout: **Long period + value**;
- period components: `Año`, `Periodo`;
- fact: `Sum of Total`;
- roles:
  - `Pais` → Country
  - `Channel` → Channel
  - `Categoria` → Category
  - `Marca` → Brand
  - keep Product Description, Pack Size and Unit as Extra
- date: `YYYY-MM`;
- negatives: keep;
- duplicates: keep;
- output mode: **Generic NIQ Standard**.

Execute.

Narration:

"The coverage expert decides semantics. Missing canonical fields are blank, never invented."

## 2:15–3:15 — Quality and standardization

Show Data Quality Dashboard.

Open Standardization Advisor and generate recommendations for:

- Brand;
- Product Description;
- Pack Size;
- Unit/UOM.

Approve a few synthetic examples such as:

- `6X330 ML` → `6 x 330 ML`;
- `units` → `UN`;
- spacing/case variants.

Apply.

Narration:

"The portal asks for standardization, while the deep-dive says do not assume or overwrite client data. We satisfy both: recommendations are deterministic and nothing changes until the coverage expert approves it."

## 3:15–3:45 — Optional Mapping Advisor

Open Mapping Advisor and choose **Bundled synthetic reference**.

Use Brand as the client key and show the historical/exact candidate result.

Narration:

"This is recommendation-only. In production the same adapter can use an approved NIQ reference. CoveragePrep IQ does not merge shipment data to NIQ retail data and does not calculate Coverage."

If the approved Luna endpoint is connected, optionally show candidate tie-breaker. Otherwise say:

"The integration hook is ready, but we will not call an unapproved external model for client data."

## 3:45–4:35 — Integrity Gate

Show:

- source total;
- expected total after user actions;
- output total;
- delta = 0;
- period reconciliation;
- numeric multiset preservation;
- **dimension-period-value association preservation**.

Key narration:

"A grand total is not enough. If 100 moves from Brand A to Brand B, the total can still match. Our association digest detects that and blocks export. The evidence suite includes a deliberate tamper test proving this."

## 4:35–5:00 — Evidence, scale, close

Show KPI summary and output workbook sheets.

Close:

"CoveragePrep IQ gives Customer Support one reusable preparation workflow across different shipment structures. It accelerates the manual work, keeps experts in control, and proves the result before it reaches Coverage Analysis."

## Backup demo

If time permits or judges ask about generalization, open `case4_matrix_multifact.xlsx` and show that KG/UN/LT matrix tabs are converted using the same framework.

## Q&A defenses

**Why not fully automate field mapping?**  Because the deep-dive explicitly says client column names may not reliably reveal Brand/Channel/Region meaning. Recommendations are fine; the expert remains the authority.

**Why is AI needed if rules work?**  Rules execute safely. AI adds value in ambiguous structural planning and candidate ranking. This is efficient agentic orchestration, not AI for its own sake.

**How do you handle 1.2 GB / larger files?**  The UI is the prototype. The same plan becomes a worker job using approved object storage and a lazy engine such as Polars/DuckDB. The project does not pretend Streamlit+pandas alone is the final multi-GB architecture.

**Does it perform Coverage Analysis?**  No. It prepares and validates shipment inputs for downstream Coverage Analysis.
