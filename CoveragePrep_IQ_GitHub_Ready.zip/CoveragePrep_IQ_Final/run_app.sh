#!/usr/bin/env bash
set -euo pipefail
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python benchmarks/generate_benchmarks.py
streamlit run app.py
