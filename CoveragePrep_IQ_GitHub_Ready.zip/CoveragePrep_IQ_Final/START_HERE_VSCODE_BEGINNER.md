# CoveragePrep IQ — Beginner Start Guide for VS Code + Python (Windows)

You do not need to know Streamlit, web development, or AI tooling to run this project. If you can use VS Code and basic Python, follow this guide in order.

## 1. What this project is

CoveragePrep IQ is a Python application with a Streamlit user interface. VS Code is where you edit/run the code; Streamlit opens the app in your normal web browser at a local address such as `http://localhost:8501`.

Main flow:

`Excel/CSV -> profile structure -> configure mapping -> transform -> data-quality checks -> validation -> export Excel/CSV`

The AI portion is optional. The deterministic Python engine works without any AI token.

## 2. What you need installed

- Windows 10/11
- VS Code
- Python 3.10 or newer (3.11 is a good choice)
- Microsoft Excel is useful for opening `.xlsx` outputs, but not required to run the app

Check Python in VS Code Terminal:

```bat
python --version
```

If that command is not recognized, try:

```bat
py --version
```

## 3. Open the project correctly

1. Extract `CoveragePrep_IQ_Hackfest2026_FINAL.zip`.
2. In VS Code choose **File > Open Folder**.
3. Select the folder named `CoveragePrep_IQ_Final` — not the ZIP itself.
4. In VS Code choose **Terminal > New Terminal**.
5. For the simplest Windows experience, choose **Command Prompt** as the VS Code terminal profile.

Your terminal should be inside the project folder. You can check with:

```bat
dir
```

You should see files such as `app.py`, `requirements.txt`, `README.md`, `demo_run.py`, and the `coverageprep` folder.

## 4. Create a virtual environment

Run once:

```bat
python -m venv .venv
```

Activate it in Command Prompt:

```bat
.venv\Scripts\activate
```

Your prompt should now show `(.venv)`.

If you use PowerShell instead, use:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks scripts, either switch the VS Code terminal to Command Prompt or temporarily allow scripts only for that terminal session:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 5. Install the Python packages

With `(.venv)` active:

```bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

This installs Streamlit, pandas, NumPy, openpyxl, XlsxWriter, python-dateutil and requests.

For tests, also install:

```bat
python -m pip install -r requirements-dev.txt
```

## 6. Generate the synthetic demo workbooks

Run:

```bat
python benchmarks\generate_benchmarks.py
```

This creates/refreshes the five safe synthetic example workbooks under:

`data\benchmark_cases\`

They are intended for learning and demonstration, so use them before trying any real challenge file.

## 7. Run the app

Run:

```bat
streamlit run app.py
```

A browser should open automatically. If not, copy the Local URL printed in the terminal (normally `http://localhost:8501`) into Edge or Chrome.

To stop the app, click the VS Code terminal and press:

`Ctrl + C`

### One-click alternative

You can also double-click `run_app_windows.bat`, or run this from the terminal:

```bat
run_app_windows.bat
```

That script creates the virtual environment, installs requirements, regenerates benchmark files and starts Streamlit. It is convenient for a first run, but slower because it checks/install packages each time.

## 8. First practice walkthrough in the app

Use **Bundled structural demo** first.

### Screen 1 — Secure ingest & structure profile

Choose a demo workbook. The app shows detected sheets, likely header row, likely layout, date-like fields, numeric fields and warnings.

Choose the sheets to prepare and the transformation layout. The four layouts are:

- `wide_periods`: periods such as Jan/Feb/Mar are already columns.
- `long_period_value`: period is stored in rows with a value column.
- `matrix`: values sit at row/column intersections.
- `sheet_per_period`: each Excel sheet represents a period.

Do not use the AI button yet. The app works without it.

### Screen 2 — Interpret, configure & approve

Choose an output mode:

- **Generic NIQ Standard**: prioritizes Country, Region, Channel, City, State, Category, Brand, SKU, Fact + periods.
- **Guide-Specific / Flexible**: keeps only the fields you select.

Choose the negative-value rule:

- Do nothing
- Transform to positive
- Transform to 0

Choose duplicate handling:

- Keep all rows (safest/default)
- Drop exact duplicates
- Aggregate selected duplicate keys by sum (use only when explicitly justified)

Map the source fields. The table lets you choose whether to keep a field, assign a role, set its output name and set its position.

Then click the large **Execute approved preparation plan** button.

### Screen 3 — Data quality & advisory standardization

Review issues rather than automatically changing data.

The Standardization Advisor can propose formatting fixes such as spacing, UOM display or surface variants. Generate recommendations, review them, approve only the ones you agree with, then apply approved standardizations.

The Mapping Advisor is optional. For learning, use the bundled synthetic reference. It only produces recommendations; it does not perform Coverage Analysis.

### Screen 4 — Integrity Gate

This is the most important evidence screen.

A healthy run should show:

- Integrity = PASS
- source total
- expected total after approved actions
- output total
- delta = 0 (or within tiny floating-point tolerance)
- period-level reconciliation PASS
- numeric multiset / association checks PASS

If Integrity = FAIL, the app intentionally blocks production export.

### Screen 5 — Output preview & audit

Review the standardized output and audit log. The audit tells you which transformations were approved and applied.

### Screen 6 — Export

If validation passed, click **Download validated output + evidence**.

Also download the **Transformation Plan** JSON. It stores the reusable configuration, not the client sales values.

## 9. Run a complete demo without the browser

Run:

```bat
python demo_run.py
```

Outputs are written to `demo_outputs\`, especially:

- `CoveragePrep_IQ_Demo_Output.xlsx`
- `CoveragePrep_IQ_Demo_Report.json`

Open the XLSX in Excel. Its tabs explain the full evidence package:

- `Prepared_Data`: final standardized data
- `Validation_Summary`: high-level PASS/FAIL and totals
- `Validation_Checks`: detailed checks
- `Exceptions`: rows/values that require review
- `Audit_Log`: what the system did
- `Data_Quality`: detected issues/recommendations
- `Standardization`: recommendations/approved decisions
- `Mapping_Advisor`: optional mapping candidates
- `KPI_Summary`: runtime and evidence metrics
- `Configuration`: transformation settings

## 10. Run automated tests

Install test dependencies first:

```bat
python -m pip install -r requirements-dev.txt
```

Then run:

```bat
python benchmark_runner.py
```

This regenerates the synthetic datasets and runs the pytest suite in `tests\`.

Then run the larger evidence suite:

```bat
python evidence_runner.py
```

Important outputs:

- `benchmark_results.json`
- `evidence\evidence_report.csv`
- `evidence\evidence_report.json`
- `evidence\final_pytest.txt`

These files are useful in the Hackfest presentation because they prove the solution was tested.

## 11. Use the command-line mode

The Streamlit app is best for the demo. `cli.py` is for repeatable execution after you already have a transformation plan.

Example:

```bat
python cli.py ^
  --input data\benchmark_cases\case2_long_period.xlsx ^
  --plan demo_outputs\Transformation_Plan_Demo.json ^
  --generic-standard ^
  --output demo_outputs\CLI_Validated_Output.xlsx
```

If the Integrity Gate passes, it writes the output. If validation fails, it refuses to write a production output.

## 12. Optional NIQ-approved AI

Do not configure this until you receive the approved NIQ/Hackfest endpoint, token and model name.

In Windows Command Prompt:

```bat
set NIQ_AI_ENDPOINT=YOUR_APPROVED_ENDPOINT
set NIQ_AI_TOKEN=YOUR_APPROVED_TOKEN
set NIQ_AI_MODEL=YOUR_APPROVED_MODEL
streamlit run app.py
```

Do not place the token directly inside `app.py` or another committed source file.

Without these variables, the app shows **Approved AI: Not configured** and continues working normally.

## 13. What each top-level file is for

| File/folder | What it is | When you use it |
|---|---|---|
| `app.py` | Streamlit web UI | Main Hackfest demo |
| `coverageprep\` | Core Python engine | Read/edit when changing logic |
| `requirements.txt` | Runtime Python packages | First setup |
| `requirements-dev.txt` | Runtime packages + pytest | When running tests |
| `run_app_windows.bat` | Windows quick-start script | Easy app launch |
| `run_tests_windows.bat` | Windows test script | Quick regression test |
| `demo_run.py` | Creates a complete demo output | Practice/evidence |
| `cli.py` | Executes a saved transformation recipe | Repeatable non-UI runs |
| `benchmark_runner.py` | Runs automated benchmark tests | Technical evidence |
| `evidence_runner.py` | Runs broader evidence scenarios | Hackfest evidence |
| `benchmarks\` | Code that generates synthetic workbooks | Recreate safe demos |
| `data\benchmark_cases\` | Five synthetic input workbooks | Learn/test each layout |
| `data\demo_reference\` | Synthetic mapping references | Mapping Advisor demo |
| `demo_outputs\` | Generated example outputs | Show expected result |
| `evidence\` | Test/evidence reports | Presentation proof |
| `tests\` | pytest test code | Developers/testing |
| `.streamlit\config.toml` | Streamlit display/server settings | Usually leave alone |
| `.gitignore` | Files Git should ignore | Leave alone |
| `MANIFEST_SHA256.txt` | Hash list for package integrity | Handoff/checking, not normal use |
| `README.md` | Short project overview | Read after this guide |
| `FINAL_IMPLEMENTATION_GUIDE.md` | Deep technical explanation | Learn how everything works |
| `ARCHITECTURE_AND_AGENT_FLOW.md` | Architecture/tool flow | Explain design to judges |
| `REQUIREMENT_TRACEABILITY.md` | Requirement-to-feature mapping | Prove challenge alignment |
| `SECURITY_RESPONSIBLE_AI.md` | Security/AI controls | Security discussion/judging |
| `EVALUATION_MAP.md` | Hackfest scoring alignment | Pitch preparation |
| `DEMO_AND_PITCH.md` | 5-minute demo script | Rehearsal/video |
| `SUBMISSION_CHECKLIST.md` | Final submission checklist | Before final upload |
| `FINAL_STATUS_AND_HANDOFF.md` | Current project status/limitations | Team handoff |
| `NIQ_CoveragePrep_IQ_Hackfest2026_Proposal.md` | Solution proposal | Business/pitch reference |
| `MIGRATION_FROM_OLD_MVP.md` | Why the original MVP was changed | Background only |

## 14. What is inside `coverageprep\`

You do not need to learn all modules on day one. Start with `app.py`, then read these only when needed.

| Module | Job |
|---|---|
| `security.py` | Checks uploaded files before processing |
| `profiler.py` | Reads sheets and detects structure |
| `models.py` | Data classes/configuration objects |
| `design.py` | Standard output-role helpers |
| `orchestrator.py` | Builds the agent/tool sequence |
| `ai_assist.py` | Optional approved-AI calls |
| `transform.py` | Core wide/long/matrix/multi-sheet transformations |
| `quality.py` | Data-quality checks |
| `standardize.py` | Human-approved text/UOM/pack recommendations |
| `mapping.py` | Optional mapping candidate recommendations |
| `validation.py` | Integrity Gate and reconciliation |
| `metrics.py` | KPI calculation |
| `exporter.py` | Writes Excel or CSV package |

Recommended learning order:

`app.py -> transform.py -> validation.py -> profiler.py -> quality.py -> standardize.py -> mapping.py -> exporter.py -> ai_assist.py`

## 15. How to read Markdown files in VS Code

Open any `.md` file and press:

`Ctrl + Shift + V`

VS Code will show a formatted Markdown preview.

## 16. What you should NOT change first

Until you are comfortable, leave these alone:

- `coverageprep\validation.py`
- `coverageprep\security.py`
- `.streamlit\config.toml`
- `MANIFEST_SHA256.txt`

The safest files for a beginner to edit are:

- documentation `.md` files
- `DEMO_AND_PITCH.md`
- presentation text
- synthetic benchmark/reference data only when you understand the expected format

## 17. Your recommended learning plan

Day 1: Run the app with synthetic demos and export one file.

Day 2: Run `demo_run.py`, tests and evidence suite; inspect output Excel tabs.

Day 3: Read `app.py`, `transform.py` and `validation.py` while comparing them with what you see in the UI.

Day 4: Try one approved challenge sample in the NIQ environment. Do not upload confidential files to external services.

Day 5: Rehearse `DEMO_AND_PITCH.md`, using the matrix/multi-tab case and the Integrity Gate as your main technical proof.

## 18. Common errors

### `python is not recognized`
Install Python and ensure **Add Python to PATH** is enabled, or try `py` instead of `python`.

### `streamlit is not recognized`
Activate `.venv`, then run:

```bat
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

### `ModuleNotFoundError`
You are usually either outside the virtual environment or packages were not installed. Activate `.venv` and reinstall requirements.

### Port 8501 is already in use
Run:

```bat
streamlit run app.py --server.port 8502
```

### PowerShell activation is blocked
Use Command Prompt inside VS Code, or use the process-only execution-policy command shown above.

### App says Approved AI is not configured
That is normal. The app does not require AI to run. Configure the NIQ-approved endpoint only when you receive it.

### Integrity Gate says FAIL
Do not bypass it. Review the selected layout, header row, value columns, period fields, field mapping, negative-value policy and duplicate policy. A FAIL is the system protecting the output from an incorrect transformation.

## 19. The three files you need first

If the whole project feels overwhelming, focus only on these:

1. `START_HERE_VSCODE_BEGINNER.md` — this guide.
2. `app.py` — the application you run.
3. `DEMO_AND_PITCH.md` — how to demonstrate it.

Everything else supports those three.
