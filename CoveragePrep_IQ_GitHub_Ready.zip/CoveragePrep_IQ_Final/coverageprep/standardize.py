from __future__ import annotations

import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


STANDARDIZATION_TYPES = [
    "None",
    "Text",
    "Brand",
    "Category",
    "Channel",
    "Market",
    "Product Description",
    "Pack Size",
    "Unit/UOM",
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _blank(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and np.isnan(v):
        return True
    return str(v).strip() == ""


def _collapse_spaces(v: Any) -> str:
    return re.sub(r"\s+", " ", str(v).strip())


def _norm_key(v: Any) -> str:
    s = _collapse_spaces(v).casefold()
    # Keep letters/numbers because we only use this for near-exact surface variants.
    return re.sub(r"[^\w]+", "", s, flags=re.UNICODE)


def suggest_standardization_type(column: str, role: Optional[str] = None) -> str:
    n = str(column).strip().lower()
    r = (role or "").strip().lower()
    if r == "brand" or "brand" in n or "marca" in n:
        return "Brand"
    if r == "category" or "category" in n or "categoria" in n or "segment" in n:
        return "Category"
    if r == "channel" or "channel" in n or "trade" in n or "retailer" in n:
        return "Channel"
    if r in {"country", "region", "city", "state"} or any(k in n for k in ["country", "region", "city", "state", "market", "pais", "país", "territory"]):
        return "Market"
    if any(k in n for k in ["uom", "unit", "measure"]):
        return "Unit/UOM"
    if any(k in n for k in ["pack", "size", "volume", "volum"]):
        return "Pack Size"
    if any(k in n for k in ["description", "desc", "product", "item"]):
        return "Product Description"
    return "Text"


_UOM_MAP = {
    "kg": "KG", "kgs": "KG", "kilogram": "KG", "kilograms": "KG", "kilo": "KG", "kilos": "KG",
    "g": "G", "gm": "G", "gms": "G", "gram": "G", "grams": "G",
    "mg": "MG", "milligram": "MG", "milligrams": "MG",
    "l": "L", "lt": "L", "ltr": "L", "ltrs": "L", "liter": "L", "liters": "L", "litre": "L", "litres": "L",
    "ml": "ML", "milliliter": "ML", "milliliters": "ML", "millilitre": "ML", "millilitres": "ML",
    "cl": "CL", "centiliter": "CL", "centiliters": "CL", "centilitre": "CL", "centilitres": "CL",
    "unit": "UN", "units": "UN", "un": "UN", "pc": "UN", "pcs": "UN", "piece": "UN", "pieces": "UN", "ea": "UN", "each": "UN",
}


def normalize_uom(value: Any) -> Optional[str]:
    if _blank(value):
        return None
    key = re.sub(r"[^a-z]", "", _collapse_spaces(value).lower())
    return _UOM_MAP.get(key)


def normalize_pack_size(value: Any) -> Optional[str]:
    """Conservative formatter only; it does not convert units or quantities."""
    if _blank(value):
        return None
    s = _collapse_spaces(value)
    # 6X330 ML / 6 x 330ml / 6*330 ml => 6 x 330 ML
    m = re.fullmatch(
        r"(?i)\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*(kg|kgs?|g|gms?|mg|l|lt|ltr|ltrs|ml|cl|units?|un|pcs?|pieces?|ea)\s*",
        s,
    )
    if m:
        count, qty, u = m.groups()
        u2 = normalize_uom(u) or u.upper()
        return f"{count} x {qty} {u2}"
    # 330ML -> 330 ML. No conversion.
    m = re.fullmatch(
        r"(?i)\s*(\d+(?:\.\d+)?)\s*(kg|kgs?|g|gms?|mg|l|lt|ltr|ltrs|ml|cl|units?|un|pcs?|pieces?|ea)\s*",
        s,
    )
    if m:
        qty, u = m.groups()
        u2 = normalize_uom(u) or u.upper()
        return f"{qty} {u2}"
    return None


def _surface_variant_suggestions(series: pd.Series, column: str, profile: str) -> List[Dict[str, Any]]:
    vals = [v for v in series.tolist() if not _blank(v)]
    if not vals:
        return []
    by_key: Dict[str, List[str]] = defaultdict(list)
    counts = Counter(str(v) for v in vals)
    for v in vals:
        s = str(v)
        key = _norm_key(s)
        if key:
            by_key[key].append(s)
    out: List[Dict[str, Any]] = []
    seen_pairs = set()
    for _, members in by_key.items():
        unique = list(dict.fromkeys(members))
        if len(unique) <= 1:
            continue
        # Choose the most frequent surface form; ties prefer fewer surrounding/duplicate spaces.
        target = sorted(unique, key=lambda x: (-counts[x], len(x), x.casefold()))[0]
        target = _collapse_spaces(target)
        for original in unique:
            suggestion = target
            if _collapse_spaces(original) == target and original == target:
                continue
            pair = (original, suggestion)
            if pair in seen_pairs or original == suggestion:
                continue
            seen_pairs.add(pair)
            out.append({
                "Apply": False,
                "Column": column,
                "Profile": profile,
                "Original": original,
                "Suggested": suggestion,
                "Method": "case_space_variant_cluster",
                "Confidence": 0.99,
                "Affected Rows": int((series.astype(str) == original).sum()),
                "Reason": "Values differ only by capitalization, spacing or punctuation-equivalent surface form.",
            })
    return out


def generate_standardization_suggestions(
    df: pd.DataFrame,
    column_profiles: Mapping[str, str],
    max_unique_scan: int = 5000,
) -> pd.DataFrame:
    """
    Generate recommendation-only text standardization candidates.

    Guardrail: the function never mutates the dataframe, never expands brand names,
    never performs semantic taxonomy mapping, and never converts numeric quantities.
    """
    rows: List[Dict[str, Any]] = []
    for column, profile in column_profiles.items():
        if column not in df.columns or profile in {None, "None"}:
            continue
        s = df[column]
        # Surface-form clustering is safe for all textual profiles.
        rows.extend(_surface_variant_suggestions(s.head(max_unique_scan), column, profile))

        unique_values = list(dict.fromkeys(str(v) for v in s.tolist() if not _blank(v)))[:max_unique_scan]
        for original in unique_values:
            suggestion: Optional[str] = None
            method = ""
            reason = ""
            confidence = 0.0

            collapsed = _collapse_spaces(original)
            if collapsed != original:
                suggestion = collapsed
                method = "whitespace_normalization"
                reason = "Trim leading/trailing whitespace and collapse repeated spaces."
                confidence = 1.0

            if profile == "Unit/UOM":
                u = normalize_uom(original)
                if u and u != original:
                    suggestion = u
                    method = "uom_dictionary"
                    reason = "Deterministic synonym dictionary; no quantity conversion is performed."
                    confidence = 1.0
            elif profile == "Pack Size":
                p = normalize_pack_size(original)
                if p and p != original:
                    suggestion = p
                    method = "pack_format_parser"
                    reason = "Format-only pack parser; quantity and unit meaning are preserved."
                    confidence = 0.99
            elif profile == "Product Description":
                # Safe punctuation/spacing normalization only; never rewrite the product name.
                p = re.sub(r"\s*([/|,;])\s*", r" \1 ", collapsed)
                p = re.sub(r"\s+", " ", p).strip()
                if p != original:
                    suggestion = p
                    method = "description_spacing"
                    reason = "Spacing/punctuation normalization only; words are not added, removed or translated."
                    confidence = 1.0

            if suggestion is not None and suggestion != original:
                rows.append({
                    "Apply": False,
                    "Column": column,
                    "Profile": profile,
                    "Original": original,
                    "Suggested": suggestion,
                    "Method": method,
                    "Confidence": confidence,
                    "Affected Rows": int((s.astype(str) == original).sum()),
                    "Reason": reason,
                })

    if not rows:
        return pd.DataFrame(columns=["Apply", "Column", "Profile", "Original", "Suggested", "Method", "Confidence", "Affected Rows", "Reason"])
    out = pd.DataFrame(rows).drop_duplicates(subset=["Column", "Original", "Suggested", "Method"])
    # Avoid conflicting recommendations for the same exact source value.
    # Semantic-preserving parsers outrank surface clustering, which outranks simple whitespace cleanup.
    priority = {
        "uom_dictionary": 0,
        "pack_format_parser": 0,
        "description_spacing": 1,
        "case_space_variant_cluster": 1,
        "whitespace_normalization": 2,
    }
    out["_priority"] = out["Method"].map(priority).fillna(9)
    out = out.sort_values(["Column", "Original", "_priority", "Confidence", "Affected Rows"], ascending=[True, True, True, False, False])
    out = out.drop_duplicates(subset=["Column", "Original"], keep="first")
    out = out.sort_values(["Confidence", "Affected Rows"], ascending=[False, False]).drop(columns=["_priority"]).reset_index(drop=True)
    return out


def apply_standardization_decisions(
    df: pd.DataFrame,
    decisions: pd.DataFrame,
) -> Tuple[pd.DataFrame, List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Apply only rows explicitly marked Apply=True. Returns modified df, audit entries, decision records."""
    out = df.copy()
    audit: List[Dict[str, Any]] = []
    applied: List[Dict[str, Any]] = []
    if decisions is None or decisions.empty or "Apply" not in decisions.columns:
        return out, audit, applied

    for _, r in decisions.iterrows():
        if not bool(r.get("Apply", False)):
            continue
        col = str(r.get("Column", ""))
        if col not in out.columns:
            continue
        original = str(r.get("Original", ""))
        suggested = str(r.get("Suggested", ""))
        mask = out[col].astype(str) == original
        affected = int(mask.sum())
        if affected == 0 or original == suggested:
            continue
        out.loc[mask, col] = suggested
        rec = {
            "timestamp_utc": _now(),
            "action": "approved_text_standardization",
            "column": col,
            "method": str(r.get("Method", "")),
            "confidence": float(r.get("Confidence", 0.0)),
            "affected_rows": affected,
            "original": original,
            "suggested": suggested,
            "profile": str(r.get("Profile", "")),
        }
        audit.append({k: v for k, v in rec.items() if k not in {"original", "suggested"}})
        applied.append(rec)
    return out, audit, applied


def apply_text_decisions_to_long_df(long_df: pd.DataFrame, applied_decisions: Sequence[Mapping[str, Any]]) -> pd.DataFrame:
    """Apply the same approved dimension-label decisions to the internal long lineage before re-validation."""
    out = long_df.copy()
    for d in applied_decisions:
        col = str(d.get("column", ""))
        if col not in out.columns:
            continue
        original = str(d.get("original", ""))
        suggested = str(d.get("suggested", ""))
        mask = out[col].astype(str) == original
        out.loc[mask, col] = suggested
    return out
