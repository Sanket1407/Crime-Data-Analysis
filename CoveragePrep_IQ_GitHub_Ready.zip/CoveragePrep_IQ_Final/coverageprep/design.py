from __future__ import annotations

from datetime import datetime, timezone
from typing import Dict, Iterable, List, Sequence, Tuple

import pandas as pd

STANDARD_ROLES = ["Country", "Region", "Channel", "City", "State", "Category", "Brand", "SKU", "Fact"]


def apply_standard_placeholders(
    df: pd.DataFrame,
    assigned_roles: Sequence[str],
    add_missing_blank: bool = True,
) -> Tuple[pd.DataFrame, List[Dict]]:
    """Add blank canonical columns only when explicitly requested. No values are inferred."""
    out = df.copy()
    audit = []
    if add_missing_blank:
        assigned = {r for r in assigned_roles if r and r != "Extra"}
        added = []
        for role in STANDARD_ROLES:
            if role not in assigned and role not in out.columns:
                out[role] = ""
                added.append(role)
        if added:
            audit.append({
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "action": "add_blank_standard_placeholders",
                "columns": added,
                "note": "Blank placeholders only; no source values were inferred.",
            })

    # Standard roles first when present, extras next, period columns last.
    standard = [c for c in STANDARD_ROLES if c in out.columns]
    period_cols = []
    extras = []
    for c in out.columns:
        if c in standard:
            continue
        # Period columns are typically parseable labels; leave detection to a lightweight heuristic.
        from .profiler import parse_period
        if parse_period(c) is not None:
            period_cols.append(c)
        else:
            extras.append(c)
    return out[standard + extras + period_cols], audit
