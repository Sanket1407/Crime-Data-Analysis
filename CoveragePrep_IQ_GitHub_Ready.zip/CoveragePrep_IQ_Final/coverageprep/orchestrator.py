from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ToolStep:
    step: int
    tool: str
    objective: str
    autonomy: str
    approval_required: bool
    failure_policy: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class PreparationOrchestrator:
    """
    Policy-constrained agent flow.

    The orchestrator decomposes the preparation goal, selects deterministic tools,
    and inserts human approval gates wherever a decision can remove, relabel, or
    otherwise change client-supplied information. The AI layer is advisory; it is
    never allowed to publish numbers or silently rewrite source values.
    """

    def build_plan(
        self,
        layout: str,
        use_ai_suggestion: bool = False,
        use_mapping_advisor: bool = True,
    ) -> List[ToolStep]:
        steps: List[ToolStep] = [
            ToolStep(1, "SecureIngest", "Validate type/signature and profile workbook structure", "automatic", False, "reject unsupported/suspicious input"),
            ToolStep(2, "StructureProfiler", "Detect candidate header row, period fields, numeric fields and layout", "automatic", False, "surface uncertainty; never auto-delete"),
        ]
        n = 3
        if use_ai_suggestion:
            steps.append(ToolStep(n, "ApprovedAISchemaAdvisor", "Recommend a safe transformation recipe from structural metadata", "recommendation-only", True, "ignore invalid/low-confidence suggestion"))
            n += 1
        steps.extend([
            ToolStep(n, "HumanMappingGate", "Confirm retained fields, roles, order, fact semantics, period semantics and consequential actions", "human-in-the-loop", True, "do not transform until approved"),
            ToolStep(n + 1, f"{layout}Transformer", "Execute the approved deterministic transformation with lineage", "automatic after approval", False, "stop and flag unparseable values"),
            ToolStep(n + 2, "DataQualityAgent", "Detect missing, inconsistent, duplicate, negative, mixed-type and standardization issues", "automatic recommendation", False, "flag issues; never repair silently"),
            ToolStep(n + 3, "StandardizationAdvisor", "Recommend safe text/UOM/pack formatting changes", "recommendation-only", True, "apply only explicitly approved suggestions"),
        ])
        n += 4
        if use_mapping_advisor:
            steps.append(ToolStep(n, "MappingAdvisor", "Recommend client-to-reference candidates using approved history, identifiers and deterministic similarity", "recommendation-only", True, "never write mapping into shipment automatically"))
            n += 1
        steps.extend([
            ToolStep(n, "IntegrityValidator", "Reconcile totals, periods, value multiset and dimension-period-value associations", "automatic", False, "block export on failure"),
            ToolStep(n + 1, "ExportRouter", "Choose XLSX or CSV evidence package based on Excel limits", "automatic", False, "fallback to CSV package if Excel limits exceeded"),
        ])
        return steps
