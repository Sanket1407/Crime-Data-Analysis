from __future__ import annotations

import math
import re
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _blank(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and np.isnan(v):
        return True
    return str(v).strip() == ""


def _norm(v: Any) -> str:
    if _blank(v):
        return ""
    s = str(v).casefold().strip()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w]+", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()


def _composite(row: pd.Series, cols: Sequence[str]) -> str:
    return " | ".join(_norm(row.get(c, "")) for c in cols if c in row.index and _norm(row.get(c, "")))


def _similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    ratio = SequenceMatcher(None, a, b).ratio()
    ta, tb = set(a.split()), set(b.split())
    jaccard = len(ta & tb) / max(1, len(ta | tb))
    return 0.65 * ratio + 0.35 * jaccard


def recommend_mappings(
    client_df: pd.DataFrame,
    reference_df: pd.DataFrame,
    *,
    client_identifier_col: Optional[str] = None,
    reference_identifier_col: Optional[str] = None,
    client_text_cols: Sequence[str] = (),
    reference_text_cols: Sequence[str] = (),
    reference_output_cols: Sequence[str] = (),
    historical_df: Optional[pd.DataFrame] = None,
    historical_client_identifier_col: Optional[str] = None,
    historical_reference_identifier_col: Optional[str] = None,
    top_n: int = 1,
    review_threshold: float = 0.90,
    max_client_rows: int = 2000,
    max_reference_rows: int = 10000,
) -> pd.DataFrame:
    """
    Recommendation-only mapping cascade:
      1) previously approved historical identifier mapping (if supplied),
      2) exact identifier lookup,
      3) exact normalized text composite,
      4) fuzzy text ranking.

    The function does not alter the prepared shipment data.
    """
    cdf = client_df.head(max_client_rows).reset_index(drop=False).rename(columns={"index": "__client_row"})
    rdf = reference_df.head(max_reference_rows).reset_index(drop=False).rename(columns={"index": "__ref_row"})
    output_cols = [c for c in reference_output_cols if c in rdf.columns]

    hist_map: Dict[str, str] = {}
    if historical_df is not None and historical_client_identifier_col and historical_reference_identifier_col:
        if historical_client_identifier_col in historical_df.columns and historical_reference_identifier_col in historical_df.columns:
            for _, r in historical_df.iterrows():
                k = _norm(r[historical_client_identifier_col])
                v = str(r[historical_reference_identifier_col]).strip()
                if k and v:
                    hist_map[k] = v

    ref_by_id: Dict[str, List[int]] = {}
    if reference_identifier_col and reference_identifier_col in rdf.columns:
        for i, v in rdf[reference_identifier_col].items():
            k = _norm(v)
            if k:
                ref_by_id.setdefault(k, []).append(i)

    ref_texts = [_composite(rdf.loc[i], reference_text_cols) for i in rdf.index]
    ref_text_exact: Dict[str, List[int]] = {}
    for i, txt in enumerate(ref_texts):
        if txt:
            ref_text_exact.setdefault(txt, []).append(i)

    rows: List[Dict[str, Any]] = []
    for _, crow in cdf.iterrows():
        client_row = int(crow["__client_row"])
        cid = _norm(crow.get(client_identifier_col, "")) if client_identifier_col and client_identifier_col in cdf.columns else ""
        ctxt = _composite(crow, client_text_cols)
        candidates: List[Tuple[int, str, float, str]] = []

        # Tier 1A: historical mapping to reference identifier.
        if cid and cid in hist_map and reference_identifier_col:
            target = _norm(hist_map[cid])
            for ridx in ref_by_id.get(target, []):
                candidates.append((ridx, "historical_approved_identifier", 1.0, "Previously approved mapping matched the client identifier."))

        # Tier 1B: direct identifier.
        if not candidates and cid:
            for ridx in ref_by_id.get(cid, []):
                candidates.append((ridx, "exact_identifier", 1.0, "Exact identifier match."))

        # Tier 2A: exact normalized descriptive composite.
        if not candidates and ctxt and ctxt in ref_text_exact:
            for ridx in ref_text_exact[ctxt]:
                candidates.append((ridx, "exact_normalized_text", 0.98, "Exact match after case/spacing/punctuation normalization."))

        # Tier 2B: fuzzy deterministic ranking.
        if not candidates and ctxt and ref_texts:
            scored = [(i, _similarity(ctxt, txt)) for i, txt in enumerate(ref_texts) if txt]
            scored.sort(key=lambda x: x[1], reverse=True)
            for ridx, score in scored[: max(1, top_n)]:
                candidates.append((ridx, "fuzzy_text_rank", float(score), "Deterministic text similarity; recommendation only."))

        if not candidates:
            rows.append({
                "Client Row": client_row,
                "Method": "unresolved",
                "Confidence": 0.0,
                "Review Required": True,
                "Reason": "No identifier or text candidate could be generated.",
            })
            continue

        for rank, (ridx, method, conf, reason) in enumerate(candidates[: max(1, top_n)], start=1):
            rec: Dict[str, Any] = {
                "Client Row": client_row,
                "Rank": rank,
                "Method": method,
                "Confidence": round(float(conf), 4),
                "Review Required": bool(conf < review_threshold or method == "fuzzy_text_rank"),
                "Reason": reason,
            }
            if client_identifier_col and client_identifier_col in cdf.columns:
                rec[f"Client::{client_identifier_col}"] = crow.get(client_identifier_col)
            for c in client_text_cols:
                if c in cdf.columns:
                    rec[f"Client::{c}"] = crow.get(c)
            if reference_identifier_col and reference_identifier_col in rdf.columns:
                rec[f"Candidate::{reference_identifier_col}"] = rdf.loc[ridx, reference_identifier_col]
            for c in output_cols:
                rec[f"Candidate::{c}"] = rdf.loc[ridx, c]
            rows.append(rec)

    return pd.DataFrame(rows)


def mapping_summary(recommendations: pd.DataFrame) -> Dict[str, Any]:
    if recommendations is None or recommendations.empty:
        return {"rows": 0, "auto_exact": 0, "review_required": 0, "unresolved": 0}
    return {
        "rows": int(recommendations["Client Row"].nunique()) if "Client Row" in recommendations else int(len(recommendations)),
        "auto_exact": int(recommendations.get("Method", pd.Series(dtype=str)).isin(["historical_approved_identifier", "exact_identifier", "exact_normalized_text"]).sum()),
        "review_required": int(recommendations.get("Review Required", pd.Series(dtype=bool)).fillna(True).sum()),
        "unresolved": int((recommendations.get("Method", pd.Series(dtype=str)) == "unresolved").sum()),
    }
