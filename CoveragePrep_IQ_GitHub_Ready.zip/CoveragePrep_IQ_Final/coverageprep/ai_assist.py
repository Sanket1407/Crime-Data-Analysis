from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import requests


SYSTEM_PROMPT = """You are a data-preparation planning assistant for NIQ Coverage shipment files.
Your job is ONLY to recommend a transformation configuration; never invent, replace, aggregate, or alter client values.
Coverage analysis itself is out of scope. Missing or ambiguous fields must be flagged for a human decision.
Return JSON only. Recommend one of: wide_periods, long_period_value, matrix, sheet_per_period.
Base recommendations only on the structural metadata supplied. Never infer client identity or expand abbreviations.
"""


@dataclass
class AIRecommendation:
    available: bool
    recommendation: Dict[str, Any]
    raw_text: str = ""
    provider_note: str = ""


class ApprovedAIClient:
    """
    Optional adapter for an NIQ-approved enterprise model gateway.

    Configure only with credentials/endpoints provided by the Hackfest team:
      NIQ_AI_ENDPOINT
      NIQ_AI_TOKEN
      NIQ_AI_MODEL

    The adapter expects an OpenAI-compatible chat-completions request/response shape.
    If NIQ's Luna gateway uses a different shape, edit ONLY `_call()`; the rest of the app stays unchanged.
    Core transformation and validation do not depend on AI.
    """

    def __init__(self, endpoint: Optional[str] = None, token: Optional[str] = None, model: Optional[str] = None):
        self.endpoint = endpoint or os.getenv("NIQ_AI_ENDPOINT")
        self.token = token or os.getenv("NIQ_AI_TOKEN")
        self.model = model or os.getenv("NIQ_AI_MODEL")

    @property
    def configured(self) -> bool:
        return bool(self.endpoint and self.token and self.model)

    def _call(self, messages: List[Dict[str, str]], timeout: int = 45) -> str:
        if not self.configured:
            raise RuntimeError("Approved AI gateway is not configured.")
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0,
            "response_format": {"type": "json_object"},
        }
        response = requests.post(self.endpoint, headers=headers, json=payload, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]

    def recommend_plan(self, structural_metadata: Dict[str, Any]) -> AIRecommendation:
        if not self.configured:
            return AIRecommendation(False, {}, provider_note="No approved AI endpoint configured; deterministic profiler remains available.")
        # Deliberately send structural metadata only by default: headers, dtypes, shapes, parseability rates.
        user_prompt = {
            "task": "Recommend a safe transformation plan and list ambiguities that require human approval.",
            "metadata": structural_metadata,
            "required_json_keys": [
                "layout", "confidence", "reason", "period_candidates", "value_candidates",
                "dimension_candidates", "ambiguities", "human_approvals_required"
            ],
        }
        raw = self._call([
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(user_prompt, ensure_ascii=False)},
        ])
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            parsed = {"error": "Model did not return valid JSON", "raw": raw[:1000]}
        return AIRecommendation(True, parsed, raw_text=raw, provider_note="NIQ-approved gateway; structural metadata only by default.")

    def rank_mapping_candidates(
        self,
        client_text: Dict[str, Any],
        candidates: List[Dict[str, Any]],
    ) -> AIRecommendation:
        """
        Optional NIQ-approved AI tie-breaker for already-generated mapping candidates.

        This method should be invoked only after the user explicitly approves sending
        the selected client text to an NIQ-approved endpoint. It never receives sales
        values and cannot create a candidate that was not supplied by deterministic tools.
        """
        if not self.configured:
            return AIRecommendation(False, {}, provider_note="No approved AI endpoint configured.")
        prompt = {
            "task": "Rank the supplied mapping candidates. Do not invent new values or candidates.",
            "client_text": client_text,
            "candidates": candidates,
            "required_json_keys": ["recommended_rank", "confidence", "reason", "uncertainty"],
        }
        raw = self._call([
            {"role": "system", "content": SYSTEM_PROMPT + " You may rank only candidates explicitly provided by the user/tool. Never create a new product or mapping."},
            {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)},
        ])
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            parsed = {"error": "Model did not return valid JSON", "raw": raw[:1000]}
        return AIRecommendation(True, parsed, raw_text=raw, provider_note="NIQ-approved endpoint; candidate ranking only.")
