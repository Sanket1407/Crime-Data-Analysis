from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .models import DimensionSpec, MatrixHeaderSpec, SheetPlan, TransformationResult
from .profiler import build_dataframe, combine_period_components, normalize_period_label, parse_period
from .validation import validate_transformation


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _audit(action: str, **kwargs: Any) -> Dict[str, Any]:
    return {"timestamp_utc": _now(), "action": action, **kwargs}


def _is_blank(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and np.isnan(v):
        return True
    return str(v).strip() == ""


def _parse_numeric_series(s: pd.Series) -> Tuple[pd.Series, List[int]]:
    """Parse a user-selected fact field. Unparseable nonblank rows are returned as exceptions."""
    def clean(v: Any) -> Any:
        if _is_blank(v):
            return np.nan
        if isinstance(v, (int, float, np.number)) and not isinstance(v, bool):
            return v
        text = str(v).strip().replace(",", "")
        # Accounting negative: (123.4)
        if text.startswith("(") and text.endswith(")"):
            text = "-" + text[1:-1]
        return text

    cleaned = s.map(clean)
    numeric = pd.to_numeric(cleaned, errors="coerce")
    bad_mask = numeric.isna() & ~s.map(_is_blank)
    return numeric, list(s.index[bad_mask])


def _apply_negative_policy(values: pd.Series, policy: str) -> Tuple[pd.Series, float, int]:
    values = values.copy()
    negative_mask = values < 0
    count = int(negative_mask.sum())
    before = float(values.fillna(0).sum())
    if policy == "absolute":
        values.loc[negative_mask] = values.loc[negative_mask].abs()
    elif policy == "zero":
        values.loc[negative_mask] = 0
    elif policy != "keep":
        raise ValueError(f"Unknown negative policy: {policy}")
    after = float(values.fillna(0).sum())
    return values, after - before, count


def _dimension_frame(df: pd.DataFrame, dimensions: Sequence[DimensionSpec]) -> Tuple[pd.DataFrame, List[str]]:
    kept = [d for d in dimensions if d.keep]
    kept.sort(key=lambda d: (d.position, d.source))
    out = pd.DataFrame(index=df.index)
    names: List[str] = []
    seen: Dict[str, int] = {}
    for d in kept:
        if d.source not in df.columns:
            raise ValueError(f"Selected dimension column {d.source!r} is not present in the source table.")
        name = d.final_name()
        n = seen.get(name, 0)
        seen[name] = n + 1
        if n:
            # Never merge two source columns silently.
            name = f"{name}__{n+1}"
        out[name] = df[d.source]
        names.append(name)
    return out, names


def _apply_duplicate_policy_long(
    long_df: pd.DataFrame,
    key_cols: Sequence[str],
    policy: str,
    audit: List[Dict[str, Any]],
) -> pd.DataFrame:
    if policy == "keep":
        return long_df
    if policy == "drop_exact":
        before = len(long_df)
        subset = [c for c in long_df.columns if not c.startswith("__source_")]
        out = long_df.drop_duplicates(subset=subset, keep="first")
        audit.append(_audit("drop_exact_duplicates", removed_rows=before - len(out), compared_columns=subset))
        return out
    if policy == "aggregate_sum":
        if not key_cols:
            raise ValueError("Aggregation requires explicit duplicate key columns.")
        before = len(long_df)
        out = (
            long_df.groupby(list(key_cols), dropna=False, sort=False, as_index=False)["__value"]
            .sum(min_count=1)
        )
        audit.append(_audit("aggregate_duplicates_sum", source_rows=before, output_rows=len(out), keys=list(key_cols)))
        return out
    raise ValueError(f"Unknown duplicate action: {policy}")


def _pivot_without_implicit_aggregation(
    long_df: pd.DataFrame,
    dimension_cols: Sequence[str],
    period_col: str = "__period",
    value_col: str = "__value",
    fact_col: Optional[str] = "Fact",
) -> pd.DataFrame:
    """
    Pivot periods to columns while preserving repeated source records.
    The occurrence index prevents pandas from summing duplicate keys.
    """
    index_cols = list(dimension_cols)
    if fact_col and fact_col in long_df.columns and fact_col not in index_cols:
        index_cols.append(fact_col)

    group_key = index_cols + [period_col]
    work = long_df.copy()
    work["__occurrence"] = work.groupby(group_key, dropna=False, sort=False).cumcount()
    pivot_index = index_cols + ["__occurrence"]

    wide = work.pivot(index=pivot_index, columns=period_col, values=value_col).reset_index()
    wide.columns.name = None
    wide = wide.drop(columns=["__occurrence"])

    # Keep dimensions first, periods sorted chronologically where possible.
    period_columns = [c for c in wide.columns if c not in index_cols]
    def period_sort_key(v: Any):
        ts = parse_period(v)
        return (0, ts) if ts is not None else (1, str(v))
    period_columns = sorted(period_columns, key=period_sort_key)
    return wide[index_cols + period_columns]


def transform_wide(df: pd.DataFrame, plan: SheetPlan) -> Tuple[pd.DataFrame, pd.DataFrame, List[Dict], List[Dict], Dict]:
    audit: List[Dict] = []
    exceptions: List[Dict] = []
    dims, dim_names = _dimension_frame(df, plan.dimensions)

    if not plan.period_columns:
        raise ValueError("Wide-period layout requires at least one period column.")

    missing = [c for c in plan.period_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Selected period columns not found: {missing}")

    long_parts = []
    source_total = 0.0
    user_delta = 0.0
    fact_cells_before = 0
    for raw_period in plan.period_columns:
        numeric, bad_idxs = _parse_numeric_series(df[raw_period])
        for idx in bad_idxs[:1000]:
            exceptions.append({
                "type": "non_numeric_fact",
                "sheet": plan.sheet_name,
                "source_row": int(idx),
                "source_column": raw_period,
                "value": str(df.loc[idx, raw_period]),
            })
        fact_cells_before += int(numeric.notna().sum())
        source_total += float(numeric.fillna(0).sum())
        numeric2, delta, negative_count = _apply_negative_policy(numeric, plan.negative_policy)
        user_delta += delta
        if negative_count:
            audit.append(_audit(
                "negative_policy",
                column=raw_period,
                policy=plan.negative_policy,
                affected_cells=negative_count,
                numeric_delta=delta,
            ))
        period_label = normalize_period_label(raw_period, plan.date_format)
        p = dims.copy()
        p["Fact"] = "Value"
        p["__period"] = period_label
        p["__value"] = numeric2
        p["__source_row"] = df.index.astype(int)
        long_parts.append(p)

    long_df = pd.concat(long_parts, ignore_index=True)
    duplicate_keys = [c for c in plan.duplicate_keys if c in long_df.columns]
    if plan.duplicate_action == "aggregate_sum":
        duplicate_keys = duplicate_keys or (dim_names + ["Fact", "__period"])
    long_df = _apply_duplicate_policy_long(long_df, duplicate_keys, plan.duplicate_action, audit)

    wide = _pivot_without_implicit_aggregation(long_df, dim_names, fact_col="Fact")
    audit.append(_audit(
        "transform_wide_periods",
        periods=len(plan.period_columns),
        output_rows=len(wide),
        output_columns=len(wide.columns),
        date_format=plan.date_format,
    ))
    meta = {
        "source_numeric_total": source_total,
        "expected_numeric_total": source_total + user_delta,
        "fact_cells_before": fact_cells_before,
        "dimension_columns": dim_names,
        "period_columns": [c for c in wide.columns if c not in dim_names + ["Fact"]],
        "_long_df": long_df,
    }
    return wide, long_df, audit, exceptions, meta


def transform_long(df: pd.DataFrame, plan: SheetPlan) -> Tuple[pd.DataFrame, pd.DataFrame, List[Dict], List[Dict], Dict]:
    audit: List[Dict] = []
    exceptions: List[Dict] = []
    dims, dim_names = _dimension_frame(df, plan.dimensions)
    if not plan.period_components:
        raise ValueError("Long layout requires one or more user-selected period components.")
    if not plan.value_columns:
        raise ValueError("Long layout requires at least one user-selected fact/value column.")
    period = combine_period_components(df, plan.period_components, plan.date_format)

    long_parts = []
    source_total = 0.0
    user_delta = 0.0
    fact_cells_before = 0
    for fact_col in plan.value_columns:
        if fact_col not in df.columns:
            raise ValueError(f"Fact/value column {fact_col!r} is not present.")
        numeric, bad_idxs = _parse_numeric_series(df[fact_col])
        for idx in bad_idxs[:1000]:
            exceptions.append({
                "type": "non_numeric_fact",
                "sheet": plan.sheet_name,
                "source_row": int(idx),
                "source_column": fact_col,
                "value": str(df.loc[idx, fact_col]),
            })
        fact_cells_before += int(numeric.notna().sum())
        source_total += float(numeric.fillna(0).sum())
        numeric2, delta, negative_count = _apply_negative_policy(numeric, plan.negative_policy)
        user_delta += delta
        if negative_count:
            audit.append(_audit(
                "negative_policy", column=fact_col, policy=plan.negative_policy,
                affected_cells=negative_count, numeric_delta=delta,
            ))
        part = dims.copy()
        part["Fact"] = fact_col
        part["__period"] = period
        part["__value"] = numeric2
        part["__source_row"] = df.index.astype(int)
        long_parts.append(part)

    long_df = pd.concat(long_parts, ignore_index=True)
    duplicate_keys = [c for c in plan.duplicate_keys if c in long_df.columns]
    if plan.duplicate_action == "aggregate_sum":
        duplicate_keys = duplicate_keys or (dim_names + ["Fact", "__period"])
    long_df = _apply_duplicate_policy_long(long_df, duplicate_keys, plan.duplicate_action, audit)

    wide = _pivot_without_implicit_aggregation(long_df, dim_names, fact_col="Fact")
    audit.append(_audit(
        "transform_long_period_value",
        period_components=list(plan.period_components),
        value_columns=list(plan.value_columns),
        output_rows=len(wide),
        output_columns=len(wide.columns),
        date_format=plan.date_format,
    ))
    meta = {
        "source_numeric_total": source_total,
        "expected_numeric_total": source_total + user_delta,
        "fact_cells_before": fact_cells_before,
        "dimension_columns": dim_names,
        "period_columns": [c for c in wide.columns if c not in dim_names + ["Fact"]],
        "_long_df": long_df,
    }
    return wide, long_df, audit, exceptions, meta


def transform_sheet_per_period(df: pd.DataFrame, plan: SheetPlan) -> Tuple[pd.DataFrame, pd.DataFrame, List[Dict], List[Dict], Dict]:
    if plan.sheet_period_value is None:
        raise ValueError("Sheet-per-period layout requires a period value for the sheet.")
    if not plan.value_columns:
        raise ValueError("Sheet-per-period layout requires at least one value column.")
    audit: List[Dict] = []
    exceptions: List[Dict] = []
    dims, dim_names = _dimension_frame(df, plan.dimensions)
    period_label = normalize_period_label(plan.sheet_period_value, plan.date_format)

    long_parts = []
    source_total = 0.0
    user_delta = 0.0
    fact_cells_before = 0
    for fact_col in plan.value_columns:
        numeric, bad_idxs = _parse_numeric_series(df[fact_col])
        for idx in bad_idxs[:1000]:
            exceptions.append({
                "type": "non_numeric_fact",
                "sheet": plan.sheet_name,
                "source_row": int(idx),
                "source_column": fact_col,
                "value": str(df.loc[idx, fact_col]),
            })
        fact_cells_before += int(numeric.notna().sum())
        source_total += float(numeric.fillna(0).sum())
        numeric2, delta, negative_count = _apply_negative_policy(numeric, plan.negative_policy)
        user_delta += delta
        if negative_count:
            audit.append(_audit("negative_policy", column=fact_col, policy=plan.negative_policy,
                                affected_cells=negative_count, numeric_delta=delta))
        part = dims.copy()
        part["Fact"] = fact_col
        part["__period"] = period_label
        part["__value"] = numeric2
        part["__source_row"] = df.index.astype(int)
        long_parts.append(part)

    long_df = pd.concat(long_parts, ignore_index=True)
    duplicate_keys = [c for c in plan.duplicate_keys if c in long_df.columns]
    if plan.duplicate_action == "aggregate_sum":
        duplicate_keys = duplicate_keys or (dim_names + ["Fact", "__period"])
    long_df = _apply_duplicate_policy_long(long_df, duplicate_keys, plan.duplicate_action, audit)
    wide = _pivot_without_implicit_aggregation(long_df, dim_names, fact_col="Fact")
    audit.append(_audit("transform_sheet_per_period", sheet_period=period_label, output_rows=len(wide)))
    meta = {
        "source_numeric_total": source_total,
        "expected_numeric_total": source_total + user_delta,
        "fact_cells_before": fact_cells_before,
        "dimension_columns": dim_names,
        "period_columns": [period_label],
        "_long_df": long_df,
    }
    return wide, long_df, audit, exceptions, meta


def transform_matrix(raw_df: pd.DataFrame, plan: SheetPlan) -> Tuple[pd.DataFrame, pd.DataFrame, List[Dict], List[Dict], Dict]:
    audit: List[Dict] = []
    exceptions: List[Dict] = []
    if plan.matrix_data_start_row is None or plan.matrix_value_start_col is None:
        raise ValueError("Matrix layout requires data-start row and value-start column.")
    if not plan.matrix_row_dimensions:
        raise ValueError("Matrix layout requires at least one row descriptor column.")
    if not plan.matrix_column_headers:
        raise ValueError("Matrix layout requires at least one column-header row mapping.")

    data_start = int(plan.matrix_data_start_row)
    value_start = int(plan.matrix_value_start_col)
    records: List[Dict[str, Any]] = []
    source_total = 0.0
    user_delta = 0.0
    fact_cells_before = 0

    for r in range(data_start, len(raw_df)):
        # Skip entirely blank rows.
        row_vals = raw_df.iloc[r].tolist()
        if all(_is_blank(x) for x in row_vals):
            continue
        row_dims = {name: raw_df.iat[r, c] for c, name in plan.matrix_row_dimensions.items() if c < raw_df.shape[1]}
        for c in range(value_start, raw_df.shape[1]):
            raw_value = raw_df.iat[r, c]
            if _is_blank(raw_value):
                continue
            numeric, bad_idxs = _parse_numeric_series(pd.Series([raw_value], index=[r]))
            if numeric.isna().all():
                exceptions.append({
                    "type": "non_numeric_matrix_fact",
                    "sheet": plan.sheet_name,
                    "source_row": int(r),
                    "source_column_index": int(c),
                    "value": str(raw_value),
                })
                continue
            val = float(numeric.iloc[0])
            source_total += val
            fact_cells_before += 1
            s = pd.Series([val])
            transformed, delta, negative_count = _apply_negative_policy(s, plan.negative_policy)
            val2 = float(transformed.iloc[0])
            user_delta += delta
            if negative_count:
                audit.append(_audit("negative_policy", source_row=int(r), source_col=int(c),
                                    policy=plan.negative_policy, affected_cells=1, numeric_delta=delta))
            rec: Dict[str, Any] = dict(row_dims)
            for hdr in plan.matrix_column_headers:
                if hdr.row_index >= raw_df.shape[0]:
                    raise ValueError(f"Matrix header row {hdr.row_index} is outside the sheet.")
                rec[hdr.output_name] = raw_df.iat[hdr.row_index, c]
            rec["Fact"] = plan.matrix_fact_label or plan.sheet_name
            rec["__value"] = val2
            rec["__source_row"] = int(r)
            rec["__source_col"] = int(c)
            records.append(rec)

    long_df = pd.DataFrame(records)
    if long_df.empty:
        raise ValueError("No numeric matrix cells were found with the selected boundaries.")

    period_col = plan.matrix_period_column
    if not period_col or period_col not in long_df.columns:
        raise ValueError("Choose which matrix row/header dimension represents the period.")
    if plan.date_format == "preserve":
        long_df["__period"] = long_df[period_col].astype(str).str.strip()
    else:
        parsed = long_df[period_col].map(parse_period)
        bad = parsed.isna() & ~long_df[period_col].map(_is_blank)
        if bad.any():
            examples = long_df.loc[bad, period_col].astype(str).head(5).tolist()
            raise ValueError(f"Matrix period values could not be parsed: {examples}")
        long_df["__period"] = parsed.map(lambda x: normalize_period_label(x, plan.date_format) if x is not None else "")

    dimension_cols = [c for c in long_df.columns if c not in {"__value", "__source_row", "__source_col", "__period", period_col, "Fact"}]
    # Explicit output order for matrix: row dimensions first, then column header dimensions.
    row_dim_names = list(plan.matrix_row_dimensions.values())
    header_dim_names = [h.output_name for h in plan.matrix_column_headers]
    dimension_cols = [c for c in row_dim_names + header_dim_names if c != period_col and c in long_df.columns]

    duplicate_keys = [c for c in plan.duplicate_keys if c in long_df.columns]
    if plan.duplicate_action == "aggregate_sum":
        duplicate_keys = duplicate_keys or (dimension_cols + ["Fact", "__period"])
    long_df = _apply_duplicate_policy_long(long_df, duplicate_keys, plan.duplicate_action, audit)
    wide = _pivot_without_implicit_aggregation(long_df, dimension_cols, fact_col="Fact")
    audit.append(_audit(
        "transform_matrix",
        data_start_row=data_start,
        value_start_col=value_start,
        numeric_cells=fact_cells_before,
        output_rows=len(wide),
        output_columns=len(wide.columns),
    ))
    meta = {
        "source_numeric_total": source_total,
        "expected_numeric_total": source_total + user_delta,
        "fact_cells_before": fact_cells_before,
        "dimension_columns": dimension_cols,
        "period_columns": [c for c in wide.columns if c not in dimension_cols + ["Fact"]],
        "_long_df": long_df,
    }
    return wide, long_df, audit, exceptions, meta


def transform_table(df: pd.DataFrame, plan: SheetPlan) -> TransformationResult:
    if plan.layout == "wide_periods":
        wide, long_df, audit, exceptions, meta = transform_wide(df, plan)
    elif plan.layout == "long_period_value":
        wide, long_df, audit, exceptions, meta = transform_long(df, plan)
    elif plan.layout == "sheet_per_period":
        wide, long_df, audit, exceptions, meta = transform_sheet_per_period(df, plan)
    else:
        raise ValueError(f"Layout {plan.layout!r} requires a raw grid or is unsupported by transform_table.")

    validation = validate_transformation(
        long_df=long_df,
        prepared=wide,
        source_numeric_total=meta["source_numeric_total"],
        expected_numeric_total=meta["expected_numeric_total"],
        fact_cells_before=meta["fact_cells_before"],
        row_count_before=len(df),
        exceptions=exceptions,
    )
    audit.append(_audit("validation", passed=validation.passed, delta=validation.delta))
    return TransformationResult(wide, audit, exceptions, validation, meta)


def transform_raw_matrix(raw_df: pd.DataFrame, plan: SheetPlan) -> TransformationResult:
    if plan.layout != "matrix":
        raise ValueError("transform_raw_matrix is only for matrix plans.")
    wide, long_df, audit, exceptions, meta = transform_matrix(raw_df, plan)
    validation = validate_transformation(
        long_df=long_df,
        prepared=wide,
        source_numeric_total=meta["source_numeric_total"],
        expected_numeric_total=meta["expected_numeric_total"],
        fact_cells_before=meta["fact_cells_before"],
        row_count_before=max(0, len(raw_df) - (plan.matrix_data_start_row or 0)),
        exceptions=exceptions,
    )
    audit.append(_audit("validation", passed=validation.passed, delta=validation.delta))
    return TransformationResult(wide, audit, exceptions, validation, meta)


def combine_prepared_results(results: Sequence[TransformationResult]) -> TransformationResult:
    """Combine multiple sheet results into one period-column output without implicit aggregation."""
    if not results:
        raise ValueError("No sheet results to combine.")

    long_frames = []
    dim_union: List[str] = []
    for r in results:
        ldf = r.metadata.get("_long_df")
        if ldf is None:
            raise ValueError("A sheet result is missing internal lineage needed for safe multi-sheet combination.")
        long_frames.append(ldf.copy())
        for c in r.metadata.get("dimension_columns", []):
            if c not in dim_union:
                dim_union.append(c)

    combined_long = pd.concat(long_frames, ignore_index=True, sort=False)
    # Missing dimensions from a sheet remain blank/NaN; they are never inferred.
    for c in dim_union:
        if c not in combined_long.columns:
            combined_long[c] = np.nan
    prepared = _pivot_without_implicit_aggregation(combined_long, dim_union, fact_col="Fact")

    audit = [entry for r in results for entry in r.audit_log]
    exceptions = [entry for r in results for entry in r.exceptions]
    source_total = sum(r.validation.source_numeric_total for r in results)
    expected_total = sum(r.validation.expected_total_after_user_actions for r in results)
    fact_cells_before = sum(r.validation.fact_cell_count_before for r in results)

    validation = validate_transformation(
        long_df=combined_long,
        prepared=prepared,
        source_numeric_total=source_total,
        expected_numeric_total=expected_total,
        fact_cells_before=fact_cells_before,
        row_count_before=sum(r.validation.row_count_before for r in results),
        exceptions=exceptions,
    )
    audit.append(_audit(
        "combine_sheet_outputs", sheets=len(results), output_rows=len(prepared),
        output_columns=len(prepared.columns), validation_passed=validation.passed
    ))
    return TransformationResult(
        prepared, audit, exceptions, validation,
        {"combined_sheets": len(results), "dimension_columns": dim_union, "_long_df": combined_long}
    )



def revalidate_after_approved_text_changes(
    result: TransformationResult,
    applied_decisions: Sequence[Dict[str, Any]],
) -> TransformationResult:
    """
    Re-run the Integrity Gate after approved textual standardizations.

    The same approved label substitutions are applied to the internal long-lineage
    copy solely for reconciliation, so the association digest still proves that
    facts remained attached to the correct dimensions and periods after the approved edits.
    """
    from .standardize import apply_text_decisions_to_long_df

    long_df = result.metadata.get("_long_df")
    if long_df is None:
        raise ValueError("Internal lineage is unavailable; cannot revalidate text changes safely.")
    adjusted_long = apply_text_decisions_to_long_df(long_df, applied_decisions)
    validation = validate_transformation(
        long_df=adjusted_long,
        prepared=result.prepared,
        source_numeric_total=result.validation.source_numeric_total,
        expected_numeric_total=result.validation.expected_total_after_user_actions,
        fact_cells_before=result.validation.fact_cell_count_before,
        row_count_before=result.validation.row_count_before,
        exceptions=result.exceptions,
    )
    result.metadata["_long_df"] = adjusted_long
    result.validation = validation
    result.audit_log.append(_audit(
        "revalidate_after_approved_text_standardization",
        approved_decisions=len(applied_decisions),
        passed=validation.passed,
        delta=validation.delta,
    ))
    return result
