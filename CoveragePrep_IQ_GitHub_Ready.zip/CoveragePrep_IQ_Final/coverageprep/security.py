from __future__ import annotations

import io
import os
import re
import zipfile
from typing import Any, Dict, List, Tuple

import pandas as pd


ALLOWED_EXTENSIONS = {".csv", ".xlsx"}
FORMULA_PREFIXES = ("=", "+", "-", "@")


def validate_upload(filename: str, file_bytes: bytes, max_bytes: int = 2_200_000_000) -> List[str]:
    """Fail closed on unsupported or suspicious inputs. Returns non-fatal warnings."""
    warnings: List[str] = []
    ext = os.path.splitext(filename.lower())[1]
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError("Only .csv and .xlsx are accepted. Macro-enabled workbooks and legacy .xls are rejected.")
    if len(file_bytes) > max_bytes:
        raise ValueError(f"File exceeds configured maximum size of {max_bytes:,} bytes.")
    if ext == ".xlsx":
        if not file_bytes.startswith(b"PK"):
            raise ValueError("The file extension is .xlsx but the file signature is not a valid OOXML ZIP container.")
        try:
            with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
                names = set(z.namelist())
                if "[Content_Types].xml" not in names:
                    raise ValueError("Invalid XLSX package: missing [Content_Types].xml.")
                if any("vbaProject.bin" in n for n in names):
                    raise ValueError("Macro content was detected. CoveragePrep IQ does not process macro-enabled workbooks.")
                external = [n for n in names if "externalLinks/" in n]
                if external:
                    warnings.append(f"Workbook contains {len(external)} external-link parts. Links are not followed or executed.")
        except zipfile.BadZipFile as e:
            raise ValueError("Invalid XLSX ZIP container.") from e
    return warnings


def formula_like_text_report(df: pd.DataFrame, sample_limit: int = 20) -> Dict[str, Any]:
    hits = []
    for col in df.columns:
        s = df[col]
        for idx, value in s.items():
            if isinstance(value, str) and value.startswith(FORMULA_PREFIXES):
                # Negative numeric strings are common facts; only flag text that isn't a valid number.
                try:
                    float(value.replace(",", ""))
                    continue
                except Exception:
                    pass
                hits.append({"row": int(idx), "column": str(col), "prefix": value[:1]})
                if len(hits) >= sample_limit:
                    break
        if len(hits) >= sample_limit:
            break
    return {"count_sampled": len(hits), "examples": hits, "note": "XLSX export disables formula-string interpretation; source values are not altered."}


def redact_value_for_logs(value: Any) -> str:
    """Avoid writing client values into debug/audit logs. Show type/shape only."""
    if value is None:
        return "<null>"
    if isinstance(value, str):
        return f"<str:{len(value)} chars>"
    if isinstance(value, (int, float)):
        return "<numeric>"
    return f"<{type(value).__name__}>"
