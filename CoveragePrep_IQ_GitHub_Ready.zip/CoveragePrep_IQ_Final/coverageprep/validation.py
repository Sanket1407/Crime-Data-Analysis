from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Sequence

import numpy as np
import pandas as pd

from .models import ValidationResult


def _tol(expected: float) -> float:
    return max(1e-8, abs(expected) * 1e-10)


def _numeric_period_columns(prepared: pd.DataFrame, long_df: pd.DataFrame) -> List[str]:
    periods = {str(x) for x in long_df.get("__period", pd.Series(dtype=object)).dropna().astype(str).unique()}
    return [c for c in prepared.columns if str(c) in periods]


def _group_sums_long(long_df: pd.DataFrame) -> Dict[str, float]:
    if long_df.empty:
        return {}
    work = long_df.copy()
    work["__period"] = work["__period"].astype(str)
    work["__value"] = pd.to_numeric(work["__value"], errors="coerce")
    grouped = work.groupby("__period", dropna=False)["__value"].sum(min_count=1)
    return {str(k): float(v) for k, v in grouped.items() if pd.notna(v)}


def _group_sums_wide(prepared: pd.DataFrame, period_cols: Sequence[str]) -> Dict[str, float]:
    result: Dict[str, float] = {}
    for c in period_cols:
        result[str(c)] = float(pd.to_numeric(prepared[c], errors="coerce").fillna(0).sum())
    return result


def _value_multiset_digest(values: pd.Series) -> str:
    nums = pd.to_numeric(values, errors="coerce").dropna().astype(float).tolist()
    # Sorting makes the digest insensitive to row order while preserving duplicate counts.
    payload = json.dumps(sorted(round(x, 12) for x in nums), separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()



def _canon_scalar(v: Any) -> Any:
    if v is None:
        return "<NA>"
    if isinstance(v, float) and np.isnan(v):
        return "<NA>"
    if isinstance(v, (np.floating, float, np.integer, int)) and not isinstance(v, bool):
        return round(float(v), 12)
    return str(v)


def _record_multiset_digest(long_df: pd.DataFrame, prepared: pd.DataFrame, period_cols: Sequence[str]) -> str:
    """
    Compare the full (dimensions + Fact + period + value) multiset after approved actions.
    This is stronger than comparing only totals or the value multiset: it detects a value
    being accidentally attached to the wrong product/channel/period while keeping totals equal.
    """
    id_cols = [c for c in prepared.columns if c not in period_cols]
    source_cols = [c for c in id_cols if c in long_df.columns]

    source_records = []
    for _, r in long_df.iterrows():
        rec = tuple(_canon_scalar(r.get(c)) for c in source_cols) + (
            _canon_scalar(r.get("__period")),
            _canon_scalar(r.get("__value")),
        )
        source_records.append(rec)

    if period_cols:
        melted = prepared.melt(id_vars=id_cols, value_vars=list(period_cols), var_name="__period", value_name="__value")
        # Pivoted output contains structural NaNs for period combinations that did not exist in source.
        # Exclude those cells when comparing lineage records.
        melted = melted[pd.to_numeric(melted["__value"], errors="coerce").notna()]
    else:
        melted = pd.DataFrame(columns=id_cols + ["__period", "__value"])

    output_records = []
    for _, r in melted.iterrows():
        rec = tuple(_canon_scalar(r.get(c)) for c in source_cols) + (
            _canon_scalar(r.get("__period")),
            _canon_scalar(r.get("__value")),
        )
        output_records.append(rec)

    payload = json.dumps(sorted(source_records, key=repr), ensure_ascii=False, separators=(",", ":"), default=str)
    payload2 = json.dumps(sorted(output_records, key=repr), ensure_ascii=False, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest() + ":" + hashlib.sha256(payload2.encode("utf-8")).hexdigest()

def validate_transformation(
    *,
    long_df: pd.DataFrame,
    prepared: pd.DataFrame,
    source_numeric_total: float,
    expected_numeric_total: float,
    fact_cells_before: int,
    row_count_before: int,
    exceptions: List[Dict[str, Any]],
) -> ValidationResult:
    period_cols = _numeric_period_columns(prepared, long_df)
    output_total = 0.0
    fact_cells_after = 0
    melted_values: List[pd.Series] = []
    for c in period_cols:
        numeric = pd.to_numeric(prepared[c], errors="coerce")
        output_total += float(numeric.fillna(0).sum())
        fact_cells_after += int(numeric.notna().sum())
        melted_values.append(numeric)

    delta = float(output_total - expected_numeric_total)
    total_ok = abs(delta) <= _tol(expected_numeric_total)

    long_group = _group_sums_long(long_df)
    wide_group = _group_sums_wide(prepared, period_cols)
    period_keys = sorted(set(long_group) | set(wide_group))
    period_reconciliation = []
    period_ok = True
    for p in period_keys:
        lv = float(long_group.get(p, 0.0))
        wv = float(wide_group.get(p, 0.0))
        d = wv - lv
        ok = abs(d) <= _tol(lv)
        period_ok = period_ok and ok
        period_reconciliation.append({"period": p, "source_after_actions": lv, "output": wv, "delta": d, "passed": ok})

    long_digest = _value_multiset_digest(long_df["__value"]) if "__value" in long_df else ""
    if melted_values:
        output_values = pd.concat(melted_values, ignore_index=True)
        wide_digest = _value_multiset_digest(output_values)
    else:
        wide_digest = _value_multiset_digest(pd.Series(dtype=float))
    multiset_ok = long_digest == wide_digest

    record_pair = _record_multiset_digest(long_df, prepared, period_cols)
    source_record_digest, output_record_digest = record_pair.split(":", 1)
    record_association_ok = source_record_digest == output_record_digest
    fact_cell_count_ok = int(long_df.get("__value", pd.Series(dtype=float)).notna().sum()) == int(fact_cells_after)

    nonnumeric_fact_exceptions = sum(1 for e in exceptions if e.get("type", "").startswith("non_numeric"))

    checks: List[Dict[str, Any]] = [
        {
            "check": "numeric_total_reconciliation",
            "passed": total_ok,
            "source_total": source_numeric_total,
            "expected_after_user_actions": expected_numeric_total,
            "output_total": output_total,
            "delta": delta,
        },
        {
            "check": "period_level_reconciliation",
            "passed": period_ok,
            "details": period_reconciliation,
        },
        {
            "check": "numeric_value_multiset_preserved_after_actions",
            "passed": multiset_ok,
            "source_digest": long_digest,
            "output_digest": wide_digest,
        },
        {
            "check": "dimension_period_value_association_preserved",
            "passed": record_association_ok,
            "source_digest": source_record_digest,
            "output_digest": output_record_digest,
            "note": "Detects values being attached to the wrong dimension/period even when totals still match.",
        },
        {
            "check": "fact_cell_count_preserved_after_actions",
            "passed": fact_cell_count_ok,
            "source_after_actions": int(long_df.get("__value", pd.Series(dtype=float)).notna().sum()),
            "output": int(fact_cells_after),
        },
        {
            "check": "unparseable_fact_cells",
            "passed": nonnumeric_fact_exceptions == 0,
            "count": nonnumeric_fact_exceptions,
            "note": "Flagged rather than assumed or overwritten.",
        },
    ]

    # Non-numeric selected fact cells are a validation warning/failure because they were not transformed.
    passed = bool(total_ok and period_ok and multiset_ok and record_association_ok and fact_cell_count_ok and nonnumeric_fact_exceptions == 0)
    return ValidationResult(
        passed=passed,
        source_numeric_total=float(source_numeric_total),
        expected_total_after_user_actions=float(expected_numeric_total),
        output_numeric_total=float(output_total),
        delta=delta,
        row_count_before=int(row_count_before),
        row_count_after=int(len(prepared)),
        fact_cell_count_before=int(fact_cells_before),
        fact_cell_count_after=int(fact_cells_after),
        checks=checks,
    )
