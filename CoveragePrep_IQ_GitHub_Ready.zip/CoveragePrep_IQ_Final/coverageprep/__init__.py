"""CoveragePrep IQ core package."""

__version__ = "2.0.0"
