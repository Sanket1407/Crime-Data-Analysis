from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


CANONICAL_ROLES = [
    "Country", "Region", "Channel", "City", "State",
    "Category", "Brand", "SKU", "Fact", "Extra",
]

LAYOUTS = {
    "wide_periods": "Period values are already separate columns",
    "long_period_value": "One/more period fields + one/more fact/value fields",
    "matrix": "Row descriptors crossed with column headers to produce values",
    "sheet_per_period": "Each sheet represents a period; values live in rows",
}

NEGATIVE_POLICIES = {
    "keep": "Do nothing",
    "absolute": "Transform negatives to positive",
    "zero": "Transform negatives to 0",
}


@dataclass
class DimensionSpec:
    source: str
    keep: bool = True
    role: str = "Extra"
    output_name: Optional[str] = None
    position: int = 999

    def final_name(self) -> str:
        return (self.output_name or self.source).strip()


@dataclass
class MatrixHeaderSpec:
    row_index: int
    output_name: str
    role: str = "Extra"


@dataclass
class SheetPlan:
    sheet_name: str
    layout: str
    header_row: int = 0

    # Output dimensions / descriptor fields
    dimensions: List[DimensionSpec] = field(default_factory=list)

    # wide_periods
    period_columns: List[str] = field(default_factory=list)

    # long_period_value / sheet_per_period
    period_components: List[str] = field(default_factory=list)
    value_columns: List[str] = field(default_factory=list)

    # sheet_per_period
    sheet_period_value: Optional[str] = None

    # matrix: raw-grid coordinates
    matrix_data_start_row: Optional[int] = None
    matrix_value_start_col: Optional[int] = None
    matrix_row_dimensions: Dict[int, str] = field(default_factory=dict)  # col idx -> output name
    matrix_column_headers: List[MatrixHeaderSpec] = field(default_factory=list)
    matrix_period_column: Optional[str] = None
    matrix_fact_label: Optional[str] = None

    # User-controlled transformations
    date_format: str = "preserve"  # preserve | YYYY-MM | MMM-YYYY | MM.YYYY | YYYYMM
    negative_policy: str = "keep"
    duplicate_action: str = "keep"  # keep | drop_exact | aggregate_sum
    duplicate_keys: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ValidationResult:
    passed: bool
    source_numeric_total: float
    expected_total_after_user_actions: float
    output_numeric_total: float
    delta: float
    row_count_before: int
    row_count_after: int
    fact_cell_count_before: int
    fact_cell_count_after: int
    checks: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TransformationResult:
    prepared: Any
    audit_log: List[Dict[str, Any]]
    exceptions: List[Dict[str, Any]]
    validation: ValidationResult
    metadata: Dict[str, Any] = field(default_factory=dict)
