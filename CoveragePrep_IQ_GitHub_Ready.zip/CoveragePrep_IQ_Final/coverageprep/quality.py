from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

import numpy as np
import pandas as pd

from .design import STANDARD_ROLES
from .profiler import parse_period


def _blank_series(s: pd.Series) -> pd.Series:
    return s.isna() | s.astype(str).str.strip().isin(["", "nan", "None"])


def _numericish(v: Any) -> bool:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return False
    if isinstance(v, (int, float, np.number)) and not isinstance(v, bool):
        return True
    try:
        float(str(v).strip().replace(",", ""))
        return True
    except Exception:
        return False


def _issue(severity: str, category: str, field: str, issue: str, affected: int, total: int, recommendation: str) -> Dict[str, Any]:
    return {
        "Severity": severity,
        "Category": category,
        "Field": field,
        "Issue": issue,
        "Affected Rows/Cells": int(affected),
        "Affected %": round((100.0 * affected / total), 2) if total else 0.0,
        "Recommendation": recommendation,
    }


def analyze_data_quality(
    df: pd.DataFrame,
    *,
    assigned_roles: Optional[Sequence[str]] = None,
    profile_warnings: Optional[Sequence[str]] = None,
) -> pd.DataFrame:
    """Return actionable quality issues without modifying any value."""
    issues: List[Dict[str, Any]] = []
    rows = len(df)
    if df.empty:
        issues.append(_issue("Critical", "Structure", "Dataset", "Prepared dataset is empty.", 0, 0, "Review the selected header row, dimensions, fact fields and period fields."))
        return pd.DataFrame(issues)

    # Workbook/profile warnings are carried forward as review items.
    for warning in profile_warnings or []:
        issues.append(_issue("Medium", "Structure", "Workbook", str(warning), 1, 1, "Review the source structure before final approval."))

    # Duplicate full rows are surfaced but never removed automatically.
    dup = int(df.duplicated(keep=False).sum())
    if dup:
        issues.append(_issue("Medium", "Duplicates", "Dataset", "Exact duplicate output rows detected.", dup, rows, "Keep by default; remove only if the coverage expert explicitly defines them as duplicates."))

    period_cols = [c for c in df.columns if parse_period(c) is not None]
    dimension_cols = [c for c in df.columns if c not in period_cols]

    for c in dimension_cols:
        s = df[c]
        blank = int(_blank_series(s).sum())
        if blank:
            sev = "High" if c in {"SKU", "Fact"} else "Medium"
            issues.append(_issue(sev, "Completeness", str(c), "Blank/missing values present.", blank, rows, "Flag for user/customer clarification; do not infer a replacement value."))

        nonblank = s[~_blank_series(s)]
        if len(nonblank):
            numeric_count = sum(_numericish(v) for v in nonblank.tolist())
            text_count = len(nonblank) - numeric_count
            if numeric_count and text_count:
                issues.append(_issue("Low", "Type consistency", str(c), "Mixed numeric-like and text-like values detected.", min(numeric_count, text_count), len(nonblank), "Review whether this field contains multiple semantic types or identifiers stored inconsistently."))

            # Leading/trailing or repeated whitespace.
            txt = nonblank.astype(str)
            ws = int((txt != txt.str.strip()).sum() + txt.str.contains(r"\s{2,}", regex=True).sum())
            if ws:
                issues.append(_issue("Low", "Formatting", str(c), "Whitespace inconsistencies detected.", min(ws, len(nonblank)), len(nonblank), "Use Standardization Advisor; apply only approved formatting changes."))

            # Case/spacing variants with same normalized key.
            norm = txt.str.strip().str.replace(r"\s+", " ", regex=True).str.casefold().str.replace(r"[^\w]+", "", regex=True)
            variant_groups = pd.DataFrame({"raw": txt.values, "norm": norm.values}).groupby("norm")["raw"].nunique()
            variant_count = int((variant_groups > 1).sum())
            if variant_count:
                issues.append(_issue("Low", "Standardization", str(c), f"{variant_count} near-identical surface-form group(s) detected.", variant_count, max(1, txt.nunique()), "Review case/spacing variants in Standardization Advisor instead of auto-overwriting them."))

    for c in period_cols:
        numeric = pd.to_numeric(df[c], errors="coerce")
        negatives = int((numeric < 0).sum())
        if negatives:
            issues.append(_issue("Medium", "Numeric", str(c), "Negative fact values present.", negatives, int(numeric.notna().sum()), "Use the explicit negative-value policy: keep, absolute, or zero. Never change negatives silently."))
        nonnumeric = int((numeric.isna() & ~_blank_series(df[c])).sum())
        if nonnumeric:
            issues.append(_issue("High", "Numeric", str(c), "Non-numeric values appear in a prepared period column.", nonnumeric, rows, "Return to the fact/period configuration; flag unparseable source cells for review."))

    assigned = {r for r in (assigned_roles or []) if r and r != "Extra"}
    for role in STANDARD_ROLES:
        if role not in df.columns and role not in assigned:
            issues.append(_issue("Info", "Standard output", role, "Canonical role is not present in the prepared output.", 0, rows, "In Generic NIQ Standard mode add a blank placeholder; in Guide-Specific mode this can remain absent if the guide does not require it."))
        elif role in df.columns and int((~_blank_series(df[role])).sum()) == 0:
            issues.append(_issue("Info", "Standard output", role, "Canonical field is present as a blank placeholder.", rows, rows, "Leave blank unless the source contains this information; do not infer it."))

    if not issues:
        issues.append(_issue("Info", "Quality", "Dataset", "No rule-based quality issues detected.", 0, rows, "Proceed to validation and review the audit trail."))

    order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
    out = pd.DataFrame(issues)
    out["_order"] = out["Severity"].map(order).fillna(9)
    return out.sort_values(["_order", "Category", "Field"]).drop(columns=["_order"]).reset_index(drop=True)


def summarize_quality(issues: pd.DataFrame) -> Dict[str, int]:
    if issues is None or issues.empty:
        return {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    counts = issues["Severity"].value_counts().to_dict()
    return {k: int(counts.get(k, 0)) for k in ["Critical", "High", "Medium", "Low", "Info"]}
