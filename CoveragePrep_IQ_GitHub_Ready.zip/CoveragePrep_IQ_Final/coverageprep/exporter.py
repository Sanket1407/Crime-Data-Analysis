from __future__ import annotations

import io
import json
import zipfile
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd

from .models import SheetPlan, TransformationResult

EXCEL_MAX_ROWS = 1_048_576
EXCEL_MAX_COLUMNS = 16_384


def excel_feasible(df: pd.DataFrame) -> bool:
    # Header consumes one Excel row.
    return (len(df) + 1) <= EXCEL_MAX_ROWS and len(df.columns) <= EXCEL_MAX_COLUMNS


def _safe_df(records: List[Dict[str, Any]]) -> pd.DataFrame:
    if not records:
        return pd.DataFrame()
    flat = []
    for rec in records:
        row = {}
        for k, v in rec.items():
            if isinstance(v, (dict, list, tuple)):
                row[k] = json.dumps(v, ensure_ascii=False)
            else:
                row[k] = v
        flat.append(row)
    return pd.DataFrame(flat)


def to_excel_bytes(result: TransformationResult, plan: Optional[SheetPlan] = None) -> bytes:
    if not excel_feasible(result.prepared):
        raise ValueError("Prepared output exceeds Excel limits; export as CSV package instead.")
    buf = io.BytesIO()
    engine_kwargs = {"options": {"strings_to_formulas": False, "strings_to_urls": False}}
    with pd.ExcelWriter(buf, engine="xlsxwriter", engine_kwargs=engine_kwargs) as writer:
        result.prepared.to_excel(writer, sheet_name="Prepared_Data", index=False)
        pd.DataFrame([result.validation.to_dict()]).drop(columns=["checks"], errors="ignore").to_excel(
            writer, sheet_name="Validation_Summary", index=False
        )
        _safe_df(result.validation.checks).to_excel(writer, sheet_name="Validation_Checks", index=False)
        _safe_df(result.exceptions).to_excel(writer, sheet_name="Exceptions", index=False)
        _safe_df(result.audit_log).to_excel(writer, sheet_name="Audit_Log", index=False)
        quality = result.metadata.get("quality_issues")
        if isinstance(quality, pd.DataFrame) and not quality.empty:
            quality.to_excel(writer, sheet_name="Data_Quality", index=False)
        std = result.metadata.get("standardization_decisions")
        if isinstance(std, pd.DataFrame) and not std.empty:
            std.to_excel(writer, sheet_name="Standardization", index=False)
        mapping = result.metadata.get("mapping_recommendations")
        if isinstance(mapping, pd.DataFrame) and not mapping.empty:
            mapping.to_excel(writer, sheet_name="Mapping_Advisor", index=False)
        kpis = result.metadata.get("kpis")
        if isinstance(kpis, dict) and kpis:
            pd.DataFrame([kpis]).to_excel(writer, sheet_name="KPI_Summary", index=False)
        if plan is not None:
            pd.DataFrame([{"plan_json": json.dumps(plan.to_dict(), ensure_ascii=False, indent=2)}]).to_excel(
                writer, sheet_name="Configuration", index=False
            )
        # Usability formatting; no formulas are inserted.
        workbook = writer.book
        header_fmt = workbook.add_format({"bold": True, "bg_color": "#E8F0FE", "border": 1})
        for sheet_name, worksheet in writer.sheets.items():
            worksheet.freeze_panes(1, 0)
            dim_rowmax = worksheet.dim_rowmax if worksheet.dim_rowmax is not None else 0
            dim_colmax = worksheet.dim_colmax if worksheet.dim_colmax is not None else 0
            if dim_rowmax >= 0 and dim_colmax >= 0:
                worksheet.autofilter(0, 0, max(0, dim_rowmax), max(0, dim_colmax))
            worksheet.set_row(0, None, header_fmt)
            worksheet.set_column(0, min(30, max(0, dim_colmax)), 18)
    return buf.getvalue()


def to_csv_package_bytes(result: TransformationResult, plan: Optional[SheetPlan] = None) -> bytes:
    """ZIP with the main CSV plus evidence files for outputs beyond Excel limits."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("Prepared_Data.csv", result.prepared.to_csv(index=False))
        z.writestr("Validation.json", json.dumps(result.validation.to_dict(), ensure_ascii=False, indent=2, default=str))
        z.writestr("Exceptions.csv", _safe_df(result.exceptions).to_csv(index=False))
        z.writestr("Audit_Log.csv", _safe_df(result.audit_log).to_csv(index=False))
        quality = result.metadata.get("quality_issues")
        if isinstance(quality, pd.DataFrame) and not quality.empty:
            z.writestr("Data_Quality.csv", quality.to_csv(index=False))
        std = result.metadata.get("standardization_decisions")
        if isinstance(std, pd.DataFrame) and not std.empty:
            z.writestr("Standardization.csv", std.to_csv(index=False))
        mapping = result.metadata.get("mapping_recommendations")
        if isinstance(mapping, pd.DataFrame) and not mapping.empty:
            z.writestr("Mapping_Advisor.csv", mapping.to_csv(index=False))
        kpis = result.metadata.get("kpis")
        if isinstance(kpis, dict) and kpis:
            z.writestr("KPI_Summary.csv", pd.DataFrame([kpis]).to_csv(index=False))
        if plan is not None:
            z.writestr("Transformation_Plan.json", json.dumps(plan.to_dict(), ensure_ascii=False, indent=2))
        z.writestr(
            "README_SECURITY.txt",
            "CoveragePrep IQ CSV package\n"
            "The main CSV preserves source strings and numbers. Because spreadsheet applications may interpret "
            "text beginning with formula characters when a CSV is opened interactively, use trusted downstream "
            "ingestion or the XLSX export when feasible. No values were silently prefixed or altered.\n",
        )
    return buf.getvalue()


def choose_export(result: TransformationResult, plan: Optional[SheetPlan] = None) -> Tuple[str, str, bytes]:
    if excel_feasible(result.prepared):
        return "xlsx", "coverageprep_output.xlsx", to_excel_bytes(result, plan)
    return "zip", "coverageprep_output_csv_package.zip", to_csv_package_bytes(result, plan)
