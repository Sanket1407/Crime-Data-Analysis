from __future__ import annotations

import io
import math
import re
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from dateutil import parser as date_parser


_PERIOD_P_RE = re.compile(r"^(?P<year>19\d{2}|20\d{2})\s*[-_/ ]?P(?P<month>0?[1-9]|1[0-2])$", re.I)
_YEAR_MONTH_DIGIT_RE = re.compile(r"^(?P<year>19\d{2}|20\d{2})[-_/ ](?P<month>0?[1-9]|1[0-2])$")
_MONTH_YEAR_DIGIT_RE = re.compile(r"^(?P<month>0?[1-9]|1[0-2])[-_/. ](?P<year>19\d{2}|20\d{2})$")
_YYYYMM_RE = re.compile(r"^(?P<year>19\d{2}|20\d{2})(?P<month>0[1-9]|1[0-2])$")


@dataclass
class SheetProfile:
    sheet_name: str
    raw_shape: Tuple[int, int]
    header_row_candidate: int
    header_score: float
    columns: List[str]
    date_like_columns: List[str]
    numeric_like_columns: List[str]
    duplicate_column_names: List[str]
    blank_header_count: int
    predicted_layout: str
    layout_confidence: float
    warnings: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def list_sheets(file_bytes: bytes, filename: str) -> List[str]:
    lower = filename.lower()
    if lower.endswith(".csv"):
        return ["(CSV)"]
    if not lower.endswith(".xlsx"):
        raise ValueError("CoveragePrep IQ accepts CSV and XLSX files. XLSM/XLS/archives are intentionally rejected.")
    xls = pd.ExcelFile(io.BytesIO(file_bytes), engine="openpyxl")
    return xls.sheet_names


def read_raw_grid(file_bytes: bytes, filename: str, sheet_name: Optional[str] = None, nrows: Optional[int] = None) -> pd.DataFrame:
    lower = filename.lower()
    if lower.endswith(".csv"):
        return pd.read_csv(
            io.BytesIO(file_bytes),
            header=None,
            dtype=object,
            keep_default_na=False,
            nrows=nrows,
            engine="python",
        )
    if lower.endswith(".xlsx"):
        return pd.read_excel(
            io.BytesIO(file_bytes),
            sheet_name=sheet_name,
            header=None,
            dtype=object,
            nrows=nrows,
            engine="openpyxl",
        )
    raise ValueError("Unsupported file type. Use CSV or XLSX.")


def _is_blank(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    s = str(v).strip()
    return s == "" or s.lower() in {"nan", "none"}


def _is_numericish(v: Any) -> bool:
    if _is_blank(v):
        return False
    if isinstance(v, (int, float, np.number)) and not isinstance(v, bool):
        return True
    s = str(v).strip().replace(",", "").replace("%", "")
    try:
        float(s)
        return True
    except Exception:
        return False


def header_row_score(row: Sequence[Any]) -> float:
    nonblank = [v for v in row if not _is_blank(v)]
    if not nonblank:
        return -1e9
    textish = sum(not _is_numericish(v) for v in nonblank)
    unique = len({str(v).strip().lower() for v in nonblank})
    duplicate_penalty = max(0, len(nonblank) - unique)
    blank_penalty = len(row) - len(nonblank)
    # Favor dense, mostly textual and mostly unique rows.
    return (2.0 * textish) + (0.5 * len(nonblank)) - (1.5 * duplicate_penalty) - (0.05 * blank_penalty)


def detect_header_row(raw_df: pd.DataFrame, scan_rows: int = 20) -> Tuple[int, float]:
    best_idx = 0
    best_score = -1e9
    for idx in range(min(scan_rows, len(raw_df))):
        score = header_row_score(raw_df.iloc[idx].tolist())
        if score > best_score:
            best_idx, best_score = idx, score
    return best_idx, float(best_score)


def build_dataframe(raw_df: pd.DataFrame, header_row: int) -> pd.DataFrame:
    if raw_df.empty:
        return pd.DataFrame()
    header = []
    seen: Dict[str, int] = {}
    for j, value in enumerate(raw_df.iloc[header_row].tolist()):
        base = "" if _is_blank(value) else str(value).strip()
        if not base:
            base = f"Unnamed_{j+1}"
        count = seen.get(base, 0)
        seen[base] = count + 1
        header.append(base if count == 0 else f"{base}__{count+1}")
    df = raw_df.iloc[header_row + 1 :].copy()
    df.columns = header
    df = df.dropna(axis=0, how="all")
    # Treat rows of all empty strings as empty as well.
    if not df.empty:
        nonempty_mask = df.apply(lambda r: any(not _is_blank(v) for v in r), axis=1)
        df = df.loc[nonempty_mask]
    return df.reset_index(drop=True)


def parse_period(value: Any) -> Optional[pd.Timestamp]:
    """Conservative parser used for *period labels*, never to overwrite source values silently."""
    if value is None or _is_blank(value):
        return None
    if isinstance(value, pd.Timestamp):
        return value
    if isinstance(value, datetime):
        return pd.Timestamp(value)
    if isinstance(value, np.datetime64):
        return pd.Timestamp(value)

    # Excel serial date headers: keep a conservative range.
    if isinstance(value, (int, float, np.number)) and not isinstance(value, bool):
        x = float(value)
        if 20000 <= x <= 80000 and x.is_integer():
            try:
                return pd.Timestamp("1899-12-30") + pd.to_timedelta(int(x), unit="D")
            except Exception:
                return None
        # A plain year is not enough to identify a period column.
        return None

    s = str(value).strip()
    if not s:
        return None

    m = _PERIOD_P_RE.match(s)
    if m:
        return pd.Timestamp(year=int(m.group("year")), month=int(m.group("month")), day=1)
    m = _YEAR_MONTH_DIGIT_RE.match(s)
    if m:
        return pd.Timestamp(year=int(m.group("year")), month=int(m.group("month")), day=1)
    m = _MONTH_YEAR_DIGIT_RE.match(s)
    if m:
        return pd.Timestamp(year=int(m.group("year")), month=int(m.group("month")), day=1)
    m = _YYYYMM_RE.match(s)
    if m:
        return pd.Timestamp(year=int(m.group("year")), month=int(m.group("month")), day=1)

    # Avoid treating arbitrary numeric identifiers as dates.
    if re.fullmatch(r"\d+(\.\d+)?", s):
        return None

    # Require a visible year to avoid parsing words like "May" without context.
    if not re.search(r"(19\d{2}|20\d{2}|\d{2})", s):
        return None
    try:
        dt = date_parser.parse(s, fuzzy=False, default=datetime(2000, 1, 1))
        if 1990 <= dt.year <= 2100:
            return pd.Timestamp(year=dt.year, month=dt.month, day=1)
    except Exception:
        return None
    return None


def normalize_period_label(value: Any, fmt: str) -> str:
    if fmt == "preserve":
        return str(value).strip()
    ts = parse_period(value)
    if ts is None:
        raise ValueError(f"Could not parse period label {value!r}; choose Preserve or correct the period selection.")
    if fmt == "YYYY-MM":
        return ts.strftime("%Y-%m")
    if fmt == "MMM-YYYY":
        return ts.strftime("%b-%Y")
    if fmt == "MM.YYYY":
        return ts.strftime("%m.%Y")
    if fmt == "YYYYMM":
        return ts.strftime("%Y%m")
    raise ValueError(f"Unsupported date format: {fmt}")


def combine_period_components(df: pd.DataFrame, columns: Sequence[str], fmt: str = "YYYY-MM") -> pd.Series:
    """
    Combine user-selected time components without assuming missing information.
    Supports Year + P01/P02, Year + month-name/number, or a single parseable period field.
    """
    if not columns:
        raise ValueError("At least one period component is required.")
    if len(columns) == 1:
        source = df[columns[0]]
        if fmt == "preserve":
            return source.astype(str).str.strip()
        parsed = source.map(parse_period)
        bad = parsed.isna() & source.map(lambda x: not _is_blank(x))
        if bad.any():
            examples = source[bad].astype(str).head(5).tolist()
            raise ValueError(f"Unparseable period values in {columns[0]}: {examples}")
        return parsed.map(lambda x: normalize_period_label(x, fmt) if x is not None else "")

    # Two or more components. Common explicit pattern: year + period/month.
    cols = [df[c] for c in columns]

    def parse_row(vals: Sequence[Any]) -> Optional[pd.Timestamp]:
        text = [str(v).strip() for v in vals if not _is_blank(v)]
        if not text:
            return None
        year = None
        month = None
        for token in text:
            if re.fullmatch(r"(19\d{2}|20\d{2})", token):
                year = int(token)
                continue
            mp = re.fullmatch(r"P(0?[1-9]|1[0-2])", token, flags=re.I)
            if mp:
                month = int(mp.group(1))
                continue
            if re.fullmatch(r"0?[1-9]|1[0-2]", token):
                if month is None:
                    month = int(token)
                    continue
            # Try month names but do not let them supply a year.
            try:
                candidate = date_parser.parse(token, fuzzy=False, default=datetime(2000, 1, 1))
                if token.lower() not in {"2000"} and 1 <= candidate.month <= 12:
                    month = candidate.month
            except Exception:
                pass
        if year is not None and month is not None:
            return pd.Timestamp(year=year, month=month, day=1)
        # Last resort: concatenate only user-selected components.
        return parse_period(" ".join(text))

    parsed = pd.Series([parse_row(vals) for vals in zip(*cols)], index=df.index)
    nonblank = pd.Series([any(not _is_blank(v) for v in vals) for vals in zip(*cols)], index=df.index)
    bad = parsed.isna() & nonblank
    if bad.any():
        examples = df.loc[bad, list(columns)].head(5).to_dict("records")
        raise ValueError(f"Could not combine selected period components. Examples: {examples}")
    if fmt == "preserve":
        # Preserve is ambiguous for multi-component input; use a lossless visible join.
        return df[list(columns)].astype(str).agg(" | ".join, axis=1)
    return parsed.map(lambda x: normalize_period_label(x, fmt) if x is not None else "")


def _numeric_ratio(series: pd.Series) -> float:
    if series.empty:
        return 0.0
    cleaned = series.map(lambda x: str(x).strip().replace(",", "") if not _is_blank(x) else "")
    parsed = pd.to_numeric(cleaned, errors="coerce")
    denom = max(1, int((cleaned != "").sum()))
    return float(parsed.notna().sum() / denom)


def profile_sheet(file_bytes: bytes, filename: str, sheet_name: Optional[str], scan_rows: int = 200) -> SheetProfile:
    raw = read_raw_grid(file_bytes, filename, sheet_name, nrows=scan_rows)
    header_row, hscore = detect_header_row(raw)
    df = build_dataframe(raw, header_row)
    columns = list(map(str, df.columns))
    date_like = [c for c in columns if parse_period(c) is not None]
    numeric_like = [c for c in columns if _numeric_ratio(df[c].head(100)) >= 0.8]

    base_names = [re.sub(r"__\d+$", "", c) for c in columns]
    dupes = sorted({x for x in base_names if base_names.count(x) > 1})
    blank_headers = sum(c.startswith("Unnamed_") for c in columns)

    warnings: List[str] = []
    if dupes:
        warnings.append(f"Duplicate header labels detected: {dupes[:5]}")
    if blank_headers:
        warnings.append(f"{blank_headers} blank header cells were assigned temporary names.")

    n_period_cols = len(date_like)
    n_cols = len(columns)
    # Structural-only suggestion; user confirms before transform.
    if n_period_cols >= 2:
        layout, conf = "wide_periods", min(0.98, 0.65 + 0.03 * n_period_cols)
    else:
        lower_names = [c.lower() for c in columns]
        has_year = any(re.search(r"\b(year|año|ano|annee|jahr)\b", x) for x in lower_names)
        has_period = any(re.search(r"\b(month|period|periodo|monthyear|date|fecha|calendar)\b", x) for x in lower_names)
        if has_year and has_period and numeric_like:
            layout, conf = "long_period_value", 0.82
        elif header_row >= 1 and raw.shape[1] >= 6 and raw.shape[0] >= 6:
            # Matrix is deliberately conservative; no automatic transform.
            layout, conf = "matrix", 0.55
        else:
            layout, conf = "long_period_value", 0.45

    return SheetProfile(
        sheet_name=sheet_name or "(CSV)",
        raw_shape=tuple(map(int, raw.shape)),
        header_row_candidate=int(header_row),
        header_score=round(hscore, 2),
        columns=columns,
        date_like_columns=date_like,
        numeric_like_columns=numeric_like,
        duplicate_column_names=dupes,
        blank_header_count=int(blank_headers),
        predicted_layout=layout,
        layout_confidence=round(conf, 2),
        warnings=warnings,
    )


def profile_workbook(file_bytes: bytes, filename: str) -> List[SheetProfile]:
    sheets = list_sheets(file_bytes, filename)
    profiles = []
    for sheet in sheets:
        actual_sheet = None if sheet == "(CSV)" else sheet
        profiles.append(profile_sheet(file_bytes, filename, actual_sheet))
    return profiles
