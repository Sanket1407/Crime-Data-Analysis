from __future__ import annotations

from typing import Any, Dict, Optional

import pandas as pd

from .mapping import mapping_summary
from .quality import summarize_quality


def build_kpis(
    *,
    prepared: pd.DataFrame,
    validation: Any,
    elapsed_seconds: float,
    exceptions_count: int,
    quality_issues: Optional[pd.DataFrame] = None,
    standardization_decisions: Optional[pd.DataFrame] = None,
    mapping_recommendations: Optional[pd.DataFrame] = None,
    sheets_processed: int = 1,
) -> Dict[str, Any]:
    q = summarize_quality(quality_issues if quality_issues is not None else pd.DataFrame())
    m = mapping_summary(mapping_recommendations if mapping_recommendations is not None else pd.DataFrame())
    std_count = 0
    if standardization_decisions is not None and not standardization_decisions.empty:
        if "Affected Rows" in standardization_decisions.columns:
            std_count = int(pd.to_numeric(standardization_decisions["Affected Rows"], errors="coerce").fillna(0).sum())
        elif "affected_rows" in standardization_decisions.columns:
            std_count = int(pd.to_numeric(standardization_decisions["affected_rows"], errors="coerce").fillna(0).sum())
    return {
        "Sheets processed": int(sheets_processed),
        "Prepared rows": int(len(prepared)),
        "Prepared columns": int(len(prepared.columns)),
        "Fact cells before": int(getattr(validation, "fact_cell_count_before", 0)),
        "Fact cells after": int(getattr(validation, "fact_cell_count_after", 0)),
        "Runtime seconds": round(float(elapsed_seconds), 3),
        "Integrity gate": "PASS" if bool(getattr(validation, "passed", False)) else "FAIL",
        "Numeric delta": float(getattr(validation, "delta", 0.0)),
        "Exceptions": int(exceptions_count),
        "DQ critical/high": int(q.get("Critical", 0) + q.get("High", 0)),
        "DQ medium": int(q.get("Medium", 0)),
        "Approved standardized cells/rows": int(std_count),
        "Mapping rows assessed": int(m.get("rows", 0)),
        "Mapping review required": int(m.get("review_required", 0)),
    }
