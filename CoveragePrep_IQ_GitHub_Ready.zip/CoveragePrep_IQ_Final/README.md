# CoveragePrep IQ — Hackfest 2026 Final Working Model
### Intelligent Client Data Preparation for Coverage Analysis

**Core principle:** **Agent recommends. Rules transform. Validation proves.**

CoveragePrep IQ is a working Python/Streamlit application that prepares inconsistent client shipment files for downstream Coverage Analysis while keeping a human in control of ambiguous or consequential decisions. It implements the challenge's four-step operating model:

**Ingest → Interpret / Flag → Transform → Validate**

It does **not** calculate Coverage itself, silently infer missing client data, or automatically overwrite client terminology.

## Final feature set

- CSV and XLSX ingestion with file/signature validation.
- Header-row and layout profiling.
- Four structural transformation patterns:
  - wide period columns;
  - long period + value;
  - matrix/crosstab;
  - sheet-per-period.
- Multi-sheet → one standardized output.
- Flexible field retention, deletion, role assignment, rename and ordering.
- Two output modes:
  - **Generic NIQ Standard** — Country, Region, Channel, City, State, Category, Brand, SKU, Fact + periods; missing standard roles are blank, never inferred.
  - **Guide-Specific / Flexible** — only the fields the coverage expert selects.
- Date standardization while preserving the source time grain.
- Negative-value choices: keep / absolute / zero.
- Duplicate choices: keep / exact-drop / explicit aggregation.
- Data Quality Dashboard with actionable recommendations.
- Human-approved Standardization Advisor for:
  - product descriptions;
  - pack-size formatting;
  - UOM formatting;
  - brand/category/channel/market surface variants.
- Optional Mapping Advisor using:
  1. previously approved historical mappings;
  2. exact identifiers;
  3. exact normalized descriptive matches;
  4. deterministic fuzzy ranking;
  5. optional NIQ-approved AI candidate tie-breaker.
- Strong **Integrity Gate**:
  - overall numeric reconciliation;
  - period-level reconciliation;
  - numeric-value multiset digest;
  - fact-cell count preservation;
  - **dimension + period + value association digest** to catch a value attached to the wrong product/channel/period even when totals still match.
- Audit trail and exception queue.
- XLSX output with evidence tabs; automatic CSV-package fallback beyond Excel limits.
- Optional NIQ-approved AI schema planner. The deterministic engine works without AI.
- Repeatable benchmark suite and evidence runner.

## Quick start on Windows

```bat
cd CoveragePrep_IQ_Final
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python benchmarks\generate_benchmarks.py
streamlit run app.py
```

Or run:

```bat
run_app_windows.bat
```

Then open the local Streamlit URL printed in the terminal.

## Run the evidence suite

```bat
.venv\Scripts\activate
python -m pip install -r requirements-dev.txt
python benchmark_runner.py
python evidence_runner.py
```

Current bundled evidence:

- **12/12 automated tests passing**.
- **8/8 evidence scenarios passing**.
- 5 synthetic structural patterns matching the challenge examples.
- A negative-control test proves the Integrity Gate rejects a deliberately mis-associated value even when the grand total remains unchanged.

## Generate a full demo output without Streamlit

```bat
python demo_run.py
```

This creates:

- `demo_outputs/CoveragePrep_IQ_Demo_Output.xlsx`
- `demo_outputs/CoveragePrep_IQ_Demo_Report.json`

The workbook includes:

- `Prepared_Data`
- `Validation_Summary`
- `Validation_Checks`
- `Exceptions`
- `Audit_Log`
- `Data_Quality`
- `Standardization`
- `Mapping_Advisor`
- `KPI_Summary`
- `Configuration`

## CLI path

A reusable transformation plan can be executed without the UI:

```bat
python cli.py ^
  --input data\benchmark_cases\case2_long_period.xlsx ^
  --plan demo_outputs\Transformation_Plan_Demo.json ^
  --generic-standard ^
  --output demo_outputs\CLI_Validated_Output.xlsx
```

## Optional NIQ-approved AI configuration

Use only the model endpoint/token distributed through the approved Hackfest/NIQ environment.

```bat
set NIQ_AI_ENDPOINT=...
set NIQ_AI_TOKEN=...
set NIQ_AI_MODEL=...
streamlit run app.py
```

AI is deliberately limited:

- schema planning uses structural metadata by default;
- candidate ranking can use client descriptive text only after explicit user approval;
- sales values are not sent to the AI mapping tie-breaker;
- AI cannot invent mappings outside candidates produced by deterministic/reference tools;
- AI cannot publish shipment values or calculate Coverage.

## Important confidentiality note

The bundled datasets and mapping references are synthetic. They demonstrate structure and workflow only. Replace them with approved challenge files in the NIQ environment, and never upload confidential client shipment data to unapproved external services.

## Final-project documentation

Read these in order:

1. `FINAL_IMPLEMENTATION_GUIDE.md` — complete step-by-step explanation, tools, logic and run instructions.
2. `REQUIREMENT_TRACEABILITY.md` — exact challenge/portal/evaluation alignment.
3. `ARCHITECTURE_AND_AGENT_FLOW.md` — technical architecture and agent/tool decisions.
4. `DEMO_AND_PITCH.md` — recommended 5-minute judge demo.
5. `SECURITY_RESPONSIBLE_AI.md` — security, privacy and AI controls.
6. `SUBMISSION_CHECKLIST.md` — final pre-submit gate.

## Production scaling path

The Streamlit model is optimized for hackathon demonstration and correctness. For the challenge's very large files, productionization should keep the same transformation contract but move execution to an approved worker service using lazy/streaming engines such as Polars or DuckDB for CSV/Parquet and read-only/streaming Excel handling. Raw client data should remain in approved temporary storage; the UI should exchange recipes, job IDs, evidence and signed output locations rather than holding multi-GB workbooks in browser/session memory.

## GitHub repository workflow

This project is intended to live in a **private** GitHub repository. See `GITHUB_REPOSITORY_GUIDE.md` for a beginner-friendly VS Code and Git workflow.

The repository includes a GitHub Actions workflow at `.github/workflows/ci.yml` that compiles the Python sources and runs the automated test suite on pushes and pull requests to `main`.

Never commit confidential client data or real AI/API credentials. Use `.env.example` only as a template for variable names.
