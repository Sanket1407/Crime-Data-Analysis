from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from coverageprep.design import apply_standard_placeholders
from coverageprep.exporter import choose_export
from coverageprep.models import DimensionSpec, MatrixHeaderSpec, SheetPlan
from coverageprep.profiler import build_dataframe, read_raw_grid
from coverageprep.transform import combine_prepared_results, revalidate_after_approved_text_changes, transform_raw_matrix, transform_table


def plan_from_dict(d: dict) -> SheetPlan:
    dims = [DimensionSpec(**x) for x in d.get("dimensions", [])]
    headers = [MatrixHeaderSpec(**x) for x in d.get("matrix_column_headers", [])]
    return SheetPlan(
        sheet_name=d.get("sheet_name", ""),
        layout=d["layout"],
        header_row=int(d.get("header_row", 0)),
        dimensions=dims,
        period_columns=d.get("period_columns", []),
        period_components=d.get("period_components", []),
        value_columns=d.get("value_columns", []),
        sheet_period_value=d.get("sheet_period_value"),
        matrix_data_start_row=d.get("matrix_data_start_row"),
        matrix_value_start_col=d.get("matrix_value_start_col"),
        matrix_row_dimensions={int(k): v for k, v in d.get("matrix_row_dimensions", {}).items()},
        matrix_column_headers=headers,
        matrix_period_column=d.get("matrix_period_column"),
        matrix_fact_label=d.get("matrix_fact_label"),
        date_format=d.get("date_format", "preserve"),
        negative_policy=d.get("negative_policy", "keep"),
        duplicate_action=d.get("duplicate_action", "keep"),
        duplicate_keys=d.get("duplicate_keys", []),
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="CoveragePrep IQ deterministic CLI")
    ap.add_argument("--input", required=True, help="CSV/XLSX shipment file")
    ap.add_argument("--plan", required=True, help="Transformation_Plan.json")
    ap.add_argument("--sheets", nargs="*", default=None, help="Optional sheets; defaults to plan sheet")
    ap.add_argument("--generic-standard", action="store_true", help="Add blank canonical output roles")
    ap.add_argument("--output", default="coverageprep_cli_output.xlsx")
    args = ap.parse_args()

    input_path = Path(args.input)
    plan_dict = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    plan = plan_from_dict(plan_dict)
    b = input_path.read_bytes()
    sheets = args.sheets or [plan.sheet_name]
    results = []
    for sheet in sheets:
        p = plan_from_dict(plan_dict)
        p.sheet_name = sheet
        if p.layout == "matrix":
            raw = read_raw_grid(b, input_path.name, None if sheet == "(CSV)" else sheet)
            results.append(transform_raw_matrix(raw, p))
        else:
            raw = read_raw_grid(b, input_path.name, None if sheet == "(CSV)" else sheet)
            df = build_dataframe(raw, p.header_row)
            if p.layout == "sheet_per_period":
                p.sheet_period_value = sheet
            results.append(transform_table(df, p))

    result = combine_prepared_results(results) if len(results) > 1 else results[0]
    roles = [d.role for d in plan.dimensions]
    result.prepared, audit = apply_standard_placeholders(result.prepared, roles + ["Fact"], args.generic_standard)
    result.audit_log.extend(audit)
    result = revalidate_after_approved_text_changes(result, [])

    if not result.validation.passed:
        print(json.dumps(result.validation.to_dict(), indent=2))
        print("Integrity Gate FAILED; no production output written.")
        return 2

    ext, _, payload = choose_export(result, plan)
    output = Path(args.output)
    if ext == "zip" and output.suffix.lower() != ".zip":
        output = output.with_suffix(".zip")
    output.write_bytes(payload)
    print(f"Integrity Gate PASS | rows={len(result.prepared):,} | numeric delta={result.validation.delta}")
    print(f"Wrote {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
