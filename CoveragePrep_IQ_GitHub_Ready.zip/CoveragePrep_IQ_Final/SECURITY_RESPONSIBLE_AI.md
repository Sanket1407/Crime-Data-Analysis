# CoveragePrep IQ — Security, Data Privacy & Responsible AI

## Threat model

Primary risks considered:

- malicious or malformed workbook uploads;
- macro execution / embedded external links;
- spreadsheet formula injection on export;
- client-data leakage to an unapproved AI service;
- leaked API credentials;
- AI hallucination changing shipment values;
- automatic deletion/aggregation of client records;
- incorrect transformation that preserves a grand total but moves a value to the wrong product/channel/period;
- overly large files exhausting the interactive process.

## Implemented prototype controls

### Input validation

`coverageprep/security.py`

- accept CSV/XLSX only;
- validate XLSX OOXML ZIP signature;
- reject VBA/macro parts;
- do not execute external links;
- apply a configured size limit;
- fail closed on invalid packages.

### Credentials

No AI token is stored in code. Configuration comes from:

- `NIQ_AI_ENDPOINT`
- `NIQ_AI_TOKEN`
- `NIQ_AI_MODEL`

### AI minimization

The model is optional.

Schema planning sends structural metadata by default rather than raw rows.

The optional Mapping Advisor AI tie-breaker:

- requires explicit user approval;
- sends only selected descriptive text and already-generated candidate labels;
- does not send sales values;
- cannot create a new candidate;
- cannot modify shipment output automatically.

### Human oversight

Explicit approval is required for:

- retained/deleted output fields;
- semantic field roles;
- negative-value policy;
- duplicate removal/aggregation;
- text standardization;
- use of mapping recommendations.

### Numerical and association integrity

Export is blocked unless validation passes:

- overall numeric total;
- period totals;
- numeric-value multiset;
- fact-cell count;
- dimension + period + value association digest;
- no unparseable selected fact cells.

This is specifically designed to catch "same total, wrong allocation" failures.

### Spreadsheet output safety

XLSX export disables conversion of source strings into formulas/URLs. Formula-like source text is surfaced for review rather than silently rewritten.

### Auditability

The evidence workbook contains:

- validation summary/checks;
- exception queue;
- audit log;
- data-quality report;
- approved standardization decisions;
- mapping recommendations;
- KPI summary;
- transformation configuration.

## Production controls required before enterprise deployment

- NIQ SSO / RBAC;
- least-privilege service identities;
- encrypted approved object storage;
- encrypted transport and worker queues;
- server-side malware/DLP scanning as required by NIQ policy;
- retention/deletion policy for temporary shipment data;
- centralized immutable audit logging;
- secret manager rather than environment variables on developer machines;
- API egress allow-listing;
- rate limits and quotas;
- large-file worker isolation;
- dependency/SAST scanning in CI;
- model/version allow-listing and prompt/output logging consistent with NIQ GenAI policy.

## Responsible AI design statement

CoveragePrep IQ uses AI only where probabilistic reasoning can add value and places deterministic controls around consequential outcomes. The LLM is never the source of truth for sales facts. Uncertainty is surfaced, candidate choices are bounded, and human approval is required before actions that can change business meaning.
