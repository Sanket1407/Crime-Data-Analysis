# CoveragePrep IQ — Final Submission Checklist

## Working solution

- [x] End-to-end deterministic engine implemented.
- [x] Streamlit human-in-the-loop app implemented.
- [x] Wide-period transformation implemented.
- [x] Long period/value transformation implemented.
- [x] Multi-sheet combination implemented.
- [x] Matrix/crosstab transformation implemented.
- [x] Sheet-per-period transformation implemented.
- [x] Generic standard + guide-specific modes implemented.
- [x] Negative-value policy implemented.
- [x] Duplicate policy implemented.
- [x] Data Quality Dashboard implemented.
- [x] Standardization Advisor implemented.
- [x] Mapping Advisor implemented as recommendation-only.
- [x] Integrity Gate implemented and export-blocking.
- [x] XLSX/CSV-limit routing implemented.
- [x] CLI and non-UI demo implemented.

## Evidence

- [x] 12 automated tests pass on bundled synthetic cases.
- [x] 8 evidence scenarios pass.
- [x] Negative-control tamper test proves the stronger association validator works.
- [x] Demo output workbook generated with evidence tabs.
- [ ] Re-run the same evidence harness on the official five challenge workbooks in the approved NIQ environment.
- [ ] Measure real analyst manual baseline and full workflow TAT.

## Security / Responsible AI

- [x] File/signature validation.
- [x] Macro-enabled workbook rejection.
- [x] No secrets embedded in source.
- [x] AI endpoint configured via environment variables.
- [x] Structural metadata only by default for AI schema planning.
- [x] Explicit user approval required before descriptive text is sent to optional AI candidate ranking.
- [x] AI cannot create sales values or new mapping candidates.
- [x] Human approval for consequential changes.
- [x] Audit log and exception queue.
- [x] Export blocked when integrity fails.
- [ ] Add NIQ SSO/RBAC if deployed beyond a local Hackfest prototype.

## Submission package

- [x] Source code.
- [x] README and full implementation guide.
- [x] Requirement traceability.
- [x] Architecture / agent-flow explanation.
- [x] Security / Responsible AI document.
- [x] Demo/pitch runbook.
- [x] Synthetic input/output evidence.
- [ ] Final PowerPoint in official Hackfest template.
- [ ] 5-minute Microsoft Teams pitch video using official background.
- [ ] Upload generated output file(s) requested by the challenge.

## Final claims discipline

- Do **not** claim Coverage Analysis is performed by this tool.
- Do **not** claim the bundled synthetic mapping reference is an NIQ production taxonomy.
- Do **not** claim a time-reduction percentage until real manual and assisted timings are measured.
- Treat the portal's `$125,000/yr` figure as the challenge's stated opportunity, not a saving already delivered by the prototype.
