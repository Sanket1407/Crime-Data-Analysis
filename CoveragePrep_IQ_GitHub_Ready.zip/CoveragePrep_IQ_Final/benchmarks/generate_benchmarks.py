from __future__ import annotations

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "benchmark_cases"
OUT.mkdir(parents=True, exist_ok=True)

# Case 1: period columns are already wide and out of chronological order.
wide = pd.DataFrame({
    "L1_3 - Bottler": ["B1", "B2"],
    "L1_2 - Division": ["North", "South"],
    "Brand": ["Alpha", "Beta"],
    "2025 Feb": [20, 25],
    "2025 Jan": [10, 15],
    "2025 Mar": [30, -5],
})
wide.to_excel(OUT / "case1_wide_periods.xlsx", index=False)

# Case 2: Year + Pxx + a fact field must be transposed to period columns.
long = pd.DataFrame({
    "Año": [2024, 2024, 2024, 2024],
    "Periodo": ["P01", "P02", "P01", "P02"],
    "Pais": ["Costa Rica"] * 4,
    "Channel": ["Food Service", "Food Service", "Modern Trade", "Modern Trade"],
    "Categoria": ["Food", "Food", "Food", "Food"],
    "Marca": ["Oreo", " OREO ", "Tang", "TANG"],
    "Product Description": ["Oreo Choco 6X330 ML", "Oreo  Choco  6 x 330ml", "Tang Orange 1LTR", "Tang Orange 1 L"],
    "Pack Size": ["6X330 ML", "6 x 330ml", "1LTR", "1 L"],
    "Unit": ["units", "UN", "litre", "L"],
    "Sum of Total": [100, 120, 80, 90],
})
long.to_excel(OUT / "case2_long_period.xlsx", index=False)

# Case 3: multiple yearly tabs with the same schema, combined to one output.
case3 = OUT / "case3_multisheet_years.xlsx"
with pd.ExcelWriter(case3, engine="xlsxwriter") as xw:
    for year, vals in [(2022, [11, 13]), (2023, [17, 19]), (2024, [23, 29])]:
        df = pd.DataFrame({
            "Channel": ["Direct", "Direct"],
            "Brand": ["MAGGI", "MAGGI"],
            "SKU": ["A", "B"],
            "DisplayYear": [year, year],
            "DisplayMonth": [1, 2],
            "RDBN_Quantity": vals,
        })
        df.to_excel(xw, sheet_name=str(year), index=False)

# Case 4: crosstab/matrix with row descriptors and column-header dimensions; tabs are facts.
case4 = OUT / "case4_matrix_multifact.xlsx"
with pd.ExcelWriter(case4, engine="xlsxwriter") as xw:
    for fact, mult in [("KG", 1), ("UN", 10), ("LT", 2)]:
        raw = pd.DataFrame([
            ["", "", "Customer", "CustA", "CustB"],
            ["", "", "Customer Group", "Group1", "Group2"],
            ["Calendar", "SKU", "", "", ""],
            ["01.2020", "P1", "", 10 * mult, 20 * mult],
            ["02.2020", "P1", "", 12 * mult, 22 * mult],
            ["01.2020", "P2", "", 5 * mult, 7 * mult],
            ["02.2020", "P2", "", 6 * mult, 8 * mult],
        ])
        raw.to_excel(xw, sheet_name=fact, index=False, header=False)

# Case 5: one period per sheet; same row schema, combined to one output.
case5 = OUT / "case5_sheet_per_period.xlsx"
with pd.ExcelWriter(case5, engine="xlsxwriter") as xw:
    for period, vals in [("2023-01", [40, 60]), ("2023-02", [45, 65]), ("2023-03", [50, 70])]:
        df = pd.DataFrame({
            "Distributor": ["D1", "D1"],
            "SKU": ["S1", "S2"],
            "VOL": vals,
        })
        df.to_excel(xw, sheet_name=period, index=False)

REF = ROOT / "data" / "demo_reference"
REF.mkdir(parents=True, exist_ok=True)
pd.DataFrame({
    "NIQ_Product_ID": ["NIQ-OREO-001", "NIQ-TANG-001"],
    "Brand": ["Oreo", "Tang"],
    "Category": ["Food", "Food"],
    "Standard_Product": ["OREO CHOCO", "TANG ORANGE"],
    "Standard_Pack": ["6 x 330 ML", "1 L"],
}).to_csv(REF / "niq_product_reference_demo.csv", index=False)

pd.DataFrame({
    "Client_Key": ["OREO", "TANG"],
    "NIQ_Product_ID": ["NIQ-OREO-001", "NIQ-TANG-001"],
    "Approved_By": ["Demo Coverage Expert", "Demo Coverage Expert"],
}).to_csv(REF / "historical_mappings_demo.csv", index=False)

print(f"Generated benchmark workbooks in {OUT}")
print(f"Generated synthetic mapping references in {REF}")
