from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    gen = subprocess.run([sys.executable, str(ROOT / "benchmarks" / "generate_benchmarks.py")], capture_output=True, text=True)
    if gen.returncode != 0:
        print(gen.stdout); print(gen.stderr, file=sys.stderr); return gen.returncode
    start = time.perf_counter()
    test = subprocess.run([sys.executable, "-m", "pytest", "-q", str(ROOT / "tests")], capture_output=True, text=True, cwd=ROOT)
    elapsed = time.perf_counter() - start
    output = test.stdout + "\n" + test.stderr
    passed = test.returncode == 0
    result = {
        "suite": "CoveragePrep IQ structural benchmark",
        "representative_cases": 5,
        "tests_passed": passed,
        "elapsed_seconds": round(elapsed, 3),
        "pytest_output": output.strip(),
        "evidence_note": "Synthetic cases reproduce the structural patterns visible in the supplied reference screenshots; they are not the confidential original example workbooks.",
    }
    (ROOT / "benchmark_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return test.returncode


if __name__ == "__main__":
    raise SystemExit(main())
