@echo off
setlocal
if not exist .venv\Scripts\python.exe python -m venv .venv
call .venv\Scripts\activate
python -m pip install -r requirements-dev.txt
python benchmark_runner.py
endlocal
