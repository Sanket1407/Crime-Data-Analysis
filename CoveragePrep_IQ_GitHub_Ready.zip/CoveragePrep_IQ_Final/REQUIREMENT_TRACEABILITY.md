# CoveragePrep IQ — Requirement Traceability

This matrix maps the final working model to the challenge deep-dive, the portal wording shown in the supplied screenshots, and the Hackfest 2026 evaluation framework.

## Challenge / portal outcomes

| Requirement | Final implementation | Evidence |
|---|---|---|
| Ingest Excel and CSV | `security.py`, `profiler.py` | App uploader + tests |
| Identify relevant fields/structure | profiler + optional approved AI schema advisor | visible profile table and agent plan |
| Detect missing/incomplete/inconsistent/ambiguous information | Data Quality Agent + exception queue | `quality.py`, exported `Data_Quality` sheet |
| Standardized output | Generic NIQ Standard + Guide-Specific mode | `design.py`, output preview |
| Country / Region / Channel / City / State / Category / Brand / SKU / Fact + periods | canonical ordering with blank placeholders only | `Prepared_Data` |
| User flexibility to select/delete/reorder | editable Output Field Designer | Streamlit UI |
| Date standardization | Preserve / YYYY-MM / MMM-YYYY / MM.YYYY / YYYYMM | profiler/transform tests |
| Preserve original time grain | no automatic weekly→monthly conversion | transformation design |
| Negative values | keep / absolute / zero | tests + audit |
| Duplicate handling | keep default / exact drop / explicit aggregation | tests + audit |
| Multi-tab to one output | multi-sheet combine engine | benchmark case 3/4/5 |
| Matrix/crosstab challenge | dedicated matrix transformer | benchmark case 4 |
| Standardize product description, pack size, UOM, brand/category/channel/market | advisory deterministic standardization + explicit approval | `standardize.py`, `Standardization` sheet |
| Recommend mappings to NIQ product structures | optional Mapping Advisor against an approved reference | `mapping.py`, `Mapping_Advisor` sheet |
| Use identifiers/business rules/history/AI matching | history → exact ID → exact normalized text → deterministic fuzzy → optional approved AI tie-break | mapping module / app |
| No silent assumptions/overwrites | all ambiguous/consequential decisions require user action | UI + audit trail |
| Coverage Analysis itself out of scope | no coverage % or NIQ sales comparison calculated | project scope statement |
| Numerical correctness | total + period + multiset + association digest + fact count | Integrity Gate |
| Excel/CSV size fallback | Excel limits checked; ZIP/CSV evidence package fallback | exporter |
| Scalable/global path | modular engine + production worker path documented | README / implementation guide |
| Reduce manual effort/TAT | automation pipeline + measured engine runtime; manual baseline must be measured, not invented | KPI panel + evidence runner |

## Hackfest evaluation framework

| Evaluation dimension | Weight | CoveragePrep IQ evidence |
|---|---:|---|
| Technical Implementation & Scalability | 25% | working end-to-end transformation engine, four structural layouts, failure handling, CLI, UI, export, production scaling path |
| Business Value | 25% | targets Customer Support shipment preparation; removes repeated manual reshape/validation work; KPIs exposed; portal cost opportunity treated as challenge context, not claimed realized saving |
| Agentic Quality | 20% | visible orchestrator decomposes tasks and chooses tools; AI is recommendation-only; human gates for consequential decisions; deterministic tools complete the job |
| Outcome Accuracy & Evidence | 10% | 12 tests, 8 evidence cases, runtime metrics, 0-delta reconciliation and deliberate tamper negative control |
| Responsible AI & Security | 10% | approved endpoint only, no hard-coded credentials, structural metadata by default, explicit approval for candidate-ranking text, file validation, audit, integrity export gate |
| Presentation & Communication | 10% | demo runbook, architecture flow, measurable evidence, limitations and next steps documented |

## First-level readiness/security gate

- End-to-end working backend: **yes**.
- UI implementation: **yes, Streamlit source included**.
- Repeatable non-UI demo: **yes, `demo_run.py`**.
- CLI: **yes, `cli.py`**.
- Security/input validation: **yes**.
- Data privacy / external sharing guardrail: **yes**.
- Human oversight: **yes**.
- Audit trail: **yes**.
- Test/evidence suite: **yes**.

## Remaining pre-submission actions that require NIQ environment access

1. Install/run Streamlit using the NIQ-approved package source.
2. Connect the actual approved Luna/AI endpoint if the team wants to demo AI live.
3. Run the evidence harness against the official five challenge workbooks.
4. Measure a real manual baseline and end-to-end analyst interaction time before claiming TAT reduction.
5. If an actual NIQ product/reference hierarchy is available for the challenge, connect it to Mapping Advisor instead of the bundled synthetic reference.
6. Complete NIQ SSO/RBAC if deploying beyond the local Hackfest demo.
