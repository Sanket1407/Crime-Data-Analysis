"""CoveragePrep Simple Step 7G — final local terminal application.

Run with:
    python main.py

The application stays local, preserves the source file, supports multi-sheet
selection, reusable configs, structure-change checks, one FACT/value series per
processed table, validation, and local Excel/CSV export.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

from coverageprep.reader import ShipmentReadError, UnsupportedFileTypeError, inventory_file
from coverageprep.scanner import manual_header_scan, scan_sheet_headers, scan_workbook_headers
from coverageprep.periods import parse_period, scan_sheet_periods
from coverageprep.mapping import detect_single_fact, suggest_field_roles
from coverageprep.transform import TransformationBlocked, load_table
from coverageprep.workflow import (
    SheetRunSpec,
    WorkflowBlocked,
    process_multiple_sheets,
    suggest_fact_label,
)
from coverageprep.export_multi import export_multisheet_run
from coverageprep.config import compare_structure, load_config, save_config, specs_from_config
from coverageprep.scanreport import export_scan_report


BANNER = """
========================================================
 CoveragePrep Simple — Step 7G
 Local Client Shipment Preparation
========================================================
""".strip()

ROLE_OPTIONS = ["COUNTRY", "REGION", "CHANNEL", "CITY", "STATE", "CATEGORY", "BRAND", "SKU", "EXTRA"]


def _input_dir() -> Path:
    p = Path(__file__).parent / "input"
    p.mkdir(exist_ok=True)
    return p


def _output_dir() -> Path:
    p = Path(__file__).parent / "output"
    p.mkdir(exist_ok=True)
    return p


def _config_dir() -> Path:
    p = Path(__file__).parent / "config"
    p.mkdir(exist_ok=True)
    return p


def choose_input_file() -> Path:
    candidates = sorted(
        p for p in _input_dir().iterdir()
        if p.is_file() and p.suffix.lower() in {".xlsx", ".xlsm", ".csv"}
    )
    print("\nShipment files available in input\\:")
    for i, p in enumerate(candidates, 1):
        print(f"  {i}. {p.name}")
    if not candidates:
        print("  (none)")
    print("  0. Enter another local file path")
    while True:
        choice = input("\nSelect file: ").strip()
        if choice == "0":
            return Path(input("Enter shipment file path: ").strip().strip('"'))
        if choice.isdigit() and 1 <= int(choice) <= len(candidates):
            return candidates[int(choice) - 1]
        print("Invalid selection. Try again.")


def _parse_selection(text: str, count: int) -> list[int]:
    selected: list[int] = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        if not part.isdigit() or not (1 <= int(part) <= count):
            raise ValueError(f"Invalid selection: {part}")
        value = int(part)
        if value not in selected:
            selected.append(value)
    if not selected:
        raise ValueError("Select at least one item")
    return selected


def choose_sheets(path: Path) -> list[str]:
    inv = inventory_file(path, preview_rows=0)
    print("\n========================================================")
    print(" SHEET SELECTION")
    print("========================================================")
    for i, sheet in enumerate(inv.sheets, 1):
        print(f"{i:>2}. {sheet.name:<32} {sheet.rows:>10,} rows x {sheet.columns:>6,} cols")
    if len(inv.sheets) == 1:
        return [inv.sheets[0].name]
    while True:
        raw = input("\nSelect sheet number(s), e.g. 2,3,4: ").strip()
        try:
            idx = _parse_selection(raw, len(inv.sheets))
            return [inv.sheets[i - 1].name for i in idx]
        except ValueError as exc:
            print(exc)


def choose_period_order() -> str:
    print("\nPeriod order for Prepared_Data:")
    print("  1. Oldest -> newest [recommended]")
    print("  2. Newest -> oldest")
    print("  3. Keep source order")
    choice = input("Select [1]: ").strip()
    return {"2": "descending", "3": "source"}.get(choice, "ascending")


def choose_negative_policy() -> str:
    print("\nNegative fact-value handling:")
    print("  1. Keep original [recommended]")
    print("  2. Convert negative values to positive")
    print("  3. Convert negative values to zero")
    choice = input("Select [1]: ").strip()
    return {"2": "absolute", "3": "zero"}.get(choice, "keep")


def choose_duplicate_policy() -> str:
    print("\nExact duplicate source rows:")
    print("  1. Keep all [recommended]")
    print("  2. Exclude exact duplicates from Prepared_Data")
    choice = input("Select [1]: ").strip()
    return "drop_exact" if choice == "2" else "keep"


def configure_header(path: Path, sheet_name: str):
    scan = scan_sheet_headers(path, sheet_name)
    print("\n--------------------------------------------------------")
    print(f"HEADER — {sheet_name}")
    print("--------------------------------------------------------")
    if scan.recommended:
        c = scan.recommended
        print(f"Recommended rows: {c.start_row}-{c.end_row} | confidence={c.confidence} | score={c.score}")
        preview = " | ".join(c.flattened_headers[:12])
        if len(c.flattened_headers) > 12:
            preview += " | ..."
        print(f"Flattened preview: {preview}")
        choice = input("Use this header range? [Y/n]: ").strip().lower()
        if choice in {"", "y", "yes"}:
            return scan
    else:
        print("No reliable automatic header recommendation.")

    while True:
        try:
            start = int(input("Header start row: ").strip())
            end = int(input("Header end row: ").strip())
            manual = manual_header_scan(path, sheet_name, start, end)
            print("Manual header preview:")
            print("  " + " | ".join(manual.recommended.flattened_headers[:12]))
            return manual
        except (ValueError, ShipmentReadError) as exc:
            print(f"Invalid header range: {exc}")


def _print_period_scan(period_scan) -> None:
    print("Period findings:")
    if not period_scan.findings:
        print("  No safe period structure detected.")
    for f in period_scan.findings:
        source = ", ".join(f.source_columns) if f.source_columns else "-"
        print(f"  {f.location:<18} {f.frequency:<12} {f.status:<8} source={source}")
        for mapping in f.mappings[:8]:
            pattern = f" | pattern={mapping.pattern}" if getattr(mapping, "pattern", None) else ""
            print(f"      {mapping.original} -> {mapping.standard or '(unresolved)'} [{mapping.status}]{pattern}")
        if len(f.mappings) > 8:
            print(f"      ... {len(f.mappings) - 8} more")
    if period_scan.coverage:
        c = period_scan.coverage
        print("Period coverage:")
        print(f"  Frequency: {c.frequency} ({c.frequency_confidence}% confidence)")
        print(f"  Detected: {c.detected_periods}")
        print(f"  First / last: {c.earliest} / {c.latest}")
        print(f"  Source order: {c.source_order}")
        if c.pattern_name:
            print(f"  Pattern: {c.pattern_name}")
        if c.missing_periods:
            print(f"  Missing periods: {', '.join(c.missing_periods[:12])}" + (" ..." if len(c.missing_periods) > 12 else ""))
        print(f"  Recommendation: {c.recommended_action}")
    if period_scan.collisions:
        print("BLOCKING PERIOD COLLISIONS:")
        for c in period_scan.collisions:
            print(f"  {c.standard_period}: {', '.join(c.sources)}")


def configure_roles(path: Path, sheet_name: str, header_scan, period_scan) -> dict[str, str]:
    table = load_table(path, sheet_name, header_scan=header_scan)
    period_sources: set[str] = set()
    for finding in period_scan.findings:
        if finding.status == "OK":
            period_sources.update(finding.source_columns)
    headers = []
    for c in table.columns:
        if parse_period(c.flattened_header).status == "OK":
            continue
        if c.source_header in period_sources or c.flattened_header in period_sources:
            continue
        headers.append(c.source_header)
    suggestions = suggest_field_roles(headers)
    roles = {s.source_header: s.role for s in suggestions}
    print("\nLogical role recommendations (source headers stay unchanged):")
    for i, s in enumerate(suggestions, 1):
        print(f"  {i:>2}. {s.source_header:<35} -> {s.role:<10} [{s.confidence}]")
    choice = input("Edit any role assignments? [y/N]: ").strip().lower()
    if choice not in {"y", "yes"}:
        return roles

    print("Allowed roles: " + ", ".join(ROLE_OPTIONS))
    print("Enter changes one at a time. Press Enter on field number when finished.")
    while True:
        raw = input("Field number to change: ").strip()
        if not raw:
            break
        if not raw.isdigit() or not (1 <= int(raw) <= len(suggestions)):
            print("Invalid field number.")
            continue
        item = suggestions[int(raw) - 1]
        role = input(f"Role for '{item.source_header}': ").strip().upper()
        if role not in ROLE_OPTIONS:
            print("Invalid role.")
            continue
        roles[item.source_header] = role
    return roles


def _choose_fact_source_for_row_layout(path: Path, sheet_name: str, header_scan, period_scan, roles: dict[str, str]) -> str | None:
    priority = {"COLUMN_HEADER": 1, "COMBINED_COLUMNS": 2, "ROW_COLUMN": 3, "SHEET_NAME": 4}
    safe = [f for f in period_scan.findings if f.status == "OK"]
    if not safe:
        return None
    safe.sort(key=lambda f: priority.get(f.location, 99))
    finding = safe[0]
    if finding.location == "COLUMN_HEADER":
        return None
    table = load_table(path, sheet_name, header_scan=header_scan)
    rename = {c.internal_name: c.source_header for c in table.columns}
    frame = table.frame.rename(columns=rename)
    detection = detect_single_fact(
        frame,
        layout="SHEET_PERIOD" if finding.location == "SHEET_NAME" else "ROW_PERIODS",
        period_source_columns=list(finding.source_columns),
        assigned_roles=roles,
        sheet_name=sheet_name,
    )
    if detection.source_column and detection.status in {"OK", "REVIEW"}:
        print(f"Detected single fact/value column: {detection.source_column} [{detection.status}]")
        if input("Use this value column? [Y/n]: ").strip().lower() in {"", "y", "yes"}:
            return detection.source_column
    candidates = [c for c in detection.candidates if not c.identifier_hint]
    if candidates:
        print("Possible numeric value columns:")
        for i, c in enumerate(candidates, 1):
            print(f"  {i}. {c.source_header} ({c.numeric_ratio:.0%} numeric) — {c.reason}")
        raw = input("Select the ONE shipment value column, or press Enter to let the engine block safely: ").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(candidates):
            return candidates[int(raw) - 1].source_header
    return None


def configure_sheet(path: Path, sheet_name: str, period_order: str, negative_policy: str, duplicate_policy: str) -> SheetRunSpec:
    header_scan = configure_header(path, sheet_name)
    period_scan = scan_sheet_periods(path, sheet_name, header_scan=header_scan)
    print("\n--------------------------------------------------------")
    print(f"PERIODS — {sheet_name}")
    print("--------------------------------------------------------")
    _print_period_scan(period_scan)
    if period_scan.collisions:
        raise WorkflowBlocked(
            f"'{sheet_name}' has period collisions. Resolve the source/period meaning before preparation."
        )
    accept_period_codes = False
    if not any(f.status == "OK" for f in period_scan.findings):
        review_codes = [
            f for f in period_scan.findings
            if f.status == "REVIEW"
            and f.frequency == "Period code"
            and f.mappings
            and all(m.standard for m in f.mappings)
        ]
        if review_codes:
            print("Period codes such as P01/P02 were detected with enough year context to recommend month labels.")
            print("This mapping is client-specific and will only be used if you explicitly confirm it.")
            accept_period_codes = input("Confirm P01=Jan, P02=Feb, etc. for this sheet? [y/N]: ").strip().lower() in {"y", "yes"}
        if not accept_period_codes:
            raise WorkflowBlocked(
                f"'{sheet_name}' has no safe confirmed period structure. Ambiguous periods are never guessed."
            )

    roles = configure_roles(path, sheet_name, header_scan, period_scan)
    fact_source_header = _choose_fact_source_for_row_layout(path, sheet_name, header_scan, period_scan, roles)
    suggested = suggest_fact_label(sheet_name)
    if suggested:
        raw = input(f"FACT label for '{sheet_name}' [{suggested}]: ").strip()
        fact_label = raw or suggested
    else:
        raw = input(
            f"FACT label for '{sheet_name}' (leave blank only if a row-based source value column clearly names the fact): "
        ).strip()
        fact_label = raw or None

    c = header_scan.recommended
    return SheetRunSpec(
        sheet_name=sheet_name,
        header_start_row=c.start_row if c else None,
        header_end_row=c.end_row if c else None,
        fact_label=fact_label,
        fact_source_header=fact_source_header,
        field_roles=roles,
        period_order=period_order,
        negative_policy=negative_policy,
        duplicate_policy=duplicate_policy,
        accept_period_codes=accept_period_codes,
    )


def print_run_summary(run) -> None:
    print("\n========================================================")
    print(" TRANSFORMATION + VALIDATION SUMMARY")
    print("========================================================")
    for result in run.results:
        p = result.preview
        r = result.report
        print(f"\n{p.sheet_name}")
        print(f"  Layout: {p.layout}")
        print(f"  FACT: {p.fact_label}")
        print(f"  Prepared rows: {len(p.prepared_data):,}")
        print(f"  Source/expected fact cells: {r.source_fact_cells:,}")
        print(f"  Prepared fact cells: {r.output_fact_cells:,}")
        print(f"  Validation: {r.status}")
        if p.warnings:
            for w in p.warnings:
                print(f"  WARNING: {w}")
    print("\nCombined Prepared_Data")
    print(f"  Rows: {len(run.combined_data):,}")
    print(f"  Columns: {len(run.combined_data.columns):,}")
    print(f"  FINAL STATUS: {run.status}")
    print("\nFirst rows:")
    print(run.combined_data.head(8).to_string(index=False))


def scan_only() -> None:
    path = choose_input_file()
    inv = inventory_file(path, preview_rows=3)
    scans = scan_workbook_headers(path)
    print("\n========================================================")
    print(" FILE SCAN SUMMARY")
    print("========================================================")
    print(f"File: {inv.filename}")
    print(f"Type: {inv.extension}")
    print(f"Size: {inv.size_bytes:,} bytes")
    print(f"Sheets/tables: {inv.sheet_count}")
    for sheet, hscan in zip(inv.sheets, scans.sheets):
        print(f"\n[{sheet.name}] {sheet.rows:,} rows x {sheet.columns:,} cols | state={sheet.state}")
        if hscan.recommended:
            c = hscan.recommended
            print(f"  Recommended header: rows {c.start_row}-{c.end_row} ({c.confidence})")
            try:
                pscan = scan_sheet_periods(path, sheet.name, header_scan=hscan)
                safe = [f for f in pscan.findings if f.status == "OK"]
                if safe:
                    f = safe[0]
                    print(f"  Period structure: {f.location} / {f.frequency}")
                elif pscan.findings:
                    print("  Period structure: review required")
                else:
                    print("  Period structure: not detected")
                if pscan.coverage:
                    cov = pscan.coverage
                    print(f"  Period coverage: {cov.detected_periods} | {cov.earliest} -> {cov.latest}")
                    print(f"  Source order: {cov.source_order}")
                    if cov.pattern_name:
                        print(f"  Pattern: {cov.pattern_name}")
                    if cov.missing_periods:
                        print(f"  Missing periods: {len(cov.missing_periods)}")
                if pscan.collisions:
                    print(f"  BLOCKER: {len(pscan.collisions)} period collision(s)")
            except Exception as exc:
                print(f"  Period scan warning: {exc}")
        else:
            print("  Header: review required")
    print("\nScan only complete. No shipment data was transformed.")
    if input("Create local Excel scan report? [y/N]: ").strip().lower() in {"y", "yes"}:
        report_path = export_scan_report(path, output_dir=_output_dir())
        print(f"Scan report: {report_path}")


def prepare_new() -> None:
    path = choose_input_file()
    sheets = choose_sheets(path)
    period_order = choose_period_order()
    negative_policy = choose_negative_policy()
    duplicate_policy = choose_duplicate_policy()

    specs: list[SheetRunSpec] = []
    for sheet in sheets:
        specs.append(configure_sheet(path, sheet, period_order, negative_policy, duplicate_policy))

    print("\n========================================================")
    print(" TRANSFORMATION PREVIEW SETTINGS")
    print("========================================================")
    print(f"File: {path}")
    print(f"Sheets: {', '.join(s.sheet_name for s in specs)}")
    print(f"Period order: {period_order}")
    print(f"Negative policy: {negative_policy}")
    print(f"Exact duplicate policy: {duplicate_policy}")
    print("Automatic aggregation: DISABLED")
    print("Source headers renamed: NO")
    print("Missing values inferred: NO")
    if input("\nProceed with transformation? [Y/n]: ").strip().lower() not in {"", "y", "yes"}:
        print("Cancelled. Nothing was written.")
        return

    run = process_multiple_sheets(path, specs, period_order=period_order)
    print_run_summary(run)

    if input("\nCreate local output workbook now? [Y/n]: ").strip().lower() not in {"", "y", "yes"}:
        print("No output was written.")
        return
    exported = export_multisheet_run(path, run, output_dir=_output_dir())
    print("\n========================================================")
    print(" LOCAL EXPORT COMPLETE")
    print("========================================================")
    print(f"Status: {exported.status}")
    print(f"Workbook: {exported.workbook_path}")
    if exported.prepared_csv_path:
        print(f"Prepared data CSV: {exported.prepared_csv_path}")
    print(f"Source evidence mode: {exported.source_mode}")
    if exported.status != "PASS":
        print("IMPORTANT: output is REVIEW_REQUIRED and is not a validated prepared shipment.")

    if run.status == "PASS" and input("Save reusable configuration? [Y/n]: ").strip().lower() in {"", "y", "yes"}:
        default = _config_dir() / f"{path.stem}_Config.json"
        raw = input(f"Config path [{default}]: ").strip().strip('"')
        target = Path(raw) if raw else default
        saved = save_config(run, target)
        print(f"Configuration saved: {saved}")


def choose_config_file() -> Path:
    candidates = sorted(p for p in _config_dir().glob("*.json") if p.is_file())
    print("\nSaved configurations:")
    for i, p in enumerate(candidates, 1):
        print(f"  {i}. {p.name}")
    if not candidates:
        print("  (none)")
    print("  0. Enter another config path")
    while True:
        choice = input("Select config: ").strip()
        if choice == "0":
            return Path(input("Config path: ").strip().strip('"'))
        if choice.isdigit() and 1 <= int(choice) <= len(candidates):
            return candidates[int(choice) - 1]
        print("Invalid selection.")


def reuse_config() -> None:
    path = choose_input_file()
    config_path = choose_config_file()
    config = load_config(config_path)
    print("\nChecking current shipment against saved structure...")
    safe, messages = compare_structure(path, config)
    for msg in messages:
        print(f"  {msg}")
    if not safe:
        print("\nSTRUCTURE CHANGE DETECTED. Saved configuration will NOT be applied automatically.")
        print("Use 'Prepare a shipment file' to review the new structure.")
        return
    if input("\nStructure compatible. Reuse saved configuration? [Y/n]: ").strip().lower() not in {"", "y", "yes"}:
        print("Cancelled.")
        return
    specs = specs_from_config(config)
    period_order = config.get("period_order", "ascending")
    run = process_multiple_sheets(path, specs, period_order=period_order)
    print_run_summary(run)
    exported = export_multisheet_run(path, run, output_dir=_output_dir())
    print(f"\nOutput: {exported.workbook_path}")
    if exported.prepared_csv_path:
        print(f"Prepared data CSV: {exported.prepared_csv_path}")


def main() -> None:
    print(BANNER)
    print("\nLocal-first: the original shipment file is never overwritten.")
    while True:
        print("\nMain menu")
        print("  1. Scan a shipment file")
        print("  2. Prepare a shipment file")
        print("  3. Reuse a saved configuration")
        print("  4. Exit")
        choice = input("Select option: ").strip()
        try:
            if choice == "1":
                scan_only()
            elif choice == "2":
                prepare_new()
            elif choice == "3":
                reuse_config()
            elif choice == "4":
                print("Goodbye.")
                return
            else:
                print("Invalid option.")
        except (
            FileNotFoundError,
            UnsupportedFileTypeError,
            ShipmentReadError,
            TransformationBlocked,
            WorkflowBlocked,
            ValueError,
        ) as exc:
            print(f"\nBLOCKED/ERROR: {exc}")


if __name__ == "__main__":
    main()
