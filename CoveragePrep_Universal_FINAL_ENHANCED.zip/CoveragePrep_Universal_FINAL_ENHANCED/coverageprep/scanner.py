"""Read-only structural scanner for CoveragePrep Simple.

Step 7B scope:
- inspect the top rows of every sheet/table;
- recommend likely header row(s), including multi-row headers;
- provide flattened header previews only for inspection;
- never rename, transform, or write shipment data.

Period interpretation is intentionally NOT implemented here. 7B may recognize
simple year/date-like header tokens only as structural clues for header scoring.
Period standardization belongs to Step 7C.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import date, datetime
from pathlib import Path
from typing import Any
import math
import re

from openpyxl import load_workbook

from .reader import (
    ShipmentReadError,
    UnsupportedFileTypeError,
    validate_source_path,
)


@dataclass(frozen=True)
class HeaderCandidate:
    """One possible header range, using 1-based source row numbers."""

    start_row: int
    end_row: int
    score: float
    confidence: str
    flattened_headers: list[str]
    reasons: list[str]

    @property
    def depth(self) -> int:
        return self.end_row - self.start_row + 1

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["depth"] = self.depth
        return data


@dataclass(frozen=True)
class SheetHeaderScan:
    """Header recommendations for one source sheet/table."""

    sheet_name: str
    source_rows: int
    source_columns: int
    inspected_rows: int
    inspected_columns: int
    candidates: list[HeaderCandidate]
    warnings: list[str]

    @property
    def recommended(self) -> HeaderCandidate | None:
        return self.candidates[0] if self.candidates else None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["recommended"] = self.recommended.to_dict() if self.recommended else None
        return data


@dataclass(frozen=True)
class WorkbookHeaderScan:
    filename: str
    sheets: list[SheetHeaderScan]

    def to_dict(self) -> dict[str, Any]:
        return {
            "filename": self.filename,
            "sheets": [sheet.to_dict() for sheet in self.sheets],
        }


@dataclass(frozen=True)
class _RowProfile:
    row_number: int
    nonempty: int
    density: float
    text_ratio: float
    numeric_ratio: float
    year_like_ratio: float
    date_ratio: float
    unique_ratio: float
    long_text_ratio: float
    semantic_header_ratio: float

    @property
    def header_token_ratio(self) -> float:
        # Text and date/year labels are common in headers. A year-like numeric value
        # is counted here so a row such as 2026 | 2025 | 2024 is not dismissed as data.
        return min(1.0, self.text_ratio + self.year_like_ratio + self.date_ratio)


_YEAR_RE = re.compile(r"^(?:19|20)\d{2}$")
_NUMERIC_TEXT_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")
_SEMANTIC_HEADER_RE = re.compile(
    r"\b(?:country|region|channel|branch|division|category|brand|sku|upc|ean|gtin|material|item|"
    r"product|description|desc|code|id|key|year|month|period|date|week|quarter|value|sales|"
    r"quantity|qty|volume|units?|tons?|eaches?|litres?|liters?|market|state|city|town|trade)\b",
    re.IGNORECASE,
)


def _is_blank(value: Any) -> bool:
    return value is None or (isinstance(value, str) and value.strip() == "")


def _is_year_like(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return 1900 <= value <= 2100
    if isinstance(value, float) and value.is_integer():
        return 1900 <= int(value) <= 2100
    if isinstance(value, str):
        return bool(_YEAR_RE.fullmatch(value.strip()))
    return False


def _is_number(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return not (isinstance(value, float) and math.isnan(value))
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        return bool(text and _NUMERIC_TEXT_RE.fullmatch(text))
    return False


def _display_token(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat(sep=" ", timespec="seconds")
    if isinstance(value, date):
        return value.isoformat()
    text = str(value).strip()
    return text


def _row_profile(row_number: int, row: list[Any], width: int) -> _RowProfile:
    width = max(width, 1)
    values = [value for value in row[:width] if not _is_blank(value)]
    nonempty = len(values)
    if nonempty == 0:
        return _RowProfile(row_number, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

    text_count = sum(isinstance(v, str) and not _is_year_like(v) and not _is_number(v) for v in values)
    numeric_count = sum(_is_number(v) for v in values)
    year_count = sum(_is_year_like(v) for v in values)
    date_count = sum(isinstance(v, (date, datetime)) for v in values)
    long_text_count = sum(
        isinstance(v, str) and len(v.strip()) >= 50 for v in values
    )
    semantic_count = sum(
        isinstance(v, str) and bool(_SEMANTIC_HEADER_RE.search(v)) for v in values
    )

    normalized = [_display_token(v).casefold() for v in values]
    unique_ratio = len(set(normalized)) / nonempty if nonempty else 0.0

    return _RowProfile(
        row_number=row_number,
        nonempty=nonempty,
        density=nonempty / width,
        text_ratio=text_count / nonempty,
        numeric_ratio=numeric_count / nonempty,
        year_like_ratio=year_count / nonempty,
        date_ratio=date_count / nonempty,
        unique_ratio=unique_ratio,
        long_text_ratio=long_text_count / nonempty,
        semantic_header_ratio=semantic_count / nonempty,
    )


def _effective_width(rows: list[list[Any]], source_columns: int) -> int:
    """Use the observed top-row width, bounded by the source worksheet width."""
    observed = 0
    for row in rows:
        for index, value in enumerate(row, start=1):
            if not _is_blank(value):
                observed = max(observed, index)
    if observed == 0:
        return max(1, min(source_columns, 1))
    return max(1, min(source_columns or observed, observed))


def _following_profile(profiles: list[_RowProfile], index: int, lookahead: int = 3) -> tuple[float, float]:
    following = [p for p in profiles[index + 1 : index + 1 + lookahead] if p.nonempty > 0]
    if not following:
        return 0.0, 0.0
    avg_density = sum(p.density for p in following) / len(following)
    avg_numeric = sum(p.numeric_ratio for p in following) / len(following)
    return avg_density, avg_numeric


def _following_type_similarity(profiles: list[_RowProfile], index: int, lookahead: int = 3) -> float:
    p = profiles[index]
    following = [x for x in profiles[index + 1 : index + 1 + lookahead] if x.nonempty > 0]
    if not following:
        return 0.0
    sims = []
    for x in following:
        distance = abs(p.density - x.density) + abs(p.numeric_ratio - x.numeric_ratio) + abs(p.text_ratio - x.text_ratio)
        sims.append(max(0.0, 1.0 - distance / 3.0))
    return sum(sims) / len(sims)


def _single_row_score(profiles: list[_RowProfile], index: int) -> tuple[float, list[str]]:
    p = profiles[index]
    if p.nonempty == 0:
        return 0.0, ["row is blank"]

    following_density, following_numeric = _following_profile(profiles, index)
    reasons: list[str] = []

    # Header rows commonly have broad coverage, distinct labels, and text/date/year
    # tokens, with populated data beneath them.
    score = (
        32.0 * p.density
        + 25.0 * p.header_token_ratio
        + 14.0 * p.unique_ratio
        + 14.0 * min(1.0, following_density / max(p.density, 0.05))
        + 15.0 * max(0.0, following_numeric - (p.numeric_ratio - p.year_like_ratio))
        + 24.0 * p.semantic_header_ratio
    )

    if p.density >= 0.5:
        reasons.append("row has broad column coverage")
    if p.header_token_ratio >= 0.6:
        reasons.append("row is mostly label/date/year-like")
    if p.unique_ratio >= 0.8:
        reasons.append("header values are mostly distinct")
    if following_density > 0:
        reasons.append("populated rows follow this row")
    if following_numeric > p.numeric_ratio:
        reasons.append("rows below are more numeric/data-like")
    if p.semantic_header_ratio >= 0.30:
        reasons.append("row contains common field/header vocabulary")

    # Single-cell title rows should not usually win against a real table header.
    if p.nonempty == 1:
        score *= 0.38
        reasons.append("penalty: only one populated cell")
    elif p.nonempty == 2 and p.density < 0.25:
        score *= 0.75

    if p.long_text_ratio >= 0.75 and p.nonempty <= 2:
        score *= 0.55
        reasons.append("penalty: looks like a title/note")

    # A row made of arbitrary numbers is more likely to be data. Year-like numbers
    # are exempt because they can legitimately be period headers.
    ordinary_numeric_ratio = max(0.0, p.numeric_ratio - p.year_like_ratio)
    if ordinary_numeric_ratio >= 0.8 and p.header_token_ratio < 0.25:
        score *= 0.45
        reasons.append("penalty: row looks numeric/data-like")

    # Dense transactional rows often look like plausible headers because they are
    # mostly text and unique. Penalize rows whose type profile looks like the next
    # few rows and which lack semantic field-name vocabulary. This directly avoids
    # choosing rows such as "Direct | CP | East Branch | Foods | 12508373 | ...".
    similarity = _following_type_similarity(profiles, index)
    if p.density >= 0.60 and p.semantic_header_ratio < 0.18 and similarity >= 0.82:
        score *= 0.42
        reasons.append("penalty: row resembles surrounding transactional data")
    elif p.semantic_header_ratio < 0.10 and p.density >= 0.50 and similarity >= 0.75:
        score *= 0.65
        reasons.append("penalty: weak field-name evidence versus nearby rows")

    if following_density == 0.0:
        score *= 0.60
        reasons.append("penalty: no populated rows immediately below")

    return max(0.0, min(100.0, score)), reasons


def _support_score(profile: _RowProfile, leaf: _RowProfile) -> tuple[float, str | None]:
    """Score a row immediately above a leaf header as a possible group header."""
    if profile.nonempty == 0:
        return -1.0, "blank row breaks a multi-row header"

    ordinary_numeric = max(0.0, profile.numeric_ratio - profile.year_like_ratio)
    if ordinary_numeric >= 0.8 and profile.header_token_ratio < 0.25:
        return -0.7, "row above looks like data, not a header level"

    support = 0.0
    if profile.header_token_ratio >= 0.5:
        support += 0.45
    if profile.unique_ratio >= 0.5:
        support += 0.15
    if profile.density <= leaf.density + 0.15:
        support += 0.15
    if 2 <= profile.nonempty <= max(2, leaf.nonempty):
        support += 0.20
    elif profile.nonempty == 1:
        # A lone populated cell above a dense header is usually a title/note.
        # Fully merged one-cell group headers are possible, but 7B deliberately
        # prefers a conservative recommendation and lets the user expand the
        # header range manually later.
        return -0.25, "single-cell row treated as title/note, not automatic header level"

    # Dense multi-row headers are legitimate when an upper row clearly carries
    # year/date grouping (for example 2025 | 2025 | 2026 | 2026). Otherwise two
    # equally dense adjacent rows are more likely to be header + first data row.
    if abs(profile.density - leaf.density) < 0.10 and profile.year_like_ratio < 0.50 and profile.date_ratio < 0.50:
        support -= 0.35
    if profile.long_text_ratio >= 0.75 and profile.nonempty <= 2:
        support -= 0.35

    note = None
    if support >= 0.55:
        note = f"row {profile.row_number} looks like an upper header level"
    return support, note


def _forward_fill_header_row(row: list[Any], width: int) -> list[str]:
    """Forward-fill sparse group labels for a readable flattened preview only."""
    result: list[str] = []
    last = ""
    for value in row[:width]:
        token = _display_token(value)
        if token:
            last = token
            result.append(token)
        else:
            result.append(last)
    if len(result) < width:
        result.extend([last] * (width - len(result)))
    return result


def _flatten_headers(rows: list[list[Any]], start_row: int, end_row: int, width: int) -> list[str]:
    selected = rows[start_row - 1 : end_row]
    if not selected:
        return []

    filled = [_forward_fill_header_row(row, width) for row in selected]
    flattened: list[str] = []
    for col in range(width):
        tokens: list[str] = []
        for row in filled:
            token = row[col].strip()
            if token and (not tokens or tokens[-1].casefold() != token.casefold()):
                tokens.append(token)
        flattened.append(" | ".join(tokens) if tokens else f"Column {col + 1}")
    return flattened


def _confidence(score: float) -> str:
    if score >= 78:
        return "High"
    if score >= 62:
        return "Medium"
    return "Low"


def detect_header_candidates(
    rows: list[list[Any]],
    source_columns: int,
    *,
    max_header_depth: int = 5,
    top_candidates: int = 3,
) -> list[HeaderCandidate]:
    """Recommend likely single- or multi-row headers from top-of-sheet values.

    This function is intentionally conservative. It returns recommendations for
    user confirmation rather than claiming certainty.
    """
    if max_header_depth < 1:
        raise ValueError("max_header_depth must be at least 1")
    if top_candidates < 1:
        raise ValueError("top_candidates must be at least 1")
    if not rows:
        return []

    width = _effective_width(rows, source_columns)
    profiles = [_row_profile(i, row, width) for i, row in enumerate(rows, start=1)]

    raw_candidates: list[tuple[float, int, int, list[str]]] = []
    single_results = [_single_row_score(profiles, i) for i in range(len(profiles))]

    for end_index, leaf in enumerate(profiles):
        single_score, single_reasons = single_results[end_index]
        if single_score >= 25:
            raw_candidates.append((single_score, leaf.row_number, leaf.row_number, single_reasons))

        # Extend upward from the same leaf row to identify hierarchical headers.
        support_total = 0.0
        support_reasons: list[str] = []
        for depth in range(2, min(max_header_depth, end_index + 1) + 1):
            start_index = end_index - depth + 1
            support_profile = profiles[start_index]

            # If two adjacent rows have essentially the same coverage and the
            # upper row scores as a stronger standalone header, the lower row is
            # probably already data. Do not reinterpret them as a multi-row
            # header. Dense year/date grouping rows are exempt.
            upper_single_score = single_results[start_index][0]
            same_density = abs(support_profile.density - leaf.density) < 0.10
            if (
                same_density
                and support_profile.year_like_ratio < 0.50
                and support_profile.date_ratio < 0.50
                and upper_single_score >= single_score
            ):
                break

            support, note = _support_score(support_profile, leaf)
            if support < 0:
                break
            support_total += support
            if note:
                support_reasons.append(note)

            avg_support = support_total / (depth - 1)
            # Multi-row ranges should beat the leaf-only candidate only when the
            # upper rows add credible hierarchical structure.
            range_score = single_score + 17.0 * avg_support + 1.5 * (depth - 1)
            if avg_support < 0.30:
                range_score -= 10.0
            if support_profile.nonempty == 1:
                range_score -= 4.0

            if range_score >= 30:
                reasons = list(single_reasons)
                reasons.extend(support_reasons)
                if depth > 1:
                    reasons.append(f"candidate uses {depth} header rows")
                raw_candidates.append(
                    (
                        min(100.0, range_score),
                        profiles[start_index].row_number,
                        leaf.row_number,
                        reasons,
                    )
                )

    # Deduplicate by exact range, keeping the best score, then prefer higher score,
    # shallower range, and earlier row for deterministic output.
    best_by_range: dict[tuple[int, int], tuple[float, list[str]]] = {}
    for score, start, end, reasons in raw_candidates:
        key = (start, end)
        previous = best_by_range.get(key)
        if previous is None or score > previous[0]:
            best_by_range[key] = (score, reasons)

    def _candidate_rank(item):
        score, start, end, reasons = item
        flat = _flatten_headers(rows, start, end, width)
        unique_ratio = len({x.casefold() for x in flat if x}) / max(1, len([x for x in flat if x]))
        semantic_ratio = sum(bool(_SEMANTIC_HEADER_RE.search(x)) for x in flat) / max(1, len(flat))
        composite_periods = sum(
            bool(re.search(r"\b(?:19|20)\d{2}\b.*(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|P(?:0?[1-9]|1[0-2]))\b", x, re.I))
            for x in flat
        )
        # Composite year+month/period-code headers are a strong reason to keep the
        # relevant multi-row range. Semantic/unique names also beat transactional
        # rows when headline scores are tied.
        return (-score, -composite_periods, -semantic_ratio, -unique_ratio, start, -(end - start))

    ranked = sorted(
        ((score, start, end, reasons) for (start, end), (score, reasons) in best_by_range.items()),
        key=_candidate_rank,
    )

    candidates: list[HeaderCandidate] = []
    for score, start, end, reasons in ranked[:top_candidates]:
        candidates.append(
            HeaderCandidate(
                start_row=start,
                end_row=end,
                score=round(score, 1),
                confidence=_confidence(score),
                flattened_headers=_flatten_headers(rows, start, end, width),
                reasons=reasons[:6],
            )
        )
    return candidates


def _read_excel_rows(
    path: Path,
    sheet_name: str,
    max_scan_rows: int,
    max_scan_columns: int,
) -> tuple[list[list[Any]], int, int]:
    keep_vba = path.suffix.lower() == ".xlsm"
    try:
        workbook = load_workbook(
            filename=path,
            read_only=True,
            data_only=False,
            keep_vba=keep_vba,
            keep_links=True,
        )
    except Exception as exc:
        raise ShipmentReadError(f"Could not read workbook '{path.name}': {exc}") from exc

    try:
        if sheet_name not in workbook.sheetnames:
            raise ShipmentReadError(f"Sheet not found: {sheet_name}")
        worksheet = workbook[sheet_name]
        source_rows = int(worksheet.max_row or 0)
        source_columns = int(worksheet.max_column or 0)
        inspected_columns = min(source_columns, max_scan_columns) if source_columns else 0
        if source_rows == 0 or inspected_columns == 0:
            return [], source_rows, source_columns

        raw_rows = worksheet.iter_rows(
            min_row=1,
            max_row=min(source_rows, max_scan_rows),
            min_col=1,
            max_col=inspected_columns,
            values_only=True,
        )
        return [list(row) for row in raw_rows], source_rows, source_columns
    finally:
        workbook.close()


def _read_csv_rows(
    path: Path,
    max_scan_rows: int,
    max_scan_columns: int,
) -> tuple[list[list[Any]], int, int]:
    # Reuse the reader inventory because it already handles UTF-8/CP1252 and delimiter
    # detection. The inventory preview is exactly the top rows needed for 7B.
    from .reader import inventory_file

    inventory = inventory_file(path, preview_rows=max_scan_rows)
    table = inventory.sheets[0]
    rows = [list(row[:max_scan_columns]) for row in table.preview]
    return rows, table.rows, table.columns


def scan_sheet_headers(
    file_path: str | Path,
    sheet_name: str,
    *,
    max_scan_rows: int = 30,
    max_scan_columns: int = 2048,
    max_header_depth: int = 5,
    top_candidates: int = 3,
) -> SheetHeaderScan:
    """Scan one sheet/table and recommend likely header rows."""
    if max_scan_rows < 2:
        raise ValueError("max_scan_rows must be at least 2")
    if max_scan_columns < 1:
        raise ValueError("max_scan_columns must be at least 1")

    path = validate_source_path(file_path)
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        rows, source_rows, source_columns = _read_excel_rows(
            path, sheet_name, max_scan_rows, max_scan_columns
        )
    elif path.suffix.lower() == ".csv":
        if sheet_name != "(CSV)":
            raise ShipmentReadError("CSV input has a single table named '(CSV)'")
        rows, source_rows, source_columns = _read_csv_rows(
            path, max_scan_rows, max_scan_columns
        )
    else:  # validate_source_path already prevents this branch
        raise UnsupportedFileTypeError(path.suffix)

    inspected_columns = min(source_columns, max_scan_columns) if source_columns else 0
    warnings: list[str] = []
    if source_columns > max_scan_columns:
        warnings.append(
            f"Header detection sampled the first {max_scan_columns:,} of "
            f"{source_columns:,} columns."
        )
    if source_rows > max_scan_rows:
        warnings.append(
            f"Header detection inspected the first {max_scan_rows} of "
            f"{source_rows:,} rows."
        )

    candidates = detect_header_candidates(
        rows,
        source_columns=inspected_columns or source_columns,
        max_header_depth=max_header_depth,
        top_candidates=top_candidates,
    )
    if not candidates:
        warnings.append("No reliable header candidate was found; user review is required.")
    elif candidates[0].confidence == "Low":
        warnings.append("Header recommendation is low confidence; user confirmation is required.")

    return SheetHeaderScan(
        sheet_name=sheet_name,
        source_rows=source_rows,
        source_columns=source_columns,
        inspected_rows=len(rows),
        inspected_columns=inspected_columns,
        candidates=candidates,
        warnings=warnings,
    )


def scan_workbook_headers(
    file_path: str | Path,
    *,
    max_scan_rows: int = 30,
    max_scan_columns: int = 2048,
    max_header_depth: int = 5,
    top_candidates: int = 3,
) -> WorkbookHeaderScan:
    """Scan every sheet/table in a supported source file."""
    from .reader import inventory_file

    path = validate_source_path(file_path)
    inventory = inventory_file(path, preview_rows=0)
    scans = [
        scan_sheet_headers(
            path,
            sheet.name,
            max_scan_rows=max_scan_rows,
            max_scan_columns=max_scan_columns,
            max_header_depth=max_header_depth,
            top_candidates=top_candidates,
        )
        for sheet in inventory.sheets
    ]
    return WorkbookHeaderScan(filename=path.name, sheets=scans)


def manual_header_scan(
    file_path: str | Path,
    sheet_name: str,
    start_row: int,
    end_row: int,
    *,
    max_scan_columns: int = 2048,
) -> SheetHeaderScan:
    """Build a confirmed header scan from an explicit 1-based row range.

    This does not modify the source. It is used by the 7G terminal wizard when the
    user rejects the automatic header recommendation.
    """
    if start_row < 1 or end_row < start_row:
        raise ValueError("Header row range must be positive and end_row >= start_row")
    if end_row - start_row + 1 > 10:
        raise ValueError("Manual header depth is limited to 10 rows for this simple build")

    path = validate_source_path(file_path)
    scan_rows = max(end_row + 2, 12)
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        rows, source_rows, source_columns = _read_excel_rows(
            path, sheet_name, scan_rows, max_scan_columns
        )
    elif path.suffix.lower() == ".csv":
        if sheet_name != "(CSV)":
            raise ShipmentReadError("CSV input has a single table named '(CSV)'")
        rows, source_rows, source_columns = _read_csv_rows(
            path, scan_rows, max_scan_columns
        )
    else:
        raise UnsupportedFileTypeError(path.suffix)

    if end_row > source_rows:
        raise ValueError(
            f"Header end row {end_row} exceeds source row count {source_rows}"
        )
    width = _effective_width(rows, min(source_columns, max_scan_columns))
    flattened = _flatten_headers(rows, start_row, end_row, width)
    candidate = HeaderCandidate(
        start_row=start_row,
        end_row=end_row,
        score=100.0,
        confidence="Manual",
        flattened_headers=flattened,
        reasons=["user-confirmed manual header range"],
    )
    return SheetHeaderScan(
        sheet_name=sheet_name,
        source_rows=source_rows,
        source_columns=source_columns,
        inspected_rows=len(rows),
        inspected_columns=width,
        candidates=[candidate],
        warnings=[],
    )
