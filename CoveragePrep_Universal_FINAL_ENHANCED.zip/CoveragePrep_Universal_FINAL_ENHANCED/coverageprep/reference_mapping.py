"""Optional recommendation-only mapping advisor.

This is intentionally separate from shipment preparation. It never changes
Prepared_Data. If an approved NIQ/reference file is supplied, it recommends exact
identifier or exact normalized descriptive matches. AI/fuzzy matching is not used
unless an approved company workflow is added later.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any
import pandas as pd


def _norm(v: Any) -> str:
    if v is None:
        return ""
    return re.sub(r"[^a-z0-9]+", "", str(v).casefold())


def _read_reference(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() == ".csv":
        return pd.read_csv(p, dtype=object)
    return pd.read_excel(p, dtype=object)


def recommend_reference_mappings(prepared: pd.DataFrame, reference_file: str | Path) -> pd.DataFrame:
    ref = _read_reference(reference_file)
    client_cols = list(prepared.columns)
    ref_cols = list(ref.columns)
    id_words = re.compile(r"sku|upc|ean|gtin|material|item|product.*code|article", re.I)
    common_ids = [(c, r) for c in client_cols for r in ref_cols if id_words.search(str(c)) and _norm(c) == _norm(r)]
    rows: list[dict[str, Any]] = []
    if common_ids:
        ccol, rcol = common_ids[0]
        ref_lookup = {_norm(v): v for v in ref[rcol].dropna().tolist() if _norm(v)}
        for v in prepared[ccol].dropna().drop_duplicates().tolist():
            key = _norm(v)
            if key in ref_lookup:
                rows.append({"CLIENT_FIELD": ccol, "CLIENT_VALUE": v, "REFERENCE_FIELD": rcol, "REFERENCE_VALUE": ref_lookup[key], "METHOD": "Exact identifier", "CONFIDENCE": "High", "ACTION": "Recommendation only; Prepared_Data unchanged"})
    return pd.DataFrame(rows, columns=["CLIENT_FIELD", "CLIENT_VALUE", "REFERENCE_FIELD", "REFERENCE_VALUE", "METHOD", "CONFIDENCE", "ACTION"])
