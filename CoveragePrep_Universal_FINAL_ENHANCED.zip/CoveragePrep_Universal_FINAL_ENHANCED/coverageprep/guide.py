"""Local, deterministic analysis of Guide/Instruction sheets.

CoveragePrep Universal uses guide text as *context*, never as permission to alter
client values. It extracts explicit period examples, period-pattern hints and
shipment-measure hints locally so the main workflow needs fewer manual prompts.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any
import re

from openpyxl import load_workbook

from .reader import validate_source_path

_GUIDE_SHEET_RE = re.compile(
    r"(?:^|\b)(guide|instructions?|read\s*me|readme|documentation|definitions?|spec(?:ification)?s?)(?:\b|$)",
    re.IGNORECASE,
)

_EXPLICIT_MAPPING_RE = re.compile(
    r"(?P<source>c(?:19|20)\d{2}\s+[A-Za-z]{3,9})\s*"
    r"(?:=|means|represents|is|->|→|:)\s*"
    r"(?P<target>[A-Za-z]{3,9}[\s\-/]+(?:19|20)\d{2})",
    re.IGNORECASE,
)
_C_YEAR_MONTH_RE = re.compile(r"\bc(?:19|20)\d{2}\s+[A-Za-z]{3,9}\b", re.IGNORECASE)

# Conservative business-measure phrases. Generic words are accepted only as part of
# recognisable shipment phrases so ordinary prose doesn't create noisy FACT labels.
_MEASURE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\bsales\s*value\b", re.I), "Sales Value"),
    (re.compile(r"\bsales\s*volume\b", re.I), "Sales Volume"),
    (re.compile(r"\bquantity\s*tons?\b|\btons?\b", re.I), "Quantity Tons"),
    (re.compile(r"\bquantity\s*eaches?\b|\beaches?\b", re.I), "Quantity Eaches"),
    (re.compile(r"\bquantity\s*units?\b|\bunits?\b", re.I), "Units"),
    (re.compile(r"\bkilograms?\b|\bkg\b", re.I), "KG"),
    (re.compile(r"\blit(?:re|er)s?\b", re.I), "Litres"),
    (re.compile(r"\bcases?\b", re.I), "Cases"),
    (re.compile(r"\brevenue\b", re.I), "Revenue"),
]

_PERIOD_CODE_MONTHLY_RE = re.compile(
    r"(?:P0?1\s*(?:=|means|is|represents)\s*(?:Jan(?:uary)?|month\s*1)|"
    r"P01\s*[-–]\s*P12.*(?:month|monthly|calendar))",
    re.I,
)


@dataclass(frozen=True)
class GuidePeriodExample:
    sheet_name: str
    source_text: str
    target_text: str
    row_number: int
    confidence: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class GuidePatternHint:
    sheet_name: str
    pattern_name: str
    example: str
    row_number: int
    confidence: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class GuideAnalysis:
    guide_sheets: list[str]
    explicit_period_examples: list[GuidePeriodExample]
    pattern_hints: list[GuidePatternHint]
    notes: list[str]
    metric_hints: list[str] = field(default_factory=list)
    calendar_period_codes: bool = False

    @property
    def explicit_mapping(self) -> dict[str, GuidePeriodExample]:
        return {item.source_text.casefold(): item for item in self.explicit_period_examples}

    @property
    def pattern_names(self) -> set[str]:
        return {item.pattern_name for item in self.pattern_hints}

    def to_dict(self) -> dict[str, Any]:
        return {
            "guide_sheets": list(self.guide_sheets),
            "explicit_period_examples": [x.to_dict() for x in self.explicit_period_examples],
            "pattern_hints": [x.to_dict() for x in self.pattern_hints],
            "notes": list(self.notes),
            "metric_hints": list(self.metric_hints),
            "calendar_period_codes": self.calendar_period_codes,
        }


def _cell_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _read_guide_rows(path: Path, sheet_name: str, *, max_rows: int, max_columns: int) -> list[tuple[int, str]]:
    keep_vba = path.suffix.lower() == ".xlsm"
    wb = load_workbook(path, read_only=True, data_only=False, keep_vba=keep_vba, keep_links=True)
    try:
        ws = wb[sheet_name]
        output: list[tuple[int, str]] = []
        for row_number, row in enumerate(
            ws.iter_rows(
                min_row=1,
                max_row=min(int(ws.max_row or 0), max_rows),
                min_col=1,
                max_col=min(int(ws.max_column or 0), max_columns),
                values_only=True,
            ),
            start=1,
        ):
            pieces = [_cell_text(v) for v in row if _cell_text(v)]
            if pieces:
                output.append((row_number, " | ".join(pieces)))
        return output
    finally:
        wb.close()


def analyze_guide_sheets(
    file_path: str | Path,
    *,
    max_rows: int = 250,
    max_columns: int = 80,
) -> GuideAnalysis:
    path = validate_source_path(file_path)
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        return GuideAnalysis([], [], [], ["No workbook guide-sheet analysis is available for CSV input."])

    keep_vba = path.suffix.lower() == ".xlsm"
    wb = load_workbook(path, read_only=True, data_only=False, keep_vba=keep_vba, keep_links=True)
    try:
        guide_sheets = [name for name in wb.sheetnames if _GUIDE_SHEET_RE.search(name)]
    finally:
        wb.close()

    examples: list[GuidePeriodExample] = []
    hints: list[GuidePatternHint] = []
    notes: list[str] = []
    metric_hints: list[str] = []
    calendar_period_codes = False
    seen_examples: set[tuple[str, str]] = set()
    seen_hints: set[tuple[str, str]] = set()
    seen_metrics: set[str] = set()

    for sheet_name in guide_sheets:
        for row_number, text in _read_guide_rows(path, sheet_name, max_rows=max_rows, max_columns=max_columns):
            for match in _EXPLICIT_MAPPING_RE.finditer(text):
                source = re.sub(r"\s+", " ", match.group("source").strip())
                target = re.sub(r"\s+", " ", match.group("target").strip())
                key = (source.casefold(), target.casefold())
                if key not in seen_examples:
                    seen_examples.add(key)
                    examples.append(GuidePeriodExample(sheet_name, source, target, row_number, "High", "explicit source-to-period example found in guide/instruction text"))

            for example in _C_YEAR_MONTH_RE.findall(text):
                key = (sheet_name.casefold(), "cYYYY MMM")
                if key not in seen_hints:
                    seen_hints.add(key)
                    hints.append(GuidePatternHint(sheet_name, "cYYYY MMM", example, row_number, "High", "client-style cYYYY MMM period token appears in guide/instruction text"))

            for pattern, label in _MEASURE_PATTERNS:
                if pattern.search(text) and label.casefold() not in seen_metrics:
                    seen_metrics.add(label.casefold())
                    metric_hints.append(label)

            if _PERIOD_CODE_MONTHLY_RE.search(text):
                calendar_period_codes = True

    if guide_sheets:
        notes.append(f"Analyzed {len(guide_sheets)} guide/instruction sheet(s) locally: {', '.join(guide_sheets)}.")
        if not examples and not hints:
            notes.append("Guide sheets were found, but no explicit supported period examples were extracted.")
        if metric_hints:
            notes.append("Possible shipment measure hint(s) from guide: " + ", ".join(metric_hints))
        if calendar_period_codes:
            notes.append("Guide text indicates P01-P12 can be interpreted as calendar months.")
    else:
        notes.append("No Guide/Instructions/ReadMe/Documentation/Definition sheet was detected.")

    return GuideAnalysis(guide_sheets, examples, hints, notes, metric_hints, calendar_period_codes)
