"""Low-touch Smart Prepare planner for CoveragePrep Universal.

The planner tries to make the common path almost automatic:
1. select likely data sheets;
2. detect headers/periods;
3. classify dimensions and protected period-support fields;
4. detect one or many shipment measures;
5. infer a FACT label for wide-period files (fallback: ``Value``);
6. ask the user only when a real ambiguity remains.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import re

from .guide import GuideAnalysis, analyze_guide_sheets
from .mapping import detect_fact_measures, suggest_field_roles
from .periods import PeriodFinding, scan_sheet_periods, parse_period
from .reader import inventory_file, validate_source_path
from .scanner import SheetHeaderScan, scan_sheet_headers
from .transform import load_table
from .workflow import SheetRunSpec, suggest_fact_label

_NON_DATA_SHEET_RE = re.compile(r"\b(?:guide|instruction|readme|read\s*me|documentation|definition|summary|notes?|cover|contents?)\b", re.I)


@dataclass
class SmartSheetDiagnostic:
    sheet_name: str
    header: str
    period: str
    measures: list[str]
    fact_label: str | None
    warnings: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)
    needs_period_code_confirmation: bool = False


@dataclass
class SmartPlan:
    source_file: str
    specs: list[SheetRunSpec]
    diagnostics: list[SmartSheetDiagnostic]
    guide: GuideAnalysis
    selected_sheets: list[str]
    warnings: list[str]
    blockers: list[str]
    needs_period_code_confirmation: bool = False

    @property
    def ready(self) -> bool:
        return not self.blockers


def recommend_data_sheets(source_file: str | Path) -> list[str]:
    path = validate_source_path(source_file)
    inv = inventory_file(path, preview_rows=0)
    selected = [
        s.name for s in inv.sheets
        if not _NON_DATA_SHEET_RE.search(s.name) and s.rows >= 3 and s.columns >= 2 and str(s.state).lower() != "hidden"
    ]
    if not selected and inv.sheets:
        # Never silently return nothing; single-table CSV/workbooks still need a path.
        selected = [max(inv.sheets, key=lambda s: (s.rows, s.columns)).name]
    return selected


def _best_finding(period_scan) -> PeriodFinding | None:
    priority = {"COLUMN_HEADER": 1, "COMBINED_COLUMNS": 2, "ROW_COLUMN": 3, "SHEET_NAME": 4}
    safe = [f for f in period_scan.findings if f.status == "OK"]
    if safe:
        return sorted(safe, key=lambda f: priority.get(f.location, 99))[0]
    review = [f for f in period_scan.findings if f.status == "REVIEW" and f.mappings and all(m.standard for m in f.mappings)]
    if review:
        return sorted(review, key=lambda f: priority.get(f.location, 99))[0]
    return None


def _headers_excluding_periods(table, finding: PeriodFinding) -> list[str]:
    period_sources = set(finding.source_columns)
    headers: list[str] = []
    for c in table.columns:
        if c.source_header in period_sources or c.flattened_header in period_sources:
            continue
        if parse_period(c.flattened_header).status in {"OK", "REVIEW", "AMBIGUOUS"}:
            continue
        headers.append(c.source_header)
    return headers


def _fact_label_for_wide(path: Path, sheet_name: str, guide: GuideAnalysis) -> tuple[str, str | None]:
    # Explicit guide business context is strongest. If several measures are mentioned,
    # a wide table still has one value series, so use a neutral label rather than guess.
    if len(guide.metric_hints) == 1:
        return guide.metric_hints[0], None
    sheet_hint = suggest_fact_label(sheet_name)
    if sheet_hint:
        return sheet_hint, None
    filename_hint = suggest_fact_label(path.stem)
    if filename_hint:
        return filename_hint, None
    return "Value", "FACT meaning was not explicit; neutral label 'Value' used. Review if a business-specific label is required."


def build_smart_plan(
    source_file: str | Path,
    *,
    selected_sheets: list[str] | None = None,
    period_order: str = "ascending",
    negative_policy: str = "keep",
    duplicate_policy: str = "keep",
    accept_period_codes: bool | None = None,
) -> SmartPlan:
    path = validate_source_path(source_file)
    guide = analyze_guide_sheets(path)
    selected = selected_sheets or recommend_data_sheets(path)
    specs: list[SheetRunSpec] = []
    diagnostics: list[SmartSheetDiagnostic] = []
    warnings: list[str] = []
    blockers: list[str] = []
    any_pcode_confirm = False

    # Cache role/measure decisions for structurally identical sheets so year-based
    # workbooks do not conceptually reconfigure the same layout five times.
    signature_cache: dict[tuple[str, ...], dict[str, Any]] = {}

    for sheet_name in selected:
        swarn: list[str] = []
        sblock: list[str] = []
        hscan: SheetHeaderScan = scan_sheet_headers(path, sheet_name)
        candidate = hscan.recommended
        if not candidate:
            sblock.append("No reliable header detected")
            diagnostics.append(SmartSheetDiagnostic(sheet_name, "Not detected", "Not detected", [], None, swarn, sblock))
            blockers.append(f"{sheet_name}: no reliable header detected")
            continue
        if candidate.confidence == "Low":
            sblock.append(f"Header confidence is low (rows {candidate.start_row}-{candidate.end_row})")
        elif candidate.confidence == "Medium":
            swarn.append(f"Header confidence is medium (rows {candidate.start_row}-{candidate.end_row})")

        pscan = scan_sheet_periods(path, sheet_name, header_scan=hscan, guide_analysis=guide)
        if pscan.collisions:
            sblock.append(f"{len(pscan.collisions)} period collision(s)")
        finding = _best_finding(pscan)
        if not finding:
            sblock.append("No safe or reviewable period structure detected")
            period_text = "Not detected"
            measures: list[str] = []
            fact_label = None
            roles: dict[str, str] = {}
            spec = None
        else:
            period_text = f"{finding.location} / {finding.frequency} / {finding.status}"
            needs_pcode = finding.status == "REVIEW" and finding.frequency in {"Period code", "Fiscal period code"}
            any_pcode_confirm = any_pcode_confirm or needs_pcode
            if needs_pcode and not (guide.calendar_period_codes or accept_period_codes is True):
                swarn.append("Year + P01/P02 structure detected; one calendar/fiscal/retail interpretation confirmation is needed")

            table = load_table(path, sheet_name, header_scan=hscan)
            signature = tuple(re.sub(r"\b(?:19|20)\d{2}\b", "YYYY", str(c.flattened_header), flags=re.I) for c in table.columns)
            cached = signature_cache.get(signature)
            if cached:
                roles = dict(cached["roles"])
                measure_headers = list(cached["measure_headers"])
                measure_labels = dict(cached["measure_labels"])
                fact_label = cached.get("fact_label")
                swarn.append("Reused inferred roles/measures from a structurally identical sheet")
            else:
                headers = _headers_excluding_periods(table, finding)
                role_suggestions = suggest_field_roles(headers)
                roles = {x.source_header: x.role for x in role_suggestions}
                source_frame = table.frame.rename(columns={c.internal_name: c.source_header for c in table.columns})

                if finding.location == "COLUMN_HEADER":
                    measure_headers = []
                    measure_labels = {}
                    fact_label, label_warning = _fact_label_for_wide(path, sheet_name, guide)
                    if label_warning:
                        swarn.append(label_warning)
                else:
                    detection = detect_fact_measures(
                        source_frame,
                        layout="SHEET_PERIOD" if finding.location == "SHEET_NAME" else "ROW_PERIODS",
                        period_source_columns=finding.source_columns,
                        assigned_roles=roles,
                        sheet_name=sheet_name,
                    )
                    measure_headers = list(detection.measure_columns)
                    measure_labels = dict(detection.suggested_labels)
                    fact_label = measure_labels.get(measure_headers[0]) if len(measure_headers) == 1 else None
                    if detection.status == "BLOCKER":
                        sblock.append(detection.reason)
                    elif detection.status == "REVIEW":
                        swarn.append(detection.reason)
                    if len(measure_headers) > 1:
                        swarn.append(f"Detected {len(measure_headers)} shipment measures and will process all as separate FACT rows")
                signature_cache[signature] = {
                    "roles": roles,
                    "measure_headers": measure_headers,
                    "measure_labels": measure_labels,
                    "fact_label": fact_label,
                }

            measures = measure_headers
            accept_codes = bool(guide.calendar_period_codes or accept_period_codes is True)
            spec = SheetRunSpec(
                sheet_name=sheet_name,
                header_start_row=candidate.start_row,
                header_end_row=candidate.end_row,
                fact_label=fact_label,
                fact_source_header=(measure_headers[0] if len(measure_headers) == 1 else None),
                fact_source_headers=(measure_headers if len(measure_headers) > 1 else None),
                fact_labels=measure_labels or None,
                field_roles=roles,
                period_order=period_order,
                negative_policy=negative_policy,
                duplicate_policy=duplicate_policy,
                accept_period_codes=accept_codes,
            )
            specs.append(spec)

        if sblock:
            blockers.extend(f"{sheet_name}: {x}" for x in sblock)
        warnings.extend(f"{sheet_name}: {x}" for x in swarn)
        diagnostics.append(SmartSheetDiagnostic(
            sheet_name=sheet_name,
            header=f"Rows {candidate.start_row}-{candidate.end_row} ({candidate.confidence})" if candidate else "Not detected",
            period=period_text,
            measures=measures,
            fact_label=fact_label,
            warnings=swarn,
            blockers=sblock,
            needs_period_code_confirmation=(finding is not None and finding.status == "REVIEW" and finding.frequency in {"Period code", "Fiscal period code"}),
        ))

    return SmartPlan(str(path), specs, diagnostics, guide, selected, warnings, blockers, any_pcode_confirm)
