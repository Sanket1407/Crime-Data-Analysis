"""Field-role and shipment-measure detection for CoveragePrep Universal.

Design goals
------------
* preserve client header text in Prepared_Data;
* use logical roles only for ordering/diagnostics;
* protect numeric identifiers/metadata from FACT selection;
* support one OR many genuine shipment measures in a long-format table;
* keep period-support fields (Year/Month/Period) out of dimension/fact choices;
* prefer confident auto-detection, with review only when evidence is weak.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Iterable
import math
import re

import pandas as pd


ROLE_ORDER = {
    "PERIOD_SUPPORT": 5,
    "COUNTRY": 10,
    "REGION": 20,
    "CHANNEL": 30,
    "CITY": 40,
    "STATE": 50,
    "CATEGORY": 60,
    "BRAND": 70,
    "SKU": 80,
    "EXTRA": 90,
}

_ROLE_PATTERNS: list[tuple[str, re.Pattern[str], str]] = [
    ("PERIOD_SUPPORT", re.compile(r"\b(display\s*year|displayyear|year|yr|month|display\s*month|displaymonth|displaymonthyear|period|week|wk|quarter|qtr|date)\b", re.I), "period-support field"),
    ("COUNTRY", re.compile(r"\b(country|cntry|nation|market\s*country)\b", re.I), "country-like header"),
    ("REGION", re.compile(r"\b(region|regn|zone|territory|area|branch)\b", re.I), "region-like header"),
    ("CHANNEL", re.compile(r"\b(channel|chnl|trade\s*channel|route\s*to\s*market|sub\s*trade\s*channel|cd_channel)\b", re.I), "channel-like header"),
    ("CITY", re.compile(r"\b(city|town)\b", re.I), "city-like header"),
    ("STATE", re.compile(r"\b(state|province)\b", re.I), "state-like header"),
    ("CATEGORY", re.compile(r"\b(category|catg|cat\b|product\s*(group|family|segment)|segment|division)\b", re.I), "category/product-group-like header"),
    ("BRAND", re.compile(r"\b(brand|brnd|high\s*brand|sub\s*brand|master\s*brand)\b", re.I), "brand-like header"),
    ("SKU", re.compile(r"\b(sku|upc|ean|gtin|material|item\s*(code|id|number|no)?|product[_\s-]*code|article\s*(code|id|number|no)?|product[_\s-]*id)\b", re.I), "SKU/identifier-like header"),
]

# Strong fact/measure vocabulary.  The expression deliberately includes unit-like
# business measures that appeared in challenge files (tons/eaches/value etc.).
_MEASURE_HEADER_RE = re.compile(
    r"\b(?:sales(?:[_\s-]*(?:value|volume|qty|quantity|units?))?|"
    r"value|revenue|amount|turnover|volume|vol|qty|quantity|units?|eaches?|pieces?|pcs|"
    r"tons?|tonnes?|kg|kilograms?|lit(?:re|er)s?|cases?|packs?)\b",
    re.I,
)

# Explicit metadata/identifier exclusions requested by the company-laptop review.
# These remain protected even when 100% numeric.
_IDENTIFIER_RE = re.compile(
    r"(?:^|[_\s\[\]-])(?:id|code|key|year|displayyear|display_year|upc|ean|gtin|sku|"
    r"product[_\s-]*code|product[_\s-]*id|material(?:[_\s-]*(?:code|id|number|no))?|"
    r"item(?:[_\s-]*(?:code|id|number|no))?|article(?:[_\s-]*(?:code|id|number|no))?)"
    r"(?:$|[_\s\]\-])",
    re.I,
)
_PERIOD_COMPONENT_RE = re.compile(r"\b(year|yr|displayyear|display_year|month|mnth|displaymonthyear|period|week|wk|quarter|qtr|date)\b", re.I)


def _header_normalized(header: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(header).casefold()).strip()


@dataclass(frozen=True)
class FieldRoleSuggestion:
    source_header: str
    role: str
    confidence: str
    reason: str
    original_position: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class FactCandidate:
    source_header: str
    numeric_ratio: float
    nonblank_count: int
    header_hint: bool
    identifier_hint: bool
    score: float
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MeasureDetection:
    status: str  # OK / REVIEW / BLOCKER / NEEDS_LABEL
    layout: str
    measure_columns: list[str]
    suggested_labels: dict[str, str]
    candidates: list[FactCandidate]
    reason: str

    @property
    def source_column(self) -> str | None:
        return self.measure_columns[0] if len(self.measure_columns) == 1 else None

    @property
    def suggested_fact_label(self) -> str | None:
        if len(self.measure_columns) == 1:
            return self.suggested_labels.get(self.measure_columns[0])
        return None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# Backward-compatible alias used by older tests/callers.
SingleFactDetection = MeasureDetection


def suggest_field_roles(headers: Iterable[str]) -> list[FieldRoleSuggestion]:
    """Recommend logical roles while preserving the exact source header text."""
    suggestions: list[FieldRoleSuggestion] = []
    for pos, header in enumerate(headers, start=1):
        text = str(header)
        role = "EXTRA"
        confidence = "Low"
        reason = "no safe standard role inferred; keep as source field"
        for candidate_role, pattern, candidate_reason in _ROLE_PATTERNS:
            if pattern.search(text):
                role = candidate_role
                confidence = "High"
                reason = candidate_reason
                break
        suggestions.append(FieldRoleSuggestion(text, role, confidence, reason, pos))
    return suggestions


def order_headers_by_role(headers: list[str], assignments: dict[str, str] | None = None) -> list[str]:
    """Return headers in logical output order; names themselves are unchanged."""
    if assignments is None:
        assignments = {s.source_header: s.role for s in suggest_field_roles(headers)}
    original_pos = {header: idx for idx, header in enumerate(headers)}
    # PERIOD_SUPPORT columns should normally be excluded by the transform.  If one
    # survives, place it before ordinary dimensions rather than treating it as a fact.
    return sorted(
        headers,
        key=lambda h: (ROLE_ORDER.get(assignments.get(h, "EXTRA"), ROLE_ORDER["EXTRA"]), original_pos[h]),
    )


def _numeric_ratio(series: pd.Series) -> tuple[float, int]:
    values = series.dropna()
    if values.empty:
        return 0.0, 0

    nonblank: list[Any] = []
    numeric = 0
    for value in values.tolist():
        if isinstance(value, str) and value.strip() == "":
            continue
        nonblank.append(value)
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)) and not (isinstance(value, float) and math.isnan(value)):
            numeric += 1
            continue
        if isinstance(value, str):
            t = value.strip().replace(",", "")
            try:
                float(t)
                numeric += 1
            except ValueError:
                pass
    return (numeric / len(nonblank) if nonblank else 0.0), len(nonblank)


def _is_identifier_header(header: str) -> bool:
    normalized = " " + _header_normalized(header) + " "
    # Exact/near-exact protected metadata names.
    protected = {
        "id", "code", "key", "year", "displayyear", "display year", "upc", "ean", "gtin", "sku",
        "product code", "product_code", "product id", "product_id", "display_year",
    }
    if _header_normalized(header) in protected:
        return True
    return bool(_IDENTIFIER_RE.search(" " + str(header) + " "))


def _candidate_columns(
    frame: pd.DataFrame,
    *,
    period_source_columns: Iterable[str],
    excluded_columns: Iterable[str],
    assigned_roles: dict[str, str],
) -> list[FactCandidate]:
    excluded = set(period_source_columns) | set(excluded_columns)
    candidates: list[FactCandidate] = []
    for header in frame.columns:
        header = str(header)
        if header in excluded:
            continue
        role = assigned_roles.get(header)
        if role in {"SKU", "COUNTRY", "REGION", "CHANNEL", "CITY", "STATE", "CATEGORY", "BRAND", "PERIOD_SUPPORT"}:
            continue
        normalized_header = _header_normalized(header)
        if _PERIOD_COMPONENT_RE.search(normalized_header):
            continue

        ratio, count = _numeric_ratio(frame[header])
        if count < 1 or ratio < 0.80:
            continue

        header_hint = bool(_MEASURE_HEADER_RE.search(normalized_header))
        identifier_hint = _is_identifier_header(header)
        # Strong measure vocabulary matters more than pure numericity. Identifier
        # metadata is heavily penalized and never auto-selected.
        score = ratio * 50 + (45 if header_hint else 0) - (100 if identifier_hint else 0)
        reason_parts = [f"{ratio:.0%} of nonblank values are numeric"]
        if header_hint:
            reason_parts.append("header looks shipment-measure-like")
        if identifier_hint:
            reason_parts.append("protected identifier/metadata field; excluded from automatic FACT selection")
        candidates.append(FactCandidate(header, ratio, count, header_hint, identifier_hint, score, "; ".join(reason_parts)))
    candidates.sort(key=lambda c: c.score, reverse=True)
    return candidates


def detect_fact_measures(
    frame: pd.DataFrame,
    *,
    layout: str,
    period_source_columns: Iterable[str] = (),
    excluded_columns: Iterable[str] = (),
    assigned_roles: dict[str, str] | None = None,
    sheet_name: str | None = None,
) -> MeasureDetection:
    """Detect one or more genuine shipment measures.

    Wide-period layouts already contain the single value series inside the period
    columns, so only the FACT label is needed. Long/row layouts may legitimately
    contain several measures such as Quantity Tons, Value Mio and Quantity Eaches.
    """
    if layout == "WIDE_PERIODS":
        return MeasureDetection(
            status="NEEDS_LABEL",
            layout=layout,
            measure_columns=[],
            suggested_labels={},
            candidates=[],
            reason="period columns contain the shipment value series; infer or use a neutral FACT label",
        )

    assigned_roles = assigned_roles or {}
    candidates = _candidate_columns(
        frame,
        period_source_columns=period_source_columns,
        excluded_columns=excluded_columns,
        assigned_roles=assigned_roles,
    )
    safe = [c for c in candidates if not c.identifier_hint]
    strong = [c for c in safe if c.header_hint and c.numeric_ratio >= 0.80]

    if strong:
        cols = [c.source_header for c in strong]
        return MeasureDetection(
            status="OK",
            layout=layout,
            measure_columns=cols,
            suggested_labels={c: c for c in cols},
            candidates=candidates,
            reason=(
                "multiple shipment measures detected from fact-like numeric headers"
                if len(cols) > 1 else "one shipment measure detected from a fact-like numeric header"
            ),
        )

    if len(safe) == 1:
        chosen = safe[0]
        return MeasureDetection(
            status="REVIEW",
            layout=layout,
            measure_columns=[chosen.source_header],
            suggested_labels={chosen.source_header: chosen.source_header},
            candidates=candidates,
            reason="one numeric non-identifier column remains, but its header is not clearly measure-like",
        )

    if not safe:
        return MeasureDetection(
            status="BLOCKER",
            layout=layout,
            measure_columns=[],
            suggested_labels={},
            candidates=candidates,
            reason="no safe numeric shipment-measure column could be identified",
        )

    return MeasureDetection(
        status="REVIEW",
        layout=layout,
        measure_columns=[],
        suggested_labels={},
        candidates=candidates,
        reason="multiple numeric non-identifier columns remain but none has a strong shipment-measure header",
    )


def detect_single_fact(
    frame: pd.DataFrame,
    *,
    layout: str,
    period_source_columns: Iterable[str] = (),
    excluded_columns: Iterable[str] = (),
    assigned_roles: dict[str, str] | None = None,
    sheet_name: str | None = None,
) -> MeasureDetection:
    """Backward-compatible single-fact view over :func:`detect_fact_measures`."""
    detection = detect_fact_measures(
        frame,
        layout=layout,
        period_source_columns=period_source_columns,
        excluded_columns=excluded_columns,
        assigned_roles=assigned_roles,
        sheet_name=sheet_name,
    )
    if len(detection.measure_columns) <= 1:
        return detection
    # Older callers expected a manual choice if several measures existed.  The
    # Universal workflow consumes all measures; legacy callers receive REVIEW.
    return MeasureDetection(
        status="REVIEW",
        layout=layout,
        measure_columns=detection.measure_columns,
        suggested_labels=detection.suggested_labels,
        candidates=detection.candidates,
        reason="multiple valid shipment measures detected; Universal mode can process all measures",
    )
