"""Conservative data-quality and standardization recommendations.

The Universal build preserves source values by default. This module surfaces safe,
actionable standardization opportunities so the output satisfies the challenge's
standardization objective without silently changing business meaning.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import re
from typing import Any

import pandas as pd

_UOM_CANON = {
    "kg": "KG", "kgs": "KG", "kilogram": "KG", "kilograms": "KG",
    "g": "G", "gram": "G", "grams": "G",
    "l": "L", "lt": "L", "ltr": "L", "litre": "L", "litres": "L", "liter": "L", "liters": "L",
    "ml": "ML", "millilitre": "ML", "millilitres": "ML", "milliliter": "ML", "milliliters": "ML",
    "unit": "UNITS", "units": "UNITS", "pc": "UNITS", "pcs": "UNITS", "piece": "UNITS", "pieces": "UNITS",
}


def _text(v: Any) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except Exception:
        pass
    return str(v)


def _surface_key(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", text.casefold())


def _clean_space(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip())


def _pack_format(text: str) -> str | None:
    t = _clean_space(text).upper()
    m = re.fullmatch(r"(\d+)\s*[Xx×]\s*(\d+(?:\.\d+)?)\s*(ML|L|G|KG)", t)
    if m:
        return f"{m.group(1)} x {m.group(2)} {m.group(3)}"
    return None


def build_standardization_recommendations(frame: pd.DataFrame, field_roles: dict[str, str] | None = None) -> pd.DataFrame:
    field_roles = field_roles or {}
    rows: list[dict[str, Any]] = []
    for col in frame.columns:
        if col == "FACT":
            continue
        role = field_roles.get(str(col), "EXTRA")
        series = frame[col]
        text_values = [_text(v) for v in series.tolist() if _text(v)]
        if not text_values:
            continue

        # Whitespace-only differences are safe to recommend across descriptions and hierarchy values.
        space_counts: Counter[tuple[str, str]] = Counter()
        for v in text_values:
            cleaned = _clean_space(v)
            if cleaned != v:
                space_counts[(v, cleaned)] += 1
        for (orig, sug), count in space_counts.most_common(50):
            rows.append({
                "FIELD": col, "ROLE": role, "TYPE": "Whitespace", "ORIGINAL": orig, "SUGGESTED": sug,
                "METHOD": "trim/collapse spaces", "CONFIDENCE": "High", "AFFECTED_ROWS": count,
                "ACTION": "Safe formatting recommendation; source remains preserved",
            })

        # UOM standardization when the field name clearly indicates a unit/UOM field.
        if re.search(r"\b(uom|unit\s*of\s*measure|measure\s*unit|unit)\b", str(col), re.I):
            counts = Counter(v.strip() for v in text_values)
            for orig, count in counts.items():
                canon = _UOM_CANON.get(orig.casefold())
                if canon and canon != orig:
                    rows.append({
                        "FIELD": col, "ROLE": role, "TYPE": "UOM", "ORIGINAL": orig, "SUGGESTED": canon,
                        "METHOD": "deterministic UOM synonym", "CONFIDENCE": "High", "AFFECTED_ROWS": count,
                        "ACTION": "Review/apply in approved workflow; no quantity conversion",
                    })

        # Pack-size display formatting only: never convert quantities.
        if re.search(r"\b(pack|size|packsize|pack_size)\b", str(col), re.I):
            counts = Counter(v.strip() for v in text_values)
            for orig, count in counts.items():
                sug = _pack_format(orig)
                if sug and sug != orig:
                    rows.append({
                        "FIELD": col, "ROLE": role, "TYPE": "Pack Size", "ORIGINAL": orig, "SUGGESTED": sug,
                        "METHOD": "format only", "CONFIDENCE": "High", "AFFECTED_ROWS": count,
                        "ACTION": "Formatting recommendation only; numeric pack quantity unchanged",
                    })

        # Surface-equivalent variants for business hierarchy fields. This does not fuzzy-merge distinct names.
        if role in {"COUNTRY", "REGION", "CHANNEL", "CATEGORY", "BRAND", "SKU"} or re.search(r"description|desc|product", str(col), re.I):
            groups: dict[str, Counter[str]] = defaultdict(Counter)
            for v in text_values:
                groups[_surface_key(_clean_space(v))][_clean_space(v)] += 1
            for variants in groups.values():
                if len(variants) <= 1:
                    continue
                canonical = variants.most_common(1)[0][0]
                for orig, count in variants.items():
                    if orig != canonical:
                        rows.append({
                            "FIELD": col, "ROLE": role, "TYPE": "Surface Variant", "ORIGINAL": orig, "SUGGESTED": canonical,
                            "METHOD": "case/space/punctuation-equivalent grouping", "CONFIDENCE": "High", "AFFECTED_ROWS": count,
                            "ACTION": "Review; no semantic/fuzzy merge was performed",
                        })
    columns = ["FIELD", "ROLE", "TYPE", "ORIGINAL", "SUGGESTED", "METHOD", "CONFIDENCE", "AFFECTED_ROWS", "ACTION"]
    return pd.DataFrame(rows, columns=columns)


def build_data_quality_summary(frame: pd.DataFrame, field_roles: dict[str, str] | None = None) -> pd.DataFrame:
    field_roles = field_roles or {}
    rows: list[dict[str, Any]] = []
    for col in frame.columns:
        role = field_roles.get(str(col), "")
        total = len(frame)
        blank = int(frame[col].isna().sum()) + int((frame[col].astype(str).str.strip() == "").sum()) if total else 0
        if blank:
            rows.append({"SEVERITY": "WARNING", "FIELD": col, "ROLE": role, "ISSUE": "Missing/blank values", "COUNT": blank, "RECOMMENDATION": "Review source/client clarification; do not infer values"})
        if frame[col].dtype == object:
            vals = [_text(v) for v in frame[col].tolist() if _text(v)]
            trailing = sum(v != v.strip() for v in vals)
            if trailing:
                rows.append({"SEVERITY": "INFO", "FIELD": col, "ROLE": role, "ISSUE": "Leading/trailing whitespace", "COUNT": trailing, "RECOMMENDATION": "Use safe formatting standardization if approved"})
    return pd.DataFrame(rows, columns=["SEVERITY", "FIELD", "ROLE", "ISSUE", "COUNT", "RECOMMENDATION"])
