"""Read-only workbook scan report with period QA and readiness diagnostics.

This report is deliberately diagnostic: it does not transform shipment values.  It
surfaces what CoveragePrep detected, how period labels would be normalized, whether
periods are chronological/complete, what the Guide sheet explicitly says, and which
items would still require human confirmation before preparation.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import math
import re

import pandas as pd

from .reader import inventory_file, validate_source_path
from .scanner import scan_workbook_headers
from .periods import parse_period, scan_sheet_periods, SheetPeriodScan, PeriodFinding
from .guide import analyze_guide_sheets, GuideAnalysis
from .mapping import detect_fact_measures, suggest_field_roles
from .export import _write_dataframe


def _confidence_percent(label: str) -> int:
    return {"High": 98, "Medium": 75, "Low": 40}.get(str(label), 50)


def _best_finding(scan: SheetPeriodScan) -> PeriodFinding | None:
    priority = {"COLUMN_HEADER": 1, "COMBINED_COLUMNS": 2, "ROW_COLUMN": 3, "SHEET_NAME": 4}
    candidates = [f for f in scan.findings if f.mappings]
    if not candidates:
        return None
    candidates.sort(
        key=lambda f: (
            0 if f.status == "OK" else 1 if f.status == "REVIEW" else 2,
            priority.get(f.location, 99),
            -len(f.mappings),
        )
    )
    return candidates[0]


def _layout_name(scan: SheetPeriodScan) -> str:
    finding = _best_finding(scan)
    if not finding:
        return "Unknown"
    suffix = finding.frequency if finding.frequency not in {"Unknown", "Period code"} else ""
    if finding.location == "COLUMN_HEADER":
        base = "Wide"
    elif finding.location in {"ROW_COLUMN", "COMBINED_COLUMNS"}:
        base = "Long"
    elif finding.location == "SHEET_NAME":
        base = "Sheet-per-period"
    else:
        base = "Unknown"
    return f"{base} {suffix}".strip()


def _normalize_headers(headers: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    result: list[str] = []
    for raw in headers:
        base = str(raw or "Column").strip() or "Column"
        key = base.casefold()
        seen[key] = seen.get(key, 0) + 1
        result.append(base if seen[key] == 1 else f"{base}__{seen[key]}")
    return result


def _sample_frame(preview_rows: list[list[Any]], header_end_row: int, headers: list[str]) -> pd.DataFrame:
    width = len(headers)
    body: list[list[Any]] = []
    for row in preview_rows[header_end_row:]:
        vals = list(row[:width]) + [None] * max(0, width - len(row))
        vals = vals[:width]
        if any(v is not None and str(v).strip() != "" for v in vals):
            body.append(vals)
    return pd.DataFrame(body, columns=_normalize_headers(headers))


def _numeric_ratio(values: pd.Series) -> float:
    nonblank = []
    numeric = 0
    for value in values.tolist():
        if value is None:
            continue
        if isinstance(value, float) and math.isnan(value):
            continue
        if isinstance(value, str) and not value.strip():
            continue
        nonblank.append(value)
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)):
            numeric += 1
            continue
        try:
            float(str(value).strip().replace(",", ""))
            numeric += 1
        except ValueError:
            pass
    return numeric / len(nonblank) if nonblank else 0.0


def _assess_readiness(
    *,
    sheet_name: str,
    header_scan,
    period_scan: SheetPeriodScan,
    preview_rows: list[list[Any]],
    guide_analysis: GuideAnalysis,
) -> tuple[int, str, list[dict[str, Any]], str, str]:
    """Return transparent readiness score + components, not a hidden ML score."""
    candidate = header_scan.recommended
    rows: list[dict[str, Any]] = []
    score = 0

    # Header: 20 points.
    if candidate:
        header_points = 20 if candidate.confidence == "High" else 15 if candidate.confidence == "Medium" else 8
        header_status = "PASS" if candidate.confidence in {"High", "Medium"} else "REVIEW"
        detail = f"Rows {candidate.start_row}-{candidate.end_row}, score {candidate.score:.1f}, {candidate.confidence} confidence"
    else:
        header_points, header_status, detail = 0, "FAIL", "No usable header recommendation"
    score += header_points
    rows.append({"SHEET": sheet_name, "COMPONENT": "Header Detection", "STATUS": header_status, "POINTS": header_points, "MAX_POINTS": 20, "DETAIL": detail})

    safe_findings = [f for f in period_scan.findings if f.status == "OK"]
    review_findings = [f for f in period_scan.findings if f.status == "REVIEW"]
    if period_scan.collisions:
        period_points, period_status = 0, "FAIL"
        detail = f"{len(period_scan.collisions)} period collision(s) must be resolved"
    elif safe_findings:
        period_points, period_status = 35, "PASS"
        detail = f"{period_scan.coverage.detected_periods if period_scan.coverage else len(safe_findings[0].mappings)} period(s) detected"
    elif review_findings:
        period_points, period_status = 22, "REVIEW"
        detail = "Period pattern recognized but requires user confirmation"
    else:
        period_points, period_status = 0, "FAIL"
        detail = "No safe period structure detected"
    score += period_points
    rows.append({"SHEET": sheet_name, "COMPONENT": "Period Detection", "STATUS": period_status, "POINTS": period_points, "MAX_POINTS": 35, "DETAIL": detail})

    coverage = period_scan.coverage
    if coverage:
        if coverage.source_order in {"Ascending", "Descending", "Single period"}:
            chrono_points, chrono_status = 10, "PASS"
        elif coverage.source_order == "Non-chronological":
            # Sorting the prepared output is safe and user-controlled, so this is not a blocker.
            chrono_points, chrono_status = 8, "REVIEW"
        else:
            chrono_points, chrono_status = 2, "FAIL"
        chrono_detail = f"Source order: {coverage.source_order}; first={coverage.earliest}; last={coverage.latest}"
    else:
        chrono_points, chrono_status, chrono_detail = 0, "FAIL", "No period coverage available"
    score += chrono_points
    rows.append({"SHEET": sheet_name, "COMPONENT": "Chronology", "STATUS": chrono_status, "POINTS": chrono_points, "MAX_POINTS": 10, "DETAIL": chrono_detail})

    # Field structure: 15 points, based on dimensions remaining after period columns.
    if candidate:
        period_originals = {
            m.original.casefold()
            for f in period_scan.findings
            for m in f.mappings
            if m.standard and m.status in {"OK", "REVIEW"}
        }
        nonperiod_headers = [
            h for h in candidate.flattened_headers
            if str(h).casefold() not in period_originals and parse_period(h, guide_analysis=guide_analysis).status == "NOT_PERIOD"
        ]
        roles = suggest_field_roles(nonperiod_headers)
        recognized_roles = [r for r in roles if r.role != "EXTRA"]
        if nonperiod_headers:
            field_points = 15
            field_status = "PASS"
            field_detail = f"{len(nonperiod_headers)} non-period field(s); {len(recognized_roles)} logical role recommendation(s)"
        else:
            field_points, field_status, field_detail = 5, "REVIEW", "No clear non-period dimensions in sampled header"
    else:
        nonperiod_headers, roles = [], []
        field_points, field_status, field_detail = 0, "FAIL", "Header required before field assessment"
    score += field_points
    rows.append({"SHEET": sheet_name, "COMPONENT": "Field Detection", "STATUS": field_status, "POINTS": field_points, "MAX_POINTS": 15, "DETAIL": field_detail})

    # Fact readiness: 15 points. For wide layouts, values beneath period columns are
    # the one fact series; for row layouts use the existing single-fact detector on a sample.
    fact_status, fact_detail, fact_points = "FAIL", "Fact/value series could not be assessed", 0
    best = _best_finding(period_scan)
    if candidate and best and preview_rows:
        frame = _sample_frame(preview_rows, candidate.end_row, candidate.flattened_headers)
        if best.location == "COLUMN_HEADER":
            ratios: list[float] = []
            for col in frame.columns:
                parsed = parse_period(col, guide_analysis=guide_analysis)
                if parsed.status in {"OK", "REVIEW"} and parsed.standard:
                    ratios.append(_numeric_ratio(frame[col]))
            if ratios and sum(r >= 0.80 for r in ratios) / len(ratios) >= 0.80:
                fact_status, fact_points = "PASS", 15
                fact_detail = f"Wide-period layout: period columns contain one numeric value series ({sum(r >= 0.80 for r in ratios)}/{len(ratios)} columns >=80% numeric in sample)"
            elif ratios:
                fact_status, fact_points = "REVIEW", 8
                fact_detail = "Period columns detected, but sampled values are not consistently numeric"
        elif best.location in {"ROW_COLUMN", "COMBINED_COLUMNS", "SHEET_NAME"}:
            # Use displayed sample headers and existing conservative fact detector.
            assigned = {r.source_header: r.role for r in suggest_field_roles(list(frame.columns))}
            detection = detect_fact_measures(
                frame,
                layout="SHEET_PERIOD" if best.location == "SHEET_NAME" else "ROW_PERIODS",
                period_source_columns=best.source_columns,
                assigned_roles=assigned,
                sheet_name=sheet_name,
            )
            if detection.status == "OK":
                fact_status, fact_points = "PASS", 15
            elif detection.status in {"REVIEW", "NEEDS_LABEL"}:
                fact_status, fact_points = "REVIEW", 10
            else:
                fact_status, fact_points = "FAIL", 0
            fact_detail = detection.reason
            if detection.measure_columns:
                fact_detail += "; measures=" + ", ".join(detection.measure_columns)
    score += fact_points
    rows.append({"SHEET": sheet_name, "COMPONENT": "Fact Detection", "STATUS": fact_status, "POINTS": fact_points, "MAX_POINTS": 15, "DETAIL": fact_detail})

    # Safety/blockers: 5 points.
    blockers = period_scan.blocking_issue_count
    safety_points = 5 if blockers == 0 else 0
    safety_status = "PASS" if blockers == 0 else "FAIL"
    safety_detail = "No blocking period issue detected" if blockers == 0 else f"{blockers} blocking period issue(s)"
    score += safety_points
    rows.append({"SHEET": sheet_name, "COMPONENT": "Safety / Blockers", "STATUS": safety_status, "POINTS": safety_points, "MAX_POINTS": 5, "DETAIL": safety_detail})

    score = max(0, min(100, int(score)))
    if period_scan.collisions or period_status == "FAIL" or header_status == "FAIL":
        readiness = "BLOCKED"
    elif score >= 85:
        readiness = "READY WITH CONFIRMATION"
    else:
        readiness = "REVIEW"
    return score, readiness, rows, field_status, fact_status


def export_scan_report(source_file: str | Path, output_dir: str | Path = "output") -> Path:
    source = validate_source_path(source_file)
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"{source.stem}_Scan_Report.xlsx"

    # Keep a bounded sample for readiness/fact diagnostics; this does not load the
    # entire workbook into memory even when the shipment has hundreds of thousands of rows.
    inv = inventory_file(source, preview_rows=250)
    headers = scan_workbook_headers(source)
    guide = analyze_guide_sheets(source)

    summary = pd.DataFrame([
        ("Filename", inv.filename),
        ("Extension", inv.extension),
        ("Size bytes", inv.size_bytes),
        ("Sheet/table count", inv.sheet_count),
        ("Guide sheets detected", ", ".join(guide.guide_sheets) if guide.guide_sheets else "None"),
        ("Mode", "Read-only scan; no transformation performed"),
    ], columns=["ITEM", "VALUE"])

    sheet_rows: list[dict[str, Any]] = []
    header_rows: list[dict[str, Any]] = []
    period_detection_rows: list[dict[str, Any]] = []
    period_map_rows: list[dict[str, Any]] = []
    coverage_rows: list[dict[str, Any]] = []
    guide_rows: list[dict[str, Any]] = []
    readiness_rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    recommendations: list[dict[str, Any]] = []

    for item in guide.explicit_period_examples:
        guide_rows.append({
            "GUIDE_SHEET": item.sheet_name,
            "ROW": item.row_number,
            "TYPE": "Explicit period example",
            "PATTERN": "",
            "SOURCE_EXAMPLE": item.source_text,
            "TARGET_EXAMPLE": item.target_text,
            "CONFIDENCE": item.confidence,
            "DETAIL": item.reason,
        })
    for item in guide.pattern_hints:
        guide_rows.append({
            "GUIDE_SHEET": item.sheet_name,
            "ROW": item.row_number,
            "TYPE": "Pattern hint",
            "PATTERN": item.pattern_name,
            "SOURCE_EXAMPLE": item.example,
            "TARGET_EXAMPLE": "",
            "CONFIDENCE": item.confidence,
            "DETAIL": item.reason,
        })
    for metric in guide.metric_hints:
        guide_rows.append({
            "GUIDE_SHEET": ", ".join(guide.guide_sheets),
            "ROW": "",
            "TYPE": "Measure hint",
            "PATTERN": "",
            "SOURCE_EXAMPLE": metric,
            "TARGET_EXAMPLE": "FACT candidate",
            "CONFIDENCE": "Medium",
            "DETAIL": "Possible shipment measure inferred from Guide/Instructions text; confirmation occurs in preparation workflow",
        })
    if guide.calendar_period_codes:
        guide_rows.append({
            "GUIDE_SHEET": ", ".join(guide.guide_sheets), "ROW": "", "TYPE": "Period-code hint",
            "PATTERN": "P01-P12", "SOURCE_EXAMPLE": "P01", "TARGET_EXAMPLE": "Jan", "CONFIDENCE": "High",
            "DETAIL": "Guide text indicates calendar-month interpretation for P01-P12",
        })

    for note in guide.notes:
        guide_rows.append({
            "GUIDE_SHEET": "",
            "ROW": "",
            "TYPE": "Note",
            "PATTERN": "",
            "SOURCE_EXAMPLE": "",
            "TARGET_EXAMPLE": "",
            "CONFIDENCE": "",
            "DETAIL": note,
        })

    by_name = {s.sheet_name: s for s in headers.sheets}
    for sheet in inv.sheets:
        hs = by_name[sheet.name]
        c = hs.recommended
        is_guide = sheet.name in guide.guide_sheets
        pscan = None
        readiness_score = None
        readiness_status = "NOT APPLICABLE" if is_guide else "REVIEW"
        field_status = "N/A"
        fact_status = "N/A"

        for rank, candidate in enumerate(hs.candidates, 1):
            header_rows.append({
                "SHEET": sheet.name,
                "RANK": rank,
                "START_ROW": candidate.start_row,
                "END_ROW": candidate.end_row,
                "CONFIDENCE": candidate.confidence,
                "CONFIDENCE_%": _confidence_percent(candidate.confidence),
                "SCORE": candidate.score,
                "FLATTENED_PREVIEW": " | ".join(candidate.flattened_headers[:30]),
                "REASONS": "; ".join(candidate.reasons),
            })
        for warning in hs.warnings:
            issues.append({"SEVERITY": "WARNING", "SHEET": sheet.name, "TYPE": "HEADER", "DETAIL": warning})

        if c:
            try:
                pscan = scan_sheet_periods(source, sheet.name, header_scan=hs, guide_analysis=guide)
                for finding in pscan.findings:
                    period_detection_rows.append({
                        "SHEET": sheet.name,
                        "LOCATION": finding.location,
                        "SOURCE": finding.source,
                        "FREQUENCY": finding.frequency,
                        "STATUS": finding.status,
                        "CONFIDENCE": finding.confidence,
                        "CONFIDENCE_%": _confidence_percent(finding.confidence),
                        "SOURCE_COLUMNS": ", ".join(finding.source_columns),
                        "DETECTED_COUNT": len(finding.mappings),
                        "DETAIL": finding.detail,
                    })
                    for mapping in finding.mappings:
                        period_map_rows.append({
                            "SHEET": sheet.name,
                            "LOCATION": finding.location,
                            "ORIGINAL_PERIOD": mapping.original,
                            "STANDARD_PERIOD": mapping.standard,
                            "FREQUENCY": mapping.frequency,
                            "PATTERN": mapping.pattern or "",
                            "STATUS": mapping.status,
                            "CONFIDENCE": mapping.confidence,
                            "CONFIDENCE_%": _confidence_percent(mapping.confidence),
                            "REASON": mapping.reason,
                        })

                for collision in pscan.collisions:
                    issues.append({
                        "SEVERITY": "BLOCKER",
                        "SHEET": sheet.name,
                        "TYPE": "PERIOD_COLLISION",
                        "DETAIL": f"{collision.standard_period}: {', '.join(collision.sources)}. No merge was performed.",
                    })

                cov = pscan.coverage
                if cov:
                    coverage_rows.append({
                        "SHEET": sheet.name,
                        "LAYOUT": _layout_name(pscan),
                        "PERIOD_PATTERN": cov.pattern_name or "Mixed / contextual",
                        "FREQUENCY": cov.frequency,
                        "FREQUENCY_CONFIDENCE_%": cov.frequency_confidence,
                        "DETECTED_PERIODS": cov.detected_periods,
                        "FIRST_PERIOD": cov.earliest,
                        "LAST_PERIOD": cov.latest,
                        "SOURCE_ORDER": cov.source_order,
                        "MISSING_PERIODS_COUNT": len(cov.missing_periods),
                        "MISSING_PERIODS": ", ".join(cov.missing_periods),
                        "RECOMMENDED_ACTION": cov.recommended_action,
                    })

                if not is_guide:
                    readiness_score, readiness_status, components, field_status, fact_status = _assess_readiness(
                        sheet_name=sheet.name,
                        header_scan=hs,
                        period_scan=pscan,
                        preview_rows=sheet.preview,
                        guide_analysis=guide,
                    )
                    readiness_rows.extend(components)
                    readiness_rows.append({
                        "SHEET": sheet.name,
                        "COMPONENT": "OVERALL",
                        "STATUS": readiness_status,
                        "POINTS": readiness_score,
                        "MAX_POINTS": 100,
                        "DETAIL": "Transparent weighted readiness assessment; user confirmation is still required before transformation.",
                    })

                # Actionable recommendations.
                if cov:
                    if cov.pattern_name == "cYYYY MMM":
                        recommendations.append({
                            "SHEET": sheet.name,
                            "PRIORITY": "INFO",
                            "RECOMMENDATION": f"Detected client period pattern cYYYY MMM with high confidence (example: c2025 Feb → Feb 2025). {cov.detected_periods} period(s) recognized.",
                        })
                    if cov.source_order == "Non-chronological":
                        recommendations.append({
                            "SHEET": sheet.name,
                            "PRIORITY": "HIGH",
                            "RECOMMENDATION": f"Periods are recognized but source order is non-chronological. Recommended Prepared_Data order: ascending from {cov.earliest} to {cov.latest}; Source_Copy remains unchanged.",
                        })
                    if cov.missing_periods:
                        preview_missing = ", ".join(cov.missing_periods[:12])
                        recommendations.append({
                            "SHEET": sheet.name,
                            "PRIORITY": "REVIEW",
                            "RECOMMENDATION": f"Detected {len(cov.missing_periods)} missing {cov.frequency.lower()} period(s) inside the observed range: {preview_missing}. Confirm whether gaps are expected.",
                        })
                    if not pscan.collisions:
                        recommendations.append({
                            "SHEET": sheet.name,
                            "PRIORITY": "INFO",
                            "RECOMMENDATION": f"Period normalization preview is available in Period_Map. Frequency={cov.frequency}; first={cov.earliest}; last={cov.latest}.",
                        })
                else:
                    suspicious = [h for h in c.flattened_headers if re.search(r"(?:19|20)\d{2}|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|period|month", str(h), re.I)]
                    sample = suspicious[0] if suspicious else "none"
                    recommendations.append({
                        "SHEET": sheet.name,
                        "PRIORITY": "BLOCKER",
                        "RECOMMENDATION": f"Period-like headers may exist but no safe parser matched. Example candidate: {sample}. Review Period_Detection/Guide_Analysis and confirm the client convention; no period will be guessed.",
                    })

                for warning in pscan.warnings:
                    if not warning.startswith("Guide/instruction context analyzed"):
                        issues.append({"SEVERITY": "WARNING", "SHEET": sheet.name, "TYPE": "PERIOD_SCAN", "DETAIL": warning})
            except Exception as exc:
                issues.append({"SEVERITY": "WARNING", "SHEET": sheet.name, "TYPE": "PERIOD_SCAN", "DETAIL": str(exc)})

        cov = pscan.coverage if pscan else None
        sheet_rows.append({
            "SHEET": sheet.name,
            "SHEET_TYPE": "Guide/Instructions" if is_guide else "Data/Other",
            "ROWS": sheet.rows,
            "COLUMNS": sheet.columns,
            "STATE": sheet.state,
            "HEADER_START": c.start_row if c else None,
            "HEADER_END": c.end_row if c else None,
            "HEADER_CONFIDENCE": c.confidence if c else "Review",
            "LAYOUT": _layout_name(pscan) if pscan else "Unknown",
            "PERIOD_PATTERN": cov.pattern_name if cov else None,
            "FREQUENCY": cov.frequency if cov else None,
            "PERIODS_DETECTED": cov.detected_periods if cov else 0,
            "CHRONOLOGY": cov.source_order if cov else "Unknown",
            "FIELD_STATUS": field_status,
            "FACT_STATUS": fact_status,
            "READINESS_%": readiness_score,
            "READINESS_STATUS": readiness_status,
        })

    with pd.ExcelWriter(
        target,
        engine="xlsxwriter",
        engine_kwargs={"options": {"strings_to_formulas": False, "strings_to_urls": False}},
    ) as writer:
        _write_dataframe(writer, "Workbook_Summary", summary, freeze=False)
        _write_dataframe(writer, "Sheet_Summary", pd.DataFrame(sheet_rows))
        _write_dataframe(writer, "Guide_Analysis", pd.DataFrame(guide_rows, columns=[
            "GUIDE_SHEET", "ROW", "TYPE", "PATTERN", "SOURCE_EXAMPLE", "TARGET_EXAMPLE", "CONFIDENCE", "DETAIL"
        ]))
        _write_dataframe(writer, "Header_Detection", pd.DataFrame(header_rows))
        _write_dataframe(writer, "Period_Detection", pd.DataFrame(period_detection_rows, columns=[
            "SHEET", "LOCATION", "SOURCE", "FREQUENCY", "STATUS", "CONFIDENCE", "CONFIDENCE_%", "SOURCE_COLUMNS", "DETECTED_COUNT", "DETAIL"
        ]))
        _write_dataframe(writer, "Period_Map", pd.DataFrame(period_map_rows, columns=[
            "SHEET", "LOCATION", "ORIGINAL_PERIOD", "STANDARD_PERIOD", "FREQUENCY", "PATTERN", "STATUS", "CONFIDENCE", "CONFIDENCE_%", "REASON"
        ]))
        _write_dataframe(writer, "Period_Coverage", pd.DataFrame(coverage_rows, columns=[
            "SHEET", "LAYOUT", "PERIOD_PATTERN", "FREQUENCY", "FREQUENCY_CONFIDENCE_%", "DETECTED_PERIODS", "FIRST_PERIOD", "LAST_PERIOD", "SOURCE_ORDER", "MISSING_PERIODS_COUNT", "MISSING_PERIODS", "RECOMMENDED_ACTION"
        ]))
        _write_dataframe(writer, "Readiness", pd.DataFrame(readiness_rows, columns=[
            "SHEET", "COMPONENT", "STATUS", "POINTS", "MAX_POINTS", "DETAIL"
        ]))
        _write_dataframe(writer, "Issues", pd.DataFrame(issues, columns=["SEVERITY", "SHEET", "TYPE", "DETAIL"]))
        _write_dataframe(writer, "Recommendations", pd.DataFrame(recommendations, columns=["SHEET", "PRIORITY", "RECOMMENDATION"]))
    return target
