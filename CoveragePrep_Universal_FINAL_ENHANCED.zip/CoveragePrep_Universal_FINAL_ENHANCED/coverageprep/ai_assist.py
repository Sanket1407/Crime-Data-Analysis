"""Optional approved-company AI candidate ranker.

Disabled by default. Shipment preparation and validation never depend on this module.
It is intended only for recommendation-only mapping when an approved company endpoint,
token and explicit user approval are available. No numeric shipment facts are sent.
"""
from __future__ import annotations

import json
import os
from urllib.request import Request, urlopen
from typing import Iterable


class AIAssistUnavailable(RuntimeError):
    pass


def is_configured() -> bool:
    return bool(os.getenv("NIQ_AI_ENDPOINT") and os.getenv("NIQ_AI_TOKEN"))


def rank_mapping_candidates(query_text: str, candidates: Iterable[str], *, allow_approved_ai: bool = False) -> list[str]:
    if not allow_approved_ai:
        raise AIAssistUnavailable("Approved AI ranking requires explicit user approval for this run.")
    endpoint=os.getenv("NIQ_AI_ENDPOINT")
    token=os.getenv("NIQ_AI_TOKEN")
    model=os.getenv("NIQ_AI_MODEL", "")
    if not endpoint or not token:
        raise AIAssistUnavailable("NIQ_AI_ENDPOINT / NIQ_AI_TOKEN are not configured.")
    candidate_list=[str(x) for x in candidates]
    payload={
        "model": model,
        "task": "rank_mapping_candidates",
        "query": str(query_text),
        "candidates": candidate_list,
        "rules": "Rank only supplied candidates. Do not invent mappings. Return candidate strings in ranked order.",
    }
    req=Request(endpoint, data=json.dumps(payload).encode("utf-8"), headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"}, method="POST")
    with urlopen(req, timeout=30) as response:
        data=json.loads(response.read().decode("utf-8"))
    ranked=data.get("ranked_candidates") or data.get("candidates")
    if not isinstance(ranked,list):
        raise AIAssistUnavailable("Approved AI response did not contain ranked_candidates.")
    allowed=set(candidate_list)
    return [str(x) for x in ranked if str(x) in allowed]
