# CoveragePrep Universal

A local-first Python application for preparing client shipment Excel/CSV files for Coverage Analysis.

## Run

```bat
python main.py
```

Default menu:

1. **Prepare shipment — Smart Auto** (recommended)
2. **Scan only** — diagnostic report, no transformation
3. **Advanced Review** — manual overrides only when Smart Auto finds a real ambiguity
4. **Reuse saved configuration**
5. Exit

## What Smart Auto now does

- inventories all sheets and recommends data sheets while ignoring obvious Guide/Summary/Notes tabs;
- detects single and multi-row headers and penalizes rows that look like transactions;
- detects period columns, period rows, Year+Month, Year+Week, Year+Quarter, `cYYYY MMM`, sheet periods, and composite `Year + P01/P02` structures;
- scans unique period values across the full relevant columns, so large year sheets do not report only the first month;
- standardizes monthly period labels to `Jan 2026`, `Feb 2026`, etc.;
- preserves weekly/quarterly/bimonthly frequency;
- protects identifiers such as Product_Code, SKU, UPC, EAN, keys and DisplayYear from FACT selection;
- detects one **or multiple** real shipment measures (for example Tons, Value Mio, Eaches) and converts them to separate FACT rows;
- reuses inferred roles/measures across structurally identical sheets automatically;
- uses a neutral `Value` FACT label for wide-period files when business meaning is not explicit, rather than blocking the entire transformation;
- validates every output fact through source lineage before calling the output PASS;
- exports actionable Data Quality, Standardization and Mapping Recommendation sheets.

## Output workbook

A successful Smart Auto run produces:

- `Prepared_Data`
- `Source_Copy` or `Source_Reference`
- `Field_Mapping`
- `Period_Map`
- `Validation`
- `Issues`
- `Data_Quality`
- `Standardization`
- `Mapping_Recommendations`
- `Recommendations`
- `Audit_Log`

The original client shipment is never overwritten.

## Preservation rules

- Client source headers remain unchanged in `Prepared_Data`.
- `FACT` and standardized period headers are the primary standardized structural fields.
- Missing values are never inferred.
- Duplicate-looking records are never summed automatically.
- Product/brand/category/channel value standardization is conservative: safe recommendations are surfaced separately rather than silently merging business values.
- Mapping to NIQ/reference structures is recommendation-only and does not modify `Prepared_Data`.

## Period examples

| Source | Prepared period |
|---|---|
| `c2025 Feb` | `Feb 2025` |
| `JAN-26` | `Jan 2026` |
| `202603` | `Mar 2026` |
| `2026-W05` | `W05 2026` |
| `2026-Q1` | `Q1 2026` |
| stacked `2024` + `P01` | recommends `Jan 2024` and asks one calendar/fiscal/retail confirmation if Guide context does not resolve it |

## Multiple measures

For a source such as:

```text
DisplayMonthYear | Product_Code | Quantity Tons | Value Mio | Quantity Eaches
Jan 2022         | 10001        | 10            | 4.2       | 120
```

CoveragePrep produces FACT rows such as:

```text
Product_Code | FACT             | Jan 2022
10001        | Quantity Tons    | 10
10001        | Value Mio        | 4.2
10001        | Quantity Eaches  | 120
```

Numeric identifier fields remain dimensions/metadata even when they are 100% numeric.

## Optional reference / AI mapping

Put **one approved local reference** `.xlsx` or `.csv` inside `reference/` to enable recommendation-only exact identifier mapping. No mapping is written into Prepared_Data automatically.

`coverageprep/ai_assist.py` contains an optional approved-company AI ranking hook. It is disabled unless `NIQ_AI_ENDPOINT`, `NIQ_AI_TOKEN` and explicit approval are supplied. Shipment preparation never depends on external AI.

## Tests

```bat
python -m pytest -q
```

Synthetic regression samples are included under `sample_data/`, including:

- `sample_c_period_headers.xlsx`
- `sample_multirow_header.xlsx`
- `sample_period_formats.xlsx`
- `sample_multisheet_shipment.xlsx`
- `sample_universal_multi_measure.xlsx`
- `sample_composite_pcodes.xlsx`
