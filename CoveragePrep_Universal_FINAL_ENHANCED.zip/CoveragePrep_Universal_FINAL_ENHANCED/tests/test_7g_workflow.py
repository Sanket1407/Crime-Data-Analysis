from pathlib import Path

from openpyxl import Workbook, load_workbook

from coverageprep.workflow import SheetRunSpec, process_multiple_sheets
from coverageprep.config import save_config, load_config, compare_structure
from coverageprep.export_multi import export_multisheet_run


def _make_multisheet(path: Path, periods=("JAN-26", "FEB2026"), extra=False):
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment KG"
    header = ["Region Description", "Channel Level 1", "Brand Desc", "Material Code"]
    if extra:
        header.append("Distributor Type")
    header += list(periods)
    ws.append(header)
    row = ["West", "MT", "Brand A", "SKU001"]
    if extra:
        row.append("D1")
    ws.append(row + [100, 120])

    ws2 = wb.create_sheet("Shipment Units")
    header2 = ["Region Description", "Channel Level 1", "Brand Desc", "Material Code"]
    if extra:
        header2.append("Distributor Type")
    header2 += list(periods)
    ws2.append(header2)
    row2 = ["West", "MT", "Brand A", "SKU001"]
    if extra:
        row2.append("D1")
    ws2.append(row2 + [20, 25])
    wb.save(path)


def test_multisheet_process_combines_without_merging_headers(tmp_path: Path):
    path = tmp_path / "multi.xlsx"
    _make_multisheet(path)
    specs = [
        SheetRunSpec("Shipment KG", fact_label="KG", header_start_row=1, header_end_row=1),
        SheetRunSpec("Shipment Units", fact_label="UNITS", header_start_row=1, header_end_row=1),
    ]
    run = process_multiple_sheets(path, specs)
    assert run.status == "PASS"
    assert len(run.results) == 2
    assert len(run.combined_data) == 2
    assert run.combined_data["FACT"].tolist() == ["KG", "UNITS"]
    assert "Region Description" in run.combined_data.columns
    assert "Jan 2026" in run.combined_data.columns
    assert "Feb 2026" in run.combined_data.columns


def test_negative_absolute_is_explicit_and_validates(tmp_path: Path):
    path = tmp_path / "neg.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand Desc", "Jan-26", "Feb-26"])
    ws.append(["ABC", -5, 10])
    wb.save(path)
    spec = SheetRunSpec(
        "Data",
        fact_label="Sales Value",
        header_start_row=1,
        header_end_row=1,
        negative_policy="absolute",
    )
    run = process_multiple_sheets(path, [spec])
    assert run.status == "PASS"
    assert run.combined_data.loc[0, "Jan 2026"] == 5
    line = next(x for x in run.results[0].preview.lineage if x.standard_period == "Jan 2026")
    assert line.source_value == -5
    assert line.expected_value == 5
    assert line.action == "negative_to_absolute"


def test_exact_duplicate_drop_is_user_action_and_validates(tmp_path: Path):
    path = tmp_path / "dup.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(["Brand Desc", "Jan-26", "Feb-26"])
    ws.append(["ABC", 100, 120])
    ws.append(["ABC", 100, 120])
    wb.save(path)
    spec = SheetRunSpec(
        "Data",
        fact_label="Sales Value",
        header_start_row=1,
        header_end_row=1,
        duplicate_policy="drop_exact",
    )
    run = process_multiple_sheets(path, [spec])
    assert run.status == "PASS"
    assert len(run.combined_data) == 1
    assert any("exact duplicate" in w.lower() for w in run.results[0].preview.warnings)


def test_config_reuse_allows_new_periods_but_detects_dimension_change(tmp_path: Path):
    original = tmp_path / "janfeb.xlsx"
    _make_multisheet(original)
    specs = [
        SheetRunSpec("Shipment KG", fact_label="KG", header_start_row=1, header_end_row=1),
        SheetRunSpec("Shipment Units", fact_label="UNITS", header_start_row=1, header_end_row=1),
    ]
    run = process_multiple_sheets(original, specs)
    cfg_path = save_config(run, tmp_path / "config.json")
    cfg = load_config(cfg_path)

    next_period = tmp_path / "marapr.xlsx"
    _make_multisheet(next_period, periods=("MAR-26", "APR2026"))
    safe, messages = compare_structure(next_period, cfg)
    assert safe, messages

    changed = tmp_path / "changed.xlsx"
    _make_multisheet(changed, periods=("MAR-26", "APR2026"), extra=True)
    safe2, messages2 = compare_structure(changed, cfg)
    assert not safe2
    assert any("structure changed" in m.lower() or "mapped source-field set changed" in m.lower() for m in messages2)


def test_multisheet_export_has_final_evidence_sheets(tmp_path: Path):
    path = tmp_path / "multi.xlsx"
    _make_multisheet(path)
    specs = [
        SheetRunSpec("Shipment KG", fact_label="KG", header_start_row=1, header_end_row=1),
        SheetRunSpec("Shipment Units", fact_label="UNITS", header_start_row=1, header_end_row=1),
    ]
    run = process_multiple_sheets(path, specs)
    result = export_multisheet_run(path, run, output_dir=tmp_path / "out")
    assert result.status == "PASS"
    wb = load_workbook(result.workbook_path, read_only=True, data_only=False)
    try:
        assert wb.sheetnames == [
            "Prepared_Data",
            "Source_Copy",
            "Field_Mapping",
            "Period_Map",
            "Validation",
            "Issues",
            "Data_Quality",
            "Standardization",
            "Mapping_Recommendations",
            "Recommendations",
            "Audit_Log",
        ]
        assert wb["Prepared_Data"].max_row == 3
        headers = [c.value for c in wb["Prepared_Data"][1]]
        assert "FACT" in headers
        assert "Jan 2026" in headers
    finally:
        wb.close()


def test_user_can_select_fact_source_when_multiple_numeric_columns_exist(tmp_path: Path):
    path = tmp_path / "multi_numeric.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Brand Desc", "Period", "Numeric Code", "Sales Value"])
    ws.append(["ABC", "Jan-26", 999, 100])
    ws.append(["ABC", "Feb-26", 999, 120])
    wb.save(path)
    spec = SheetRunSpec(
        "Shipment",
        fact_label="Sales Value",
        fact_source_header="Sales Value",
        header_start_row=1,
        header_end_row=1,
    )
    run = process_multiple_sheets(path, [spec])
    assert run.status == "PASS"
    assert run.combined_data.loc[0, "Jan 2026"] == 100


def test_confirmed_p_codes_with_year_can_be_used(tmp_path: Path):
    path = tmp_path / "pcodes.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Shipment"
    ws.append(["Brand Desc", "Year", "Period", "Sales Value"])
    ws.append(["ABC", 2026, "P01", 100])
    ws.append(["ABC", 2026, "P02", 120])
    wb.save(path)
    spec = SheetRunSpec(
        "Shipment",
        fact_label="Sales Value",
        fact_source_header="Sales Value",
        header_start_row=1,
        header_end_row=1,
        accept_period_codes=True,
    )
    run = process_multiple_sheets(path, [spec])
    assert run.status == "PASS"
    assert "Jan 2026" in run.combined_data.columns
    assert "Feb 2026" in run.combined_data.columns
