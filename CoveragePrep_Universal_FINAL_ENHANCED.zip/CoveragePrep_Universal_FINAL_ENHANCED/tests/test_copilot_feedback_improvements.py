from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl import Workbook

from coverageprep.guide import analyze_guide_sheets
from coverageprep.periods import parse_period, scan_sheet_periods, PERIOD_PATTERNS
from coverageprep.scanner import scan_sheet_headers
from coverageprep.scanreport import export_scan_report


def _month_labels(start_year=2023, start_month=1, end_year=2026, end_month=1):
    out = []
    y, m = start_year, start_month
    names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    while (y, m) <= (end_year, end_month):
        out.append(f"c{y} {names[m-1]}")
        m += 1
        if m == 13:
            m = 1
            y += 1
    return out


def _build_feedback_workbook(path: Path):
    wb = Workbook()
    guide = wb.active
    guide.title = "Guide"
    guide.append(["Instructions"])
    guide.append(["The columns with the date represent: c2025 Feb = February 2025"])
    guide.append(["Period convention", "cYYYY MMM"])

    ws = wb.create_sheet("Data")
    dims = [
        "L1,3 - Bottler",
        "L1,2 - Division",
        "L2 - Region",
        "LT1,0 - Sub Trade Channel",
        "Product Family",
        "Brand Desc",
        "Material Code",
        "Pack Size",
        "Distributor",
        "Customer Group",
        "Sub Division",
        "Route",
        "State",
        "City",
        "Extra 1",
    ]
    periods = _month_labels()
    # Deliberately scramble while keeping every month in the range.
    order = [13, 16, 17, 2, 18, 6, 24, 0, 1, 3, 4, 5, 7, 8, 9, 10, 11, 12, 14, 15, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36]
    scrambled = [periods[i] for i in order]
    assert len(dims) + len(scrambled) == 52
    ws.append(dims + scrambled)
    for r in range(1, 15):
        dim_values = [
            "Bottler A", "Div 1", "West", "MT", "Beverages", "Brand A",
            f"SKU{r:03d}", "500 ml", "D1", "C1", "SD1", "R1", "GJ", "Vadodara", "X"
        ]
        ws.append(dim_values + [r * 100 + i for i in range(len(scrambled))])
    wb.save(path)


def test_registered_c_year_month_pattern():
    parsed = parse_period("c2025 Feb")
    assert parsed.status == "OK"
    assert parsed.standard == "Feb 2025"
    assert parsed.frequency == "Monthly"
    assert parsed.confidence == "High"
    assert parsed.pattern == "cYYYY MMM"
    assert any(p["name"] == "cYYYY MMM" for p in PERIOD_PATTERNS)


def test_future_month_variants_are_centralized_and_safe():
    assert parse_period("January/2020").standard == "Jan 2020"
    assert parse_period("202603").standard == "Mar 2026"
    assert parse_period("04/2026").standard == "Apr 2026"
    bare = parse_period("01")
    assert bare.status == "AMBIGUOUS"
    assert bare.frequency == "Monthly"
    assert bare.sequence == 1


def test_guide_analysis_extracts_explicit_period_hint(tmp_path):
    path = tmp_path / "feedback.xlsx"
    _build_feedback_workbook(path)
    guide = analyze_guide_sheets(path)
    assert guide.guide_sheets == ["Guide"]
    assert "cYYYY MMM" in guide.pattern_names
    assert "c2025 feb" in guide.explicit_mapping
    assert guide.explicit_mapping["c2025 feb"].target_text == "February 2025"


def test_period_coverage_handles_scrambled_c_headers(tmp_path):
    path = tmp_path / "feedback.xlsx"
    _build_feedback_workbook(path)
    header = scan_sheet_headers(path, "Data")
    assert header.recommended is not None
    scan = scan_sheet_periods(path, "Data", header_scan=header)
    assert scan.coverage is not None
    assert scan.coverage.frequency == "Monthly"
    assert scan.coverage.detected_periods == 37
    assert scan.coverage.earliest == "Jan 2023"
    assert scan.coverage.latest == "Jan 2026"
    assert scan.coverage.source_order == "Non-chronological"
    assert scan.coverage.missing_periods == []
    assert scan.coverage.pattern_name == "cYYYY MMM"
    assert not scan.collisions


def test_scan_report_contains_period_map_coverage_guide_and_readiness(tmp_path):
    path = tmp_path / "feedback.xlsx"
    _build_feedback_workbook(path)
    target = export_scan_report(path, tmp_path)
    assert target.exists()

    xls = pd.ExcelFile(target)
    assert "Period_Map" in xls.sheet_names
    assert "Period_Coverage" in xls.sheet_names
    assert "Guide_Analysis" in xls.sheet_names
    assert "Readiness" in xls.sheet_names

    period_map = pd.read_excel(target, sheet_name="Period_Map")
    data_map = period_map[period_map["SHEET"] == "Data"]
    row = data_map[data_map["ORIGINAL_PERIOD"] == "c2025 Feb"].iloc[0]
    assert row["STANDARD_PERIOD"] == "Feb 2025"
    assert row["PATTERN"] in {"cYYYY MMM", "MMM YYYY", "Guide explicit mapping"}

    coverage = pd.read_excel(target, sheet_name="Period_Coverage")
    data_cov = coverage[coverage["SHEET"] == "Data"].iloc[0]
    assert data_cov["LAYOUT"] == "Wide Monthly"
    assert data_cov["FREQUENCY"] == "Monthly"
    assert int(data_cov["DETECTED_PERIODS"]) == 37
    assert data_cov["FIRST_PERIOD"] == "Jan 2023"
    assert data_cov["LAST_PERIOD"] == "Jan 2026"
    assert data_cov["SOURCE_ORDER"] == "Non-chronological"
    assert int(data_cov["MISSING_PERIODS_COUNT"]) == 0

    sheets = pd.read_excel(target, sheet_name="Sheet_Summary")
    data_sheet = sheets[sheets["SHEET"] == "Data"].iloc[0]
    assert data_sheet["PERIOD_PATTERN"] == "cYYYY MMM"
    assert data_sheet["FREQUENCY"] == "Monthly"
    assert int(data_sheet["PERIODS_DETECTED"]) == 37
    assert data_sheet["CHRONOLOGY"] == "Non-chronological"
    assert int(data_sheet["READINESS_%"]) >= 85

    guide = pd.read_excel(target, sheet_name="Guide_Analysis")
    assert (guide["PATTERN"] == "cYYYY MMM").any()

    recs = pd.read_excel(target, sheet_name="Recommendations")
    data_recs = " ".join(recs[recs["SHEET"] == "Data"]["RECOMMENDATION"].astype(str).tolist())
    assert "non-chronological" in data_recs
    assert "cYYYY MMM" in data_recs
