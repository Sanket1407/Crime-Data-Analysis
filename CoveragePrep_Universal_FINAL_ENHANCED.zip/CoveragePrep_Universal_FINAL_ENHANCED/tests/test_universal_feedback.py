from pathlib import Path
from openpyxl import Workbook

from coverageprep.mapping import detect_fact_measures, suggest_field_roles
from coverageprep.periods import parse_period, scan_sheet_periods
from coverageprep.scanner import scan_sheet_headers
from coverageprep.smart import build_smart_plan
from coverageprep.workflow import process_multiple_sheets


def test_header_scanner_prefers_real_header_over_transaction_rows(tmp_path: Path):
    p=tmp_path/'medium.xlsx'
    wb=Workbook(); ws=wb.active; ws.title='2022'
    ws.append(['Channel','CD_Channel','L3_Branch_Desc','Category','Product_Code','DisplayMonthYear','DisplayYear','[RDBN_Quantity_Tons]'])
    for i in range(30):
        ws.append(['Direct','CP','East Branch','Foods',12508373+i,'Jan 2022',2022,1+i])
    wb.save(p)
    scan=scan_sheet_headers(p,'2022')
    assert scan.recommended.start_row == 1
    assert scan.recommended.end_row == 1


def test_full_unique_period_scan_goes_beyond_first_500_rows(tmp_path: Path):
    p=tmp_path/'periods.xlsx'
    wb=Workbook(); ws=wb.active; ws.title='2022'
    ws.append(['SKU','DisplayMonthYear','Sales Value'])
    for i in range(520): ws.append([10000+i,'Jan 2022',1])
    for m in ['Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']:
        ws.append([20000+len(ws['A']),f'{m} 2022',2])
    wb.save(p)
    h=scan_sheet_headers(p,'2022')
    s=scan_sheet_periods(p,'2022',header_scan=h)
    assert s.coverage.detected_periods == 12
    assert s.coverage.earliest == 'Jan 2022'
    assert s.coverage.latest == 'Dec 2022'


def test_numeric_identifier_and_year_are_protected_from_measure_detection():
    import pandas as pd
    frame=pd.DataFrame({
        'Product_Code':[1001,1002],
        'DisplayYear':[2022,2022],
        '[RDBN_Quantity_Tons]':[1.2,2.3],
        '[RDBN_Value_Mio]':[5.0,6.0],
        '[RDBN_Quantity_Eaches]':[10,20],
    })
    roles={x.source_header:x.role for x in suggest_field_roles(frame.columns)}
    d=detect_fact_measures(frame,layout='ROW_PERIODS',period_source_columns=[],assigned_roles=roles)
    assert d.status == 'OK'
    assert d.measure_columns == ['[RDBN_Quantity_Tons]','[RDBN_Value_Mio]','[RDBN_Quantity_Eaches]']


def test_composite_year_pcode_is_reviewable_not_unrecognized():
    p=parse_period('2024 | P01')
    assert p.status == 'REVIEW'
    assert p.standard == 'Jan 2024'
    assert p.pattern == 'YYYY + Pnn'


def test_smart_plan_processes_multiple_measures_and_excludes_displayyear(tmp_path: Path):
    p=tmp_path/'multi_measure.xlsx'
    wb=Workbook(); ws=wb.active; ws.title='2022'
    ws.append(['Channel','Product_Code','Brand','DisplayMonthYear','DisplayYear','[RDBN_Quantity_Tons]','[RDBN_Value_Mio]','[RDBN_Quantity_Eaches]'])
    for m,base in [('Jan',1),('Feb',2),('Mar',3)]:
        ws.append(['Direct',1000+base,'MAGGI',f'{m} 2022',2022,base,base*10,base*100])
    wb.save(p)
    plan=build_smart_plan(p,selected_sheets=['2022'])
    assert plan.ready
    assert plan.specs[0].fact_source_headers == ['[RDBN_Quantity_Tons]','[RDBN_Value_Mio]','[RDBN_Quantity_Eaches]']
    run=process_multiple_sheets(p,plan.specs)
    assert run.status == 'PASS'
    assert set(run.combined_data['FACT']) == {'[RDBN_Quantity_Tons]','[RDBN_Value_Mio]','[RDBN_Quantity_Eaches]'}
    assert 'DisplayYear' not in run.combined_data.columns


def test_composite_pcode_smart_plan_needs_one_confirmation_then_runs(tmp_path: Path):
    p=tmp_path/'pcode.xlsx'
    wb=Workbook(); ws=wb.active; ws.title='Data'
    ws.append(['Product','Product','Period','Period'])
    ws.append(['Identity','Identity',2024,2024])
    ws.append(['Brand Desc','Product_Code','P01','P02'])
    ws.append(['ABC',10001,10,20])
    wb.save(p)
    plan=build_smart_plan(p,selected_sheets=['Data'])
    assert plan.ready
    assert plan.needs_period_code_confirmation
    confirmed=build_smart_plan(p,selected_sheets=['Data'],accept_period_codes=True)
    run=process_multiple_sheets(p,confirmed.specs)
    assert run.status == 'PASS'
    assert 'Jan 2024' in run.combined_data.columns
    assert 'Feb 2024' in run.combined_data.columns
