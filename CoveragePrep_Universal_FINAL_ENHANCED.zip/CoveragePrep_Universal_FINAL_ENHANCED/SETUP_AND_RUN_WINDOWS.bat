@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo  CoveragePrep Universal - Setup and Run
echo ================================================

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found in PATH.
  echo Install Python 3.10+ and reopen this folder in VS Code.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
  if errorlevel 1 goto :error
)

echo Installing required packages...
call ".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error
call ".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Starting CoveragePrep Universal...
call ".venv\Scripts\python.exe" main.py
exit /b %errorlevel%

:error
echo.
echo Setup failed. Review the error shown above.
pause
exit /b 1
