"""CoveragePrep Universal — simple local UI.

Default path is deliberately low-touch: select a file, confirm recommended sheets,
review one concise auto-plan, then transform/validate/export. Manual field-by-field
configuration is moved behind Advanced Review.
"""
from __future__ import annotations

from pathlib import Path

from coverageprep.reader import inventory_file, ShipmentReadError, UnsupportedFileTypeError
from coverageprep.smart import build_smart_plan, recommend_data_sheets
from coverageprep.workflow import process_multiple_sheets, WorkflowBlocked
from coverageprep.export_multi import export_multisheet_run
from coverageprep.config import save_config
from coverageprep.scanreport import export_scan_report

BANNER = """
========================================================
 CoveragePrep Universal
 Local Shipment Preparation — Smart Mode
========================================================
""".strip()


def _root() -> Path:
    return Path(__file__).parent


def _input_dir() -> Path:
    p = _root() / "input"; p.mkdir(exist_ok=True); return p


def _output_dir() -> Path:
    p = _root() / "output"; p.mkdir(exist_ok=True); return p


def _config_dir() -> Path:
    p = _root() / "config"; p.mkdir(exist_ok=True); return p


def _reference_dir() -> Path:
    p = _root() / "reference"; p.mkdir(exist_ok=True); return p


def choose_input_file() -> Path:
    candidates = sorted(p for p in _input_dir().iterdir() if p.is_file() and p.suffix.lower() in {".xlsx", ".xlsm", ".csv"})
    print("\nAvailable files in input\\:")
    for i, p in enumerate(candidates, 1): print(f"  {i}. {p.name}")
    if not candidates: print("  (none)")
    print("  0. Enter another local file path")
    while True:
        raw = input("Select file: ").strip()
        if raw == "0": return Path(input("File path: ").strip().strip('"'))
        if raw.isdigit() and 1 <= int(raw) <= len(candidates): return candidates[int(raw)-1]
        print("Invalid selection.")


def _parse_sheet_selection(text: str, names: list[str]) -> list[str]:
    out=[]
    for part in text.split(","):
        part=part.strip()
        if not part: continue
        if not part.isdigit() or not (1 <= int(part) <= len(names)):
            raise ValueError(part)
        name=names[int(part)-1]
        if name not in out: out.append(name)
    if not out: raise ValueError("empty")
    return out


def choose_sheets_once(path: Path) -> list[str]:
    inv=inventory_file(path, preview_rows=0)
    all_names=[s.name for s in inv.sheets]
    recommended=recommend_data_sheets(path)
    print("\nRecommended data sheets:")
    print("  " + (", ".join(recommended) if recommended else "None"))
    raw=input("Use these sheets? [Y/n]: ").strip().lower()
    if raw in {"", "y", "yes"}: return recommended
    print("\nSheets:")
    for i,s in enumerate(inv.sheets,1): print(f"  {i}. {s.name} ({s.rows:,} rows x {s.columns:,} cols)")
    while True:
        try: return _parse_sheet_selection(input("Select sheet numbers, e.g. 2,3,4: ").strip(), all_names)
        except ValueError: print("Invalid selection.")


def _reference_file() -> Path | None:
    files=[p for p in _reference_dir().iterdir() if p.is_file() and p.suffix.lower() in {".xlsx", ".csv"}]
    return files[0] if len(files)==1 else None


def _print_plan(plan) -> None:
    print("\n========================================================")
    print(" SMART PLAN")
    print("========================================================")
    for d in plan.diagnostics:
        print(f"\n{d.sheet_name}")
        print(f"  Header:   {d.header}")
        print(f"  Period:   {d.period}")
        if d.measures:
            print(f"  Measures: {', '.join(d.measures)}")
        else:
            print(f"  FACT:     {d.fact_label or 'Value'}")
        for w in d.warnings[:4]: print(f"  Review:   {w}")
        for b in d.blockers: print(f"  BLOCKER:  {b}")
    if plan.guide.guide_sheets:
        print(f"\nGuide context: {', '.join(plan.guide.guide_sheets)}")
        if plan.guide.metric_hints: print("  Measure hints: " + ", ".join(plan.guide.metric_hints))
    print(f"\nReady: {'YES' if plan.ready else 'NO'}")


def smart_prepare() -> None:
    path=choose_input_file()
    sheets=choose_sheets_once(path)
    plan=build_smart_plan(path, selected_sheets=sheets)

    # One confirmation for the entire workbook when Year + P01/P02 is the only
    # unresolved interpretation. This replaces repeated sheet-by-sheet prompts.
    if plan.needs_period_code_confirmation and not plan.guide.calendar_period_codes:
        print("\nYear + P01/P02/... structure detected.")
        print("Interpret P01-P12 as calendar months for this run?")
        print("  Y = P01 -> Jan, P02 -> Feb, ...")
        print("  N = stop and review (use Advanced Review for fiscal/retail calendars)")
        if input("Confirm calendar months? [Y/n]: ").strip().lower() in {"", "y", "yes"}:
            plan=build_smart_plan(path, selected_sheets=sheets, accept_period_codes=True)

    _print_plan(plan)
    if not plan.ready:
        print("\nSmart Prepare stopped because a real ambiguity remains.")
        print("Use option 3 (Advanced Review) only for the unresolved item; nothing was changed.")
        return

    if input("\nProceed with this plan? [Y/n]: ").strip().lower() not in {"", "y", "yes"}:
        print("Cancelled. No output created.")
        return

    run=process_multiple_sheets(path, plan.specs, period_order="ascending")
    ref=_reference_file()
    exported=export_multisheet_run(path, run, output_dir=_output_dir(), reference_file=ref)
    config_path=_config_dir()/f"{path.stem}_Config.json"
    if run.status == "PASS": save_config(run, config_path)

    print("\n========================================================")
    print(" COMPLETE")
    print("========================================================")
    print(f"Status: {run.status}")
    print(f"Prepared rows: {len(run.combined_data):,}")
    print(f"Workbook: {exported.workbook_path}")
    if exported.prepared_csv_path: print(f"Prepared CSV: {exported.prepared_csv_path}")
    if run.status == "PASS": print(f"Reusable config: {config_path}")
    if ref: print(f"Reference mapping advisor used: {ref.name} (recommendation only)")


def scan_only() -> None:
    path=choose_input_file()
    target=export_scan_report(path, _output_dir())
    print(f"\nScan report created: {target}")


def advanced_review() -> None:
    print("\nLaunching Advanced Review. Use this only when Smart Prepare reports a blocker.")
    import advanced_main
    advanced_main.prepare_new()


def reuse_config() -> None:
    import advanced_main
    advanced_main.reuse_config()


def main() -> None:
    print(BANNER)
    while True:
        print("\n1. Prepare shipment — Smart Auto [recommended]")
        print("2. Scan only — create diagnostic report")
        print("3. Advanced Review — manual overrides")
        print("4. Reuse saved configuration")
        print("5. Exit")
        choice=input("Select [1]: ").strip() or "1"
        try:
            if choice=="1": smart_prepare()
            elif choice=="2": scan_only()
            elif choice=="3": advanced_review()
            elif choice=="4": reuse_config()
            elif choice=="5": break
            else: print("Invalid selection.")
        except (ShipmentReadError, UnsupportedFileTypeError, WorkflowBlocked, FileNotFoundError, ValueError) as exc:
            print(f"\nERROR: {exc}")
            print("No source file was modified.")


if __name__ == "__main__": main()
