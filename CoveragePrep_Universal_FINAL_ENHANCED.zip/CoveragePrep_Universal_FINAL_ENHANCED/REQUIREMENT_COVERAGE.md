# Requirement coverage

| Expected outcome | CoveragePrep Universal |
|---|---|
| Ingest Excel/CSV | `.xlsx`, `.xlsm`, `.csv`, multi-sheet inventory |
| Automatically identify/classify relevant columns | Smart role classification + protected period-support and identifier fields |
| Detect missing/incomplete/inconsistent/ambiguous information | Scan Report, Issues, Data_Quality, blockers/warnings |
| Standardize product descriptions, pack sizes, UOM, brand/category/market/channel names | Conservative Standardization recommendations: whitespace, UOM synonyms, pack formatting, surface-equivalent variants; no silent semantic merge |
| Recommend mappings to approved NIQ/reference structures | Optional local exact-identifier Mapping_Recommendations; Prepared_Data unchanged |
| Product identifiers/business rules/historical mappings/AI | Identifier-first deterministic layer; optional approved-company AI candidate ranker hook in `ai_assist.py`, disabled by default |
| Highlight DQ issues with actionable recommendations | Issues + Data_Quality + Recommendations tabs |
| Reduce manual effort/TAT/back-and-forth | Smart Auto, one confirmation summary, multi-measure auto detection, full-sheet period detection, mapping reuse across identical sheets |
| Global standardized approach | Source headers preserved; standardized FACT architecture, standardized readable periods, deterministic validation/audit |
| Numerical correctness | Source lineage, fact-cell count, dimension+FACT+period association, period reconciliation |
| No assumptions/overwrites | Original source untouched; ambiguous data is flagged; no automatic aggregation |
| Large outputs | Excel by default, CSV fallback if worksheet limits are exceeded |
