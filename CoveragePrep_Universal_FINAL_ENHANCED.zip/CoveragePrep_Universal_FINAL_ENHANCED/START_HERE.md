# START HERE — CoveragePrep Universal

## First setup in VS Code

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

Or double-click `SETUP_AND_RUN_WINDOWS.bat` the first time, then `RUN_WINDOWS.bat` later.

## Recommended workflow

Choose **1. Prepare shipment — Smart Auto**.

You normally only need to:

1. select the shipment file;
2. confirm the recommended data sheets once;
3. if Year + `P01/P02/...` is detected without a Guide definition, confirm once whether these are calendar months;
4. review the concise Smart Plan;
5. press Enter to proceed.

The application automatically handles normal header/period/role/measure decisions. Use **Advanced Review** only when Smart Auto reports an actual ambiguity.

## Real client files

You can leave the client file in its existing company folder and choose `0. Enter another local file path`. You do not need to copy confidential files into the project.

Never upload client files to GitHub or external tools.

## Output

Results are written under `output/`. If validation passes, the filename ends in `_Prepared.xlsx`. If validation fails, it ends in `_REVIEW_REQUIRED.xlsx`.

## Safe first tests

Try:

```text
sample_data\sample_universal_multi_measure.xlsx
```

This demonstrates five year sheets, all 12 monthly values, protected Product_Code/DisplayYear fields, and three shipment measures processed automatically.

Then try:

```text
sample_data\sample_composite_pcodes.xlsx
```

This demonstrates a stacked Year + P01/P02 multi-row period header and the one-time confirmation workflow.
