# Universal enhancements from company-laptop feedback

## Problems addressed

1. Transaction rows could outrank the real header.
   - Added semantic field-name evidence and transactional-row similarity penalties.

2. Large year sheets could report only one month because the scanner sampled the first rows.
   - After detecting a period-support column, CoveragePrep scans unique values across the full selected column(s).

3. Product_Code / DisplayYear and other numeric metadata appeared as possible FACT columns.
   - Protected ID/CODE/KEY/YEAR/UPC/EAN/SKU/Product_Code/DisplayYear patterns now stay out of automatic measure selection.

4. Files with several real measures required choosing one.
   - Multiple strong measure columns are processed in one run as separate FACT rows.

5. FACT labels were confusing or unknown for wide layouts.
   - Guide/sheet/workbook hints are used first; otherwise a neutral `Value` label allows safe exploration without blocking.

6. Year + P01/P02 in multi-row headers was treated as unrelated/ambiguous tokens.
   - Composite period detection reconstructs Year + Pxx before validation and asks only one interpretation question when required.

7. Structurally identical sheets repeated the same setup.
   - Smart Plan caches inferred roles/measures by structure and reuses them automatically.

8. Manual role editing was too slow.
   - Smart Auto requires no field-by-field role entry in the normal path. Advanced Review remains available as a fallback.

9. Business requirements called for data-quality and standardization guidance.
   - Added `Data_Quality` and `Standardization` output sheets with actionable, non-destructive recommendations.

10. Product/reference mapping requirements must not alter shipment preparation.
   - Added optional recommendation-only `Mapping_Recommendations` using an approved local reference. External AI is disabled by default.
